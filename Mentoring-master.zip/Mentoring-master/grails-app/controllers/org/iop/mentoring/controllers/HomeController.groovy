package org.iop.mentoring.controllers

import org.iop.mentoring.services.SecurityService

import javax.servlet.http.Cookie

class HomeController {

    def SecurityService securityService

    public static MYIOP_URL = "http://members.iop.org"
    public static IOP_URL = "http://iop.org"
    public static MENTORING_LOGIN_URL = "https://www.iop.org/myportal/MemberSignIn.jsp?page=http://iop.org/mentoring/"
    public static MENTORING_URL = "/mentoring/"

    def index() {
        show("index")

    }

    private void show(page) {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN) {
            redirect(url: MENTORING_LOGIN_URL)
        } else {
            render(view: "index", model: [status: status, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames, page: page])
        }
    }

    def mentoring(){
        show("mentoring")
    }

    def benefits(){
        show("benefits")
    }

    def partnership(){
        show("partnership")
    }

    def use(){
        show("use")
    }

    def dissolving(){
        show("dissolving")
    }

    def receiving_feedback(){
        show("receiving_feedback")
    }

    def giving_feedback(){
        show("giving_feedback")
    }

}
