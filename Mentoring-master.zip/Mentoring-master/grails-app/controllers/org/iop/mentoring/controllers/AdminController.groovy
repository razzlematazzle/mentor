package org.iop.mentoring.controllers

import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Mentor
import org.iop.mentoring.domain.MentorMentee
import org.iop.mentoring.domain.MentoringRequest
import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.ReportService
import org.iop.mentoring.services.SecurityService

class AdminController {

    def SecurityService securityService

    def ReportService reportService

    def index() {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOR
                || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def outstandingRequestsMade = reportService.countOutstandingRequestsMade(id)
            def outstandingRequestsReceived = reportService.countOutstandingRequestsReceived(id)
            render(view: "admin", model: [status: status, person: person, outstandingRequestsMade: outstandingRequestsMade,
                    outstandingRequestsReceived: outstandingRequestsReceived, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }else{
            redirect(controller: "home", action: "index")
        }
    }

    def managePMs(){
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            def requestingPersonMentee
            if (params.id != null){
                requestingPersonMentee = Person.get(Long.parseLong(params.id))
            }else{
                requestingPersonMentee = Person.get(u.id)
            }
            def preferredPersonMentors = requestingPersonMentee.findPreferredMentorPersons()
            def menteeController = new MenteeController()
            menteeController.showManagePreferredMentors(requestingPersonMentee, preferredPersonMentors, status, u.assignedMentorNames, u.preferredMentorNames)
        }
    }

    def applicationsMade(){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def reqs = MentoringRequest.findAllByRequester(person)
            render(view: "/mentee/applications", model: [status: status, person: person, mentoringRequests: reqs, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }else{
            throw new RuntimeException("System error: only registered mentees should have access to this menu option ")
        }
    }

    def applicationsRecd(){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def reqs = MentoringRequest.findAllByMentorRequested(person)
            render(view: "/mentor/applications", model: [status: status, person: person, mentoringRequests: reqs, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }else{
            throw new RuntimeException("System error: only registered mentors should have access to this menu option ")
        }
    }

    def mentorsAssigned(){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, menteeId = u.menteeId
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def menteePerson = Person.get(id)
            def mentee = Mentee.get(menteeId)
            def assignedMentorsPersons = menteePerson.findAssignedMentorPersons()
            def assignedMentors = MentorMentee.findAllByMentee(mentee)
            def assignedMentorsMap = new HashMap<Long, HashMap>()
            def assignedMentor
            for (Person assignedMentorsPerson : assignedMentorsPersons){
                assignedMentor = new HashMap()
                assignedMentor.put("person", assignedMentorsPerson)
                assignedMentorsMap.put(assignedMentorsPerson.mentorId, assignedMentor)
            }
            for (MentorMentee mentorMentee : assignedMentors){
                assignedMentor = assignedMentorsMap.get(mentorMentee.mentorId)
                assignedMentor.put("mentorMentee", mentorMentee)
            }
            render(view: "/mentee/mentorsAssigned", model: [status: status, person: person, mentorsAssigned: assignedMentorsMap, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }else{
            throw new RuntimeException("System error: only registered mentees should have access to this menu option ")
        }
    }

    def menteesAssigned(){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def mentorPerson = Person.get(id)
            def assignedMenteesPersons = mentorPerson.findAssignedMenteePersons()
            def assignedMentees = MentorMentee.findAllByMentor(mentorPerson.mentor)
            def assignedMenteesMap = new HashMap<Long, HashMap>()
            def assignedMentee
            for (Person assignedMenteesPerson : assignedMenteesPersons){
                assignedMentee = new HashMap()
                assignedMentee.put("person", assignedMenteesPerson)
                assignedMenteesMap.put(assignedMenteesPerson.menteeId, assignedMentee)
            }
            for (MentorMentee mentorMentee : assignedMentees){
                assignedMentee = assignedMenteesMap.get(mentorMentee.menteeId)
                assignedMentee.put("mentorMentee", mentorMentee)
            }
            render(view: "/mentor/menteesAssigned", model: [status: status, person: person, menteesAssigned: assignedMenteesMap, assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }else{
            throw new RuntimeException("System error: only registered mentors should have access to this menu option ")
        }
    }

    def mentee = {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def personMentee = Person.get(Long.parseLong(params.id))
            def personMentor = Person.get(id)
            def mentee = personMentee.mentee
            if (!mentee) {
                render( view: "/error", text: 'System error: cannot find mentee for person with id ' + params.id)
            }else{
                if (mentee.location != null){
                    params.put('postZip', mentee.location.postZip)
                    params.put('country', mentee.location.country.name)
                }
                // Look for a Mentoring Request with a status of UNSET (U) for this mentor/mentee (should only ever be 1).
                def req = MentoringRequest.findByRequesterAndMentorRequestedAndAccepted(personMentee, personMentor, 'U')
                def mentoring = MentorMentee.get(personMentor.mentorId, personMentee.menteeId)
                render( view: "/mentee/show", model:[person: personMentee, mentee: mentee, params: params,
                        mentoringRequest: req, mentoring: mentoring, status: status, confirm: false] )
            }
        }else{
            throw new RuntimeException("System error: only registered mentors should have access to this menu option ")
        }
    }

    def mentor = {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def personMentor = Person.get(Long.parseLong(params.id))
            def personMentee = Person.get(id)
            def mentor = personMentor.mentor
            if (!mentor) {
                render( view: "/error", text: 'System error: cannot find mentor for person with id ' + params.id)
            }else{
                if (mentor.location != null){
                    params.put('postZip', mentor.location.postZip)
                    params.put('country', mentor.location.country.name)
                }
                // Look for a Mentoring Request with a status of ACCEPTED (Y) for this mentor/mentee (should only ever be 1).
                def req = MentoringRequest.findByRequesterAndMentorRequestedAndAccepted(personMentee, personMentor, 'Y')
                def showEmail = req != null
                def mentoring = MentorMentee.get(personMentor.mentorId, personMentee.menteeId)
                render( view: "/mentor/show", model:[person: personMentor, mentor: mentor, params: params, showEmail: showEmail,
                        mentoringRequest: req, mentoring: mentoring, status: status, menteesAllocated: mentor.getLiveMentees()] )
            }
        }else{
            throw new RuntimeException("System error: only registered mentees should have access to this menu option ")
        }
    }

    def acceptDecline = {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def req = MentoringRequest.get(params.id)
            if (params.containsKey("decline")){
                declineMentoringRequest(req)
            }else if (params.containsKey("accept")){
                acceptMentoringRequest(req)
            }else{
                throw new RuntimeException("System error: could not find expected Request parameter key for accepting/declining mentoring application")
            }
        }
    }

    def endMentoring = {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def mentoring = MentorMentee.get(Long.parseLong(params.mentorId), Long.parseLong(params.menteeId))
            def personMentee = Person.findByMentee(Mentee.get(mentoring.menteeId))
            def mentee = Mentee.get(personMentee.menteeId)
            if (params.containsKey("confirm")){
                mentoring.end = new Date()
                mentoring.save(flush: true, failOnError: true)
                flash.message = "mentoring support to ${personMentee.firstName} ${personMentee.lastName} is now complete"
                def personMentor = Person.findByMentor(Mentor.get(mentoring.mentorId))
                render(view: "admin", model: [status: status, person: personMentor])
                return
            }else if (params.containsKey("end")){
                flash.message = "This will end the period of mentoring support given to ${personMentee.firstName} ${personMentee.lastName} !"
                render( view: "/mentee/show", model:[person: personMentee, mentee: mentee, params: params, mentoring: mentoring, status: status, confirm: true] )
            }else{
                throw new RuntimeException("System error: expecting to confirm/end as valid options for endMentoring")
            }
        }else{
            throw new RuntimeException("System error: only registered mentors should have access to this menu option ")
        }
    }

    def cancelEndMentoring = {
        flash.message = null
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            def mentor = Mentor.get(Long.parseLong(params.id))
            def personMentor = Person.findByMentor(mentor)
            personMentor.mentor = mentor
            render(view: "admin", model: [status: status, person: personMentor])
        }
    }

    def end_match = {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def (matchMenteeId, matchMentorId) = params.id.split("_")
            def mentee = Mentee.get(matchMenteeId)
            def menteePerson = Person.findByMentee(mentee)
            def mentor = Mentor.get(matchMentorId)
            def mentorPerson = Person.findByMentor(mentor)
            def match = MentorMentee.findByMenteeAndMentorAndEndIsNull(mentee, mentor)
            if (match == null){
                throw new RuntimeException("System error: could not end mentoring match between mentee $matchMenteeId and mentor $matchMentorId - no live record found")
            }else{
                render(view: "confirmEndMatch", model:
                        [status: status,  mentorName: mentorPerson.firstName + " " + mentorPerson.lastName,
                                menteeName: menteePerson.firstName + " " + menteePerson.lastName,
                                menteeId: matchMenteeId, mentorId: matchMentorId])
            }
        }else{
            return
        }
    }

    def confirmed_end_match = {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def (matchMenteeId, matchMentorId) = params.id.split("_")
            def matchMentee = Mentee.get(matchMenteeId)
            def matchMentor = Mentor.get(matchMentorId)
            def liveMatch = MentorMentee.findByMenteeAndMentorAndEndIsNull(matchMentee, matchMentor)
            if (liveMatch != null){
                liveMatch.end = new Date()
                liveMatch.save(flush: true, failOnError: true)
                flash.message = "This mentoring relationship has now been marked as ended."
                render(view: "admin",  model: [status: status, person: Person.get(id)])
                return
            }else{
                throw new RuntimeException("System Error: cannot find Mentoring relationship between mentee $matchMenteeId and mentor $matchMentorId - no live record found");
            }
        }
    }

    private void declineMentoringRequest(req) {
        params.put("requestedPersonMentorId", req.mentorRequested.id)
        params.put("requestingPersonMenteeId", req.requester.id)
        forward(controller: "mentoringRequest", action: "decline", params: getParams())
    }

    private acceptMentoringRequest(req){
        params.put("requestedPersonMentorId", req.mentorRequested.id)
        params.put("requestingPersonMenteeId", req.requester.id)
        forward(controller: "mentoringRequest", action: "accept", params: getParams())
    }

    private boolean checkAdminStatus(status, id){
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN || !person.superUser){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
            return false
        }
        return true
    }
}
