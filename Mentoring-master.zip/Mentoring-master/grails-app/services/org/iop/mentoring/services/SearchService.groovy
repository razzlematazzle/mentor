package org.iop.mentoring.services

import groovy.sql.Sql
import org.iop.mentoring.controllers.SearchCommand
import org.iop.mentoring.domain.IndustrySector
import org.iop.mentoring.domain.PreferredMeetingFormat

import javax.annotation.PostConstruct
import javax.sql.DataSource

class SearchService {

    static transactional = true

    static convertToKilometres = " * 1.609344"

    static convertKmToMiles = " * 0.621371192"

    static final KEYWORD_MATCH_STR = "^[\"'](.*?)[\"']\$"

    static final KEYWORD_SEARCHABLE_COLUMNS = [
            "job_title",
            "industry_sector_other",
            "organisation_type_other",
            "professional_qualifications",
            "highest_qualification_other",
            "current_responsibilities",
            "career_info",
            "subject"]

    static final KEYWORD_SEARCHABLE_MENTOR_COLUMNS = [
            "reason",
            "specialist_skills"]

    static final KEYWORD_SEARCHABLE_MENTEE_COLUMNS = [
            "skills_to_develop"]

    DataSource dataSource

    // The maximum bitmap value in the preferred_meeting_format table, used in bitmap anding.
    def max_pmf_bitmap;

    @PostConstruct
    void init() {
        Sql sql = new groovy.sql.Sql(dataSource)
        def query = "select max(bitmap) max_pmf_bitmap from preferred_meeting_format"
        def row = sql.firstRow(query)
        max_pmf_bitmap = row.max_pmf_bitmap
    }

    public def List<SearchResult> search(SearchCommand sc){
        Sql sql = new groovy.sql.Sql(dataSource)
        def query = createListSQL(sc)
        List<SearchResult> resultsList = createSearchResults(sql, query)
        return resultsList
    }

    public int count(SearchCommand sc) {
        Sql sql = new groovy.sql.Sql(dataSource)
        def query = createCountSQL(sc)
        def row = sql.firstRow(query)
        return row.total
    }

    def String createCountSQL(SearchCommand sc){
        def query
        if (sc.type == "Mentor"){
            query = createMentorCountSQL(sc)
        }else if (sc.type == "Mentee"){
            query = createMenteeCountSQL(sc)
        }else{
            throw new RuntimeException("Query must be of type 'Mentor' or 'Mentee, not '$sc.type'")
        }
        query
    }

    def String createListSQL(SearchCommand sc) {
        def query
        if (sc.type == "Mentor"){
            query = createMentorListSQL(sc)
        }else if (sc.type == "Mentee"){
            query = createMenteeListSQL(sc)
        }else{
            throw new RuntimeException("Query must be of type 'Mentor' or 'Mentee, not '$sc.type'")
        }
        query
    }

    def String createMentorListSQL(SearchCommand sc) {
        return createMentorSQL(sc, false)
    }

    def String createMentorCountSQL(SearchCommand sc){
        return createMentorSQL(sc, true)
    }

    def String createMentorSQL(SearchCommand sc, boolean countOnly) {
        def query, distance
        boolean distanceBasedQuery = isQueryDistanceBased(sc)
        query = countOnly ? selectCountClause : ""
        if (distanceBasedQuery){
            query = replaceOuterSelectDistance(sc, query, selectMentorClause)
            distance = replaceQueryLatitudeLongitudeKm(distanceSql, sc.lat, sc.lng) + ", "
        }else{
            query += selectMentorClause.replace("_DISTANCE_",  "")
            distance = ""
        }
        query += fromMentorClause.
                replace("_DISTANCE_", distance).
                replace("_KEYWORD_SEARCHABLE_COLUMNS_", sc.keywords?.trim()?.length() > 0 ? createKeywordSearchableSelectCols(sc) : "")
        query += createWhereClauseSQL(sc)
        query += groupByClause
        if (!sc.showUnavailable){
            query += havingSpareMenteeCapacityClause
        }
        if (countOnly){
            query += " ) t2"
        }else{
            if (distanceBasedQuery) query += orderByDistanceClause
            else query += orderByNameClause
            query += " limit " + sc.offset + ", "  + sc.max
        }
        query
    }

    private String replaceOuterSelectDistance(SearchCommand sc, String query, String sqlClause) {
        if (sc.units == "miles") {
            query += sqlClause.replace("_DISTANCE_", " round(distance,1) as distance, ")
        } else {
            query += sqlClause.replace("_DISTANCE_", " round(distance $convertToKilometres ,1) as distance, ")
        }
        query
    }

    def String createMenteeListSQL(SearchCommand sc) {
         return createMenteeSQL(sc, false)
    }

    def String createMenteeCountSQL(SearchCommand sc){
        return createMenteeSQL(sc, true)
    }

    def String createMenteeSQL(SearchCommand sc, boolean countOnly) {
        def query, distance
        boolean distanceBasedQuery = isQueryDistanceBased(sc)
        query = countOnly ? selectCountClause : ""
        if (distanceBasedQuery){
            query = replaceOuterSelectDistance(sc, query, selectMenteeClause)
            distance = replaceQueryLatitudeLongitudeKm(distanceSql, sc.lat, sc.lng) + ", "
        }else{
            query += selectMenteeClause.replace("_DISTANCE_",  "")
            distance = ""
        }
        query += fromMenteeClause.
                replace("_DISTANCE_", distance).
                replace("_KEYWORD_SEARCHABLE_COLUMNS_", sc.keywords?.trim()?.length() > 0 ? createKeywordSearchableSelectCols(sc) : "")
        query += createWhereClauseSQL(sc)
        if (countOnly){
            query += " ) t2"
        }else{
            if (distanceBasedQuery) query += orderByDistanceClause
            else query += orderByNameClause
            query += " limit " + sc.offset + ", "  + sc.max
        }
        query
    }

    def isQueryDistanceBased(sc){
        sc.distance?.trim() != "national"
    }

    private List<SearchResult> createSearchResults(Sql sql, String query) {
        List<SearchResult> resultsList = sql.rows(query.toString()).collect { row ->
            new SearchResult(
                    personId: row['person_id'],
                    memberCode: row['member_code'],
                    firstName: row['first_name'],
                    lastName: row['last_name'],
                    active: row['active'],
                    isSuperUser: row['super_user'],
                    isSuspended: row['suspended'],
                    countryCode: row['code'],
                    country: row['country'],
                    postZip: row['post_zip'],
                    townCity: row['town_city'],
                    industrySector: row['industry_sector'],
                    industrySectorId: row['industry_sector_id'],
                    distance: row.containsKey("distance") ? row['distance'] : null,
                    maxMentees: row.containsKey("max_mentees") ? row['max_mentees'] : 0,
                    mentorId: row.containsKey("mentor_id") ? row['mentor_id'] : null,
                    mentees: row.containsKey("mentees") ? row['mentees'] : 0,
                    menteeId: row.containsKey("mentee_id") ? row['mentee_id'] : null
            )
        }
        resultsList
    }

    def String createKeywordSearchableSelectCols(sc){
        def sb = new StringBuilder()
        for (def col : KEYWORD_SEARCHABLE_COLUMNS){
            sb.append(" $col, ")
        }
        if (sc.type == "Mentor"){
            for (def col : KEYWORD_SEARCHABLE_MENTOR_COLUMNS){
                sb.append(" $col, ")
            }
        }else if (sc.type == "Mentee"){
            for (def col : KEYWORD_SEARCHABLE_MENTEE_COLUMNS){
                sb.append(" $col, ")
            }
        }
        sb.toString()
    }

    final static selectCountClause = "select count(*) total from ( "

    final static selectMentorClause =
        'select person_id, member_code, first_name, last_name, active, super_user, suspended, code, country, post_zip, town_city, industry_sector, industry_sector_id, pmf_bitmaps, max_mentees, _DISTANCE_  mentor_id, linked_mentee_count'

    /* (nb: the method of counting the number of linked mentees uses a join between mentor and mentor_mentee, where
       we sum the number of times each mentor_id appears in the latter). */
    final static fromMentorClause = '''
    from
     (select p.id person_id, p.member_code, trim(first_name) first_name, trim(last_name) last_name, m.active, super_user, suspended, c.code, c.name country, post_zip, town_city, i.name industry_sector, i.id industry_sector_id, pmf_bitmaps, max_mentees,
                              _DISTANCE_ _KEYWORD_SEARCHABLE_COLUMNS_ m.id mentor_id, lm.linked_mentee_count
      from person p
      inner join mentor m
        on p.mentor_id = m.id
      left outer join industry_sector i
        on p.industry_sector_id = i.id
      left outer join location l
       on (m.location_id = l.id or m.alternative_location_id = l.id)
      left outer join country c
        on l.country_id = c.id
      inner join (
           select mpmf.mentor_preferred_meeting_formats_id id, sum(bitmap) pmf_bitmaps
           from mentor_preferred_meeting_format mpmf
           inner join preferred_meeting_format pmf
            on mpmf.preferred_meeting_format_id = pmf.id
           group by mentor_preferred_meeting_formats_id
     ) pmf on pmf.id = m.id
      inner join (
          select m.id, sum(mm.mentor_id is not null and mm.end is null) linked_mentee_count
          from mentor m
          left outer join mentor_mentee mm
            on m.id = mm.mentor_id
          group by m.id
        ) lm
       on m.id = lm.id) t
    '''

    final static selectMenteeClause =
        'select person_id, member_code, first_name, last_name, active, super_user, suspended, code, country, post_zip, town_city, industry_sector, industry_sector_id, _DISTANCE_ mentee_id'

    final static fromMenteeClause = '''
    from (
    select p.id person_id, p.member_code, trim(first_name) first_name, trim(last_name) last_name, m.active, super_user, suspended, c.code, c.name country, post_zip, town_city, i.name industry_sector, i.id industry_sector_id,
           _DISTANCE_ _KEYWORD_SEARCHABLE_COLUMNS_ m.id mentee_id
    from person p
      inner join mentee m
        on p.mentee_id = m.id
      left outer join industry_sector i
        on p.industry_sector_id = i.id
      inner join location l
        on m.location_id = l.id
      left outer join country c
        on l.country_id = c.id ) t
    '''

    final static groupByClause = ' group by mentor_id '

    final static havingSpareMenteeCapacityClause = ' having max_mentees > linked_mentee_count '

    final static orderByNameClause = ' order by first_name '

    final static orderByDistanceClause = ' order by distance '

    final static distanceSql =
        ''' ((ACOS(SIN(_LATITUDE_ * PI() / 180) * SIN(latitude * PI() / 180) + COS(_LATITUDE_ * PI() / 180) * COS(latitude * PI() / 180) * COS((_LONGITUDE_ - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515 ) AS `distance` '''

    private String replaceQueryLatitudeLongitudeKm(String query, BigDecimal latitude, BigDecimal longitude) {
        query = query.replaceAll("_LATITUDE_", latitude.toString()).replaceAll("_LONGITUDE_", longitude.toString())
        query
    }

    private String createWhereClauseSQL(SearchCommand sc){
        def where = " where code = '$sc.countryCode' "
        if (sc.preferredMeetingFormats?.size() > 0) where += createWherePreferredMeetingFormatsSQL(sc.preferredMeetingFormats)
        if (sc.distance != "national") where += createWhereDistanceSQL(sc)
        if (sc.industrySectors?.size() > 0) where += createWhereLookupSQL(sc.industrySectors)
        if (sc.keywords?.trim()?.length() > 0) where += createWhereKeywordsSQL(sc)
        if (!sc.showAdmin) where += " and super_user = false "
        if (!sc.showInactive) where += " and active = true "
        if (!sc.showSuspended) where += " and suspended = false "
        where
    }

    String createWherePreferredMeetingFormatsSQL(preferredMeetingFormats){
        def bitmapTotal = 0
        for (PreferredMeetingFormat pmf : preferredMeetingFormats){
            bitmapTotal += pmf.bitmap
        }
        // Handle invalid search params, eg user has chosen "All" and "Phone"
        if (bitmapTotal > max_pmf_bitmap) bitmapTotal = max_pmf_bitmap
        def preferredMeetingFormatClause = " and pmf_bitmaps & $bitmapTotal > 0 "
        preferredMeetingFormatClause
    }

    private String createWhereDistanceSQL(sc){
        def distanceClause = " and distance < " + sc.distance + " "
        if (sc.units == "km") distanceClause += convertKmToMiles
        else if (sc.units != "miles") throw new IllegalStateException("SearchCommand units must be miles or km, not $sc.units")
        distanceClause
    }

    private String createWhereKeywordsSQL(sc){
        def phrase
        def keywords = sc.keywords.trim()
        def m = keywords =~ KEYWORD_MATCH_STR
        def keywordSearchableColumns = []
        keywordSearchableColumns.addAll(KEYWORD_SEARCHABLE_COLUMNS)
        if (sc.type == "Mentor") keywordSearchableColumns.addAll(KEYWORD_SEARCHABLE_MENTOR_COLUMNS)
        else if (sc.type == "Mentee") keywordSearchableColumns.addAll(KEYWORD_SEARCHABLE_MENTEE_COLUMNS)
        if (m.matches()) phrase = createWhereKeywordsPhraseMatchSQL(m[0][1], keywordSearchableColumns)
        else phrase = createWhereKeywordsWordsMatchSQL(keywords, keywordSearchableColumns)
        phrase
    }

    private String createWhereKeywordsPhraseMatchSQL(phrase, keywordSearchableColumns){
        def sb = new StringBuilder(" and (")
        boolean first = true
        for (def col : keywordSearchableColumns){
            if (first) first = false
            else sb.append(" or ")
            sb.append(" $col like '%$phrase%' ")
        }
        sb.append(")")
        sb.toString()
    }

    private String createWhereKeywordsWordsMatchSQL(String keywords, keywordSearchableColumns){
        def phrase = ""
        def keywordNames = keywords?.trim()?.split("\\s+")
        boolean first = true
        if (keywordNames?.size() > 0){
            def sb = new StringBuilder(" and (")
            for (def keyword : keywordNames){
                for (def col : keywordSearchableColumns){
                    if (first) first = false
                    else sb.append(" or ")
                    sb.append(" $col like '%$keyword%' ")
               }
           }
            sb.append(")")
            phrase = sb.toString()
        }
        phrase
    }

    private String createWhereLookupSQL(Set<IndustrySector> industrySectors){
        boolean first = true
        def sql = " and industry_sector_id in ("
        def ids = new TreeSet<Integer>()
        for (def industrySector : industrySectors){
            ids.add(industrySector.id)
        }
        for (def id : ids){
            if (first) first = false
            else sql += ", "
            sql += id
        }
        sql += ")"
        sql
    }

}
