package org.iop.mentoring.domain

class Person {

    public static final int PHOTO_MAXSIZE = 65535

    String memberCode
    String firstName
    String lastName
    Date registrationDate
    String jobTitle
    String employer
    String careerInfo
    String emailAddress
    String alias
    OrganisationType organisationType
    String organisationTypeOther
    IndustrySector industrySector
    String industrySectorOther
    HighestQualification highestQualification
    String highestQualificationOther
    String professionalQualifications
    String currentResponsibilities
    Date startedInCurrentPosition
    Mentor mentor
    Mentee mentee
    boolean superUser = Boolean.FALSE
    boolean suspended = Boolean.FALSE
    byte[] photo
    byte[] oldPhoto
    String socialNetworkSite

    static constraints = {
        alias nullable: true
        firstName blank: false, nullable: false
        lastName blank: false, nullable: false
        jobTitle blank: false, nullable: false
        emailAddress blank: false, nullable: false
        mentor nullable: true
        mentee nullable: true, validator: {
            mentee, person ->
                if (mentee == null && person.mentor == null){
                    throw new IllegalStateException("Person must be either a mentor or mentee")
                }
        }
        industrySector nullable: true
        industrySectorOther nullable: true
        employer nullable: true
        highestQualification nullable: true
        highestQualificationOther nullable: true
        organisationType nullable: true
        organisationTypeOther nullable: true
        socialNetworkSite nullable: true
        startedInCurrentPosition nullable: true, validator: {
            start, obj -> if (start > new Date()){
                return ['person.job.start.in.future']
            }
        }
        superUser defaultValue: Boolean.FALSE
        suspended defaultValue: Boolean.FALSE
        oldPhoto nullable: true
        photo nullable: true, validator: {
            photo, obj ->
            if (photo?.size() > PHOTO_MAXSIZE){
                // This is a hack to force Grails to pick up the correct error message
                return ['person.photo.max.size.error']
            }
        }
        // nb currentResponsibilities and careerInfo validators should be DISABLED when doing data import!
        currentResponsibilities maxSize: 1000, validator: {
            currentResponsibilities, person ->
                if (currentResponsibilities == null || currentResponsibilities.trim().length() == 0){
                    return ['person.currentResponsibilities.blank.error']
                }
        }
        careerInfo maxSize: 1000, validator: {
            careerInfo, person ->
                if (careerInfo == null || careerInfo.trim().length() == 0){
                    return ['person.careerInfo.blank.error']
                }
        }

    }

    public int getYearsInPosition(){
        int yearsInPosition = 0
        if (startedInCurrentPosition != null){
            def today= new Date()
            yearsInPosition =  Math.floor((today - startedInCurrentPosition) / 365.25)
        }
        return yearsInPosition
    }

    // Find this Person's preferred Mentees' Person records.
    public List<Person> findPreferredMentorPersons(){
        def preferredMentorPersons
        def mentorIdList = new StringBuilder()
        if (mentee?.preferredMentors?.size() > 0){
            def sortedPreferredMentors = mentee?.getPreferredMentors()
            for (PreferredMentor preferredMentor : sortedPreferredMentors){
                if (mentorIdList.length() > 0)mentorIdList.append(",")
                mentorIdList.append(preferredMentor.mentor.id)
            }
            preferredMentorPersons = Person.findAll("from Person p where p.mentor.id in ($mentorIdList)")
        }
        preferredMentorPersons
    }

    // Find this Person's assigned Mentees' Person records.
    public List<Person> findAssignedMenteePersons(){
        def assignedMenteePersons
        def menteeIdList = new StringBuilder()
        def assignedMentees = MentorMentee.findAllByMentor(mentor)
        if (assignedMentees.size() > 0){
            for (MentorMentee mentorMentee : assignedMentees){
                if (menteeIdList.length() > 0)menteeIdList.append(",")
                menteeIdList.append(mentorMentee.menteeId)
            }
            assignedMenteePersons = Person.findAll("from Person p where p.mentee.id in ($menteeIdList)")
        }
        assignedMenteePersons
    }

    // Find this Person's assigned Mentors' Person records.
    public List<Person> findAssignedMentorPersons(){
        def assignedMentorPersons
        def mentorIdList = new StringBuilder()
        def assignedMentors = MentorMentee.findAllByMentee(mentee)
        if (assignedMentors.size() > 0){
            for (MentorMentee mentorMentee : assignedMentors){
                if (mentorIdList.length() > 0)mentorIdList.append(",")
                mentorIdList.append(mentorMentee.mentorId)
            }
            assignedMentorPersons = Person.findAll("from Person p where p.mentor.id in ($mentorIdList)")
        }
        assignedMentorPersons
    }

    public static List<Person> findSuperUsers(){
        return Person.findAll("from Person p where p.superUser = true")
    }

}
