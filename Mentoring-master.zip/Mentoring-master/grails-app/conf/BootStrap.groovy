import grails.util.Environment
import org.iop.mentoring.services.CacheService

class BootStrap {

    def init = { servletContext ->
        switch (Environment.current) {
            case Environment.TEST:

                break;
            case Environment.PRODUCTION:
                CacheService.load()
                break;
        }
    }
    def destroy = {
    }
}
