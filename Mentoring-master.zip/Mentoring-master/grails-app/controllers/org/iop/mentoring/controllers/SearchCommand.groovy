package org.iop.mentoring.controllers

import grails.validation.Validateable
import org.iop.mentoring.domain.IndustrySector
import org.iop.mentoring.domain.PreferredMeetingFormat

@Validateable
class SearchCommand {

    String type
    String countryCode = 'GB'
    Set<PreferredMeetingFormat> preferredMeetingFormats
    String distance
    String units = "miles"
    String place
    String jobTitle
    Set<IndustrySector> industrySectors
    String keywords
    // next two variables, offset and max, control which part of the result set should be displayed.
    int offset = 0
    int defaultMax = 30
    int max = defaultMax
    BigDecimal lat = 0
    BigDecimal lng = 0
    boolean showUnavailable = false
    boolean showAdmin = false
    boolean showSuspended = false
    boolean showInactive = false

    public void setPreferredMeetingFormat(String id) {
        this.preferredMeetingFormat = PreferredMeetingFormat.findByName(id)
    }

    public void populateIndustrySectors(String[] args){
        if (args){
            industrySectors = new HashSet<IndustrySector>()
            for (String arg : args){
                arg = arg.trim()
                if (arg.length() > 0)  industrySectors.add(IndustrySector.get(arg))
            }
        }
    }

    public void populatePreferredMeetingFormats(String[] args){
        if (args){
            preferredMeetingFormats = new HashSet<PreferredMeetingFormat>()
            for (String arg : args){
                arg = arg.trim()
                if (arg.length() > 0)  preferredMeetingFormats.add(PreferredMeetingFormat.get(arg))
            }
        }
    }

    static constraints = {
        distance validator: {distance, o ->
            if (distance != "national" && (o.place == null || o.place?.trim()?.length() == 0) ) {
                return ['search.place.missing']
            }

        }
    }
}
