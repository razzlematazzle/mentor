package org.iop.mentoring.domain

class PreferredMeetingFormat implements Comparable{

    final static String ANY = "Any"
    final static String IN_PERSON = "In Person"
    final static String PHONE = 'Phone'
    final static String VIDEO_CONFERENCING = 'Video Conferencing'

    String name
    int bitmap

    PreferredMeetingFormat(name){
        this.name = name
    }

    static def getNames() {
        return listOrderByName()
    }

    static def getDefault(){
        return PreferredMeetingFormat.findByName(ANY)
    }

    @Override
    int compareTo(Object o) {
        this.name.compareTo(((PreferredMeetingFormat)o).name)
    }
}
