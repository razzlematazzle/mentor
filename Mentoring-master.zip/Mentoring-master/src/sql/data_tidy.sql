SUMMARY OF CHANGES TO DATA REQUESTED BY VISHANTI 02 Sep 2014

Current active members
======================
update person set suspended = true where member_code = '1103456';
update person set suspended = true where member_code = '47764';
update person set suspended = true where member_code = '580662';
update person set suspended = true where member_code = '1036490';
update person set suspended = true where member_code = '58720';
update person set suspended = true where member_code = '1068337';
update person set suspended = true where member_code = '1092985';
update person set suspended = true where member_code = '581822';
update person set suspended = true where member_code = '1118453';
update person set suspended = true where member_code = '1074881';
update person set suspended = true where member_code = '1105380';
update person set suspended = true where member_code = '47440';
update person set suspended = true where member_code = '1122689';
update person set suspended = true where member_code = '1024813';

Lapsed
======
update person set suspended = true where member_code = '80013329';
update person set suspended = true where member_code = '1063748';
update person set suspended = true where member_code = '1108703';

Resigned
========
delete from mentor_preferred_meeting_format
where mentor_preferred_meeting_formats_id = (select mentor_id from person where member_code = '80002485');
delete from mentor
where id = (select mentor_id from person where member_code = '80002485');
delete from person where member_code = '80002485';
delete from preferred_mentor where mentee_id = (select mentee_id from person where member_code = '80002485');
delete from mentee
where id = (select mentee_id from person where member_code = '80002485');

delete from mentor_preferred_meeting_format
where mentor_preferred_meeting_formats_id = (select mentor_id from person where member_code = '1109341');
delete from mentor
where id = (select mentor_id from person where member_code = '1109341');
delete from person where member_code = '1109341';
delete from mentee
where id = (select mentee_id from person where member_code = '1109341');
delete from preferred_mentor where mentee_id = (select mentee_id from person where member_code = '1109341');

delete from mentor_preferred_meeting_format
where mentor_preferred_meeting_formats_id = (select mentor_id from person where member_code = '1104380');
delete from mentor
where id = (select mentor_id from person where member_code = '1104380');
delete from person where member_code = '1104380';
delete from mentee
where id = (select mentee_id from person where member_code = '1104380');
delete from preferred_mentor where mentee_id = (select mentee_id from person where member_code = '1104380');

delete from mentor_preferred_meeting_format
where mentor_preferred_meeting_formats_id = (select mentor_id from person where member_code = '1110988');
delete from person where member_code = '1110988';
delete from mentor
where id = (select mentor_id from person where member_code = '1110988');
delete from mentee
where id = (select mentee_id from person where member_code = '1110988');
delete from preferred_mentor where mentee_id = (select mentee_id from person where member_code = '1110988');

delete from mentor_preferred_meeting_format
where mentor_preferred_meeting_formats_id = (select mentor_id from person where member_code = '1113447');
delete from person where member_code = '1113447';
delete from mentor
where id = (select mentor_id from person where member_code = '1113447');
delete from mentee
where id = (select mentee_id from person where member_code = '1113447');
delete from preferred_mentor where mentee_id = (select mentee_id from person where member_code = '1113447');

commit;
