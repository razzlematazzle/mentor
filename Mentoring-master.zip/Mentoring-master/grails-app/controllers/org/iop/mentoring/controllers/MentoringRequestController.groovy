package org.iop.mentoring.controllers

import org.iop.mentoring.controllers.HomeController
import org.iop.mentoring.domain.MentorMentee
import org.iop.mentoring.domain.MentoringRequest
import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.HumanVerificationService
import org.iop.mentoring.services.SecurityService

class MentoringRequestController {

    private static final int MAX_ALLOWED_LIVE_MENTORS = 2
    // Specify the maximum allowed number of mentoring requests that a mentee may submit in a given number of months
    private static final int MAX_ALLOWED_REQUESTS = 2
    private static final int MAX_ALLOWED_REQUESTS_MONTHS = 3
    private static final int LINE_BREAK_LENGTH = 90
    static final lengthOfVerificationString = 9
    private static final String HOW_MENTORING_WORKS = "http://www.iop.org/membership/prof-dev/tools/mentoring/partnership/page_38867.html"

    def SecurityService securityService

    def mailService

    def create() {
        def requestedPersonMentor = Person.get(params.requestedPersonMentorId)
        def requestingPersonMentee = Person.get(params.requestingPersonMenteeId)
        validateMentorRequest(requestedPersonMentor, requestingPersonMentee)
        render(view: "create", model: [requester: requestingPersonMentee, mentor: requestedPersonMentor])
    }

    // Mentee has clicked Next after viewing mentor
    def next(){
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def personRequester = Person.get(Long.parseLong(params.requesterId))
            def personMentor = Person.get(Long.parseLong(params.mentorId))
            // Ask for confirmation before sending email
            def emailText = createEmailBody(personRequester, personMentor.firstName, params.comment)
            def copyEmail = true
            def (html, targetEncrypted, startTags, endTags) =  HumanVerificationService.getVerificationStrings(lengthOfVerificationString)
            render(view: "confirm", model: [emailText: emailText, searchParams: params.searchParams, mentorRequested: personMentor,
                    verificationHtml: html, verificationKey: targetEncrypted, startTags: startTags, endTags: endTags, copyEmail: copyEmail])
        }else{
            // Not a registered mentee, so redirect to home mentoring screen
            redirect(url: HomeController.MENTORING_URL)
        }
    }

    private String createEmailBody(requester, mentorFirstName, comment){
        def sb = new StringBuilder()
        sb.append("Dear " + mentorFirstName + ",\n\n")
        sb.append("${requester.firstName} ${requester.lastName} has requested you as a mentor. ")
        sb.append("${requester.firstName} is registered as a mentee with these details:-\n\n")
        appendFieldToEmailText(sb, "Job title", requester.jobTitle)
        appendFieldToEmailText(sb, "Type of Organisation", requester.organisationType?.name)
        appendFieldToEmailText(sb, "Highest Qualification", requester.highestQualification?.name)
        appendFieldToEmailText(sb, "Subject", requester.mentee.subject)
        appendFieldToEmailText(sb, "Industry Sector", requester.industrySector?.name)
        if (requester.mentee.location?.postZip != null){
            sb.append("Location: $requester.mentee.location.postZip, $requester.mentee.location.country.name\n")
        }else if (requester.mentee.location?.country?.name != null){
            sb.append("Location: $requester.mentee.location.country.name\n")
        }
        def needMentorReasons = ""
        for (def needMentorReason : requester.mentee.needMentorReasons ){
            if (needMentorReasons.length() > 0) needMentorReasons += ", "
            needMentorReasons += needMentorReason.reason
        }
        appendFieldToEmailText(sb, "Why I want a mentor", needMentorReasons)
        if (requester.currentResponsibilities?.trim()?.length() > 0){
            appendFieldToEmailText(sb, "\nCurrent Responsibilities", lineBreak(requester.currentResponsibilities, LINE_BREAK_LENGTH))
        }
        if (requester.mentee.skillsToDevelop?.trim()?.length() > 0){
            appendFieldToEmailText(sb, "\nSkills To Develop", lineBreak(requester.mentee.skillsToDevelop, LINE_BREAK_LENGTH))
        }
        if (comment){
            sb.append("\nComment specifically for you:")
            sb.append(lineBreak(comment, LINE_BREAK_LENGTH) + "\n")
        }
        sb.append("\n\nPlease respond to ${requester.firstName}'s request and state whether you are able to provide mentoring at this time.\n" +
                "To contact ${requester.firstName}, please log in to the mentoring website at ${HomeController.IOP_URL}${HomeController.MENTORING_URL},\n" +
                "select 'Your info' from the menu, click on 'Requests received', and choose to accept or decline.\n\n" +
                "If you accept, ${requester.firstName} will then be given your email address and will contact you directly.\n\n" +
                "If you have any questions please do not hesitate to contact us at mentoring@iop.org\n\n\n"+
                "Best wishes,\n" +
                "Vishanti Fox\n" +
                "Careers Manager\n" +
                "Institute of Physics\n" +
                "76 Portland Place, London W1B 1NT\n" +
                "E-mail: vishanti.fox@iop.org\n" +
                "Direct tel: +44 (0)20 7470 4906"
        )
        return sb.toString()
    }

    private void appendFieldToEmailText(StringBuilder sb, String fieldName, String fieldContents) {
        if (fieldContents != null && fieldContents.trim().length() > 0 ){
            sb.append("$fieldName: $fieldContents\n")
        }
    }

    private String lineBreak(String s, int maxLength) {
        def brokenLine = new StringBuilder()
        def line = new StringBuilder("\n   \" ")
        def chunks = s.split(/\s+/)
        for (String chunk : chunks){
            if (line.length() + chunk.length() < maxLength){
                line.append(chunk + ' ')
            }else{
                brokenLine.append(line + "\n" + chunk + ' ')
                line.setLength(0)
            }
        }
        if (line.length() > 0) brokenLine.append(line + "\"")
        brokenLine.toString()
    }

    // Arrive here when user has clicked on "Send request now" in confirm.gsp
    def confirmed () {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            // validate the requester is human
            if (HumanVerificationService.encodeString(params.verification).equals(params.verificationKey)){
                def requestedPerson = Person.get(Long.parseLong(params.mentorRequestedId))
                def personRequester = Person.get(id)
                def mentoringRequest = new MentoringRequest([requester: personRequester, mentorRequested: requestedPerson])
                sendEmail(mentoringRequest, params.copyEmail, params.emailText)
                mentoringRequest.emailSent = true
                mentoringRequest.save(flush: true)
                render(view: "sent", model: [mentorRequested: requestedPerson, status: status])
            }else{
                def (html, targetEncrypted, startTags, endTags) = HumanVerificationService.getVerificationStrings(lengthOfVerificationString)
                flash.message = "Sorry, you did not correctly extract the " + startTags + " bold/emphasised" + endTags + " text - please try again"
                redisplayConfirmation(html, targetEncrypted, startTags, endTags)
            }
            return
        }else{
            // Not a registered mentee, so redirect to home mentoring screen
            redirect(url: HomeController.MENTORING_URL)
        }
    }

    private sendEmail(MentoringRequest mentoringRequest, String copyEmailForSender, emailText) {
        def emailSubject = "Mentoring Request from ${mentoringRequest.requester.firstName} ${mentoringRequest.requester.lastName}"
        def emailFrom = g.message(code: "iop.careers.manager.email")
        mailService.sendMail {
            from emailFrom
            to mentoringRequest.mentorRequested.emailAddress
            bcc g.message(code: "iop.admin.email")
            subject emailSubject
            text emailText
        }
        if (copyEmailForSender){
            mailService.sendMail {
                from emailFrom
                to mentoringRequest.requester.emailAddress
                subject "COPY of " + emailSubject + " - SENT TO ${mentoringRequest.mentorRequested.firstName}"
                text emailText
            }
        }
    }

    private void redisplayConfirmation(veriHtml, targetEncrypted, startTags, endTags) {
        def personMentor = Person.get(Long.parseLong(params.mentorRequestedId))
        render(view: "confirm", model: [emailText: params.emailText, searchParams: params.searchParams, mentorRequested: personMentor,
                verificationHtml: veriHtml, verificationKey: targetEncrypted, startTags: startTags, endTags: endTags, copyEmail: params.copyEmail])
    }

    def edit(){
        def requestedPersonMentor = Person.get(params.requestedPersonMentorId)
        def requestedPersonMentee = Person.get(params.requestingPersonMenteeId)
        render(view: "create", model: [requester: requestedPersonMentee, mentor: requestedPersonMentor, comment: params.comment])
    }

    def cancel(){
        redirect(url: "/")
    }

    def accept(){
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def req = MentoringRequest.get(params.id)
            req.accept()
            def mentorMentee = new MentorMentee()
            mentorMentee.mentee = req.requester.mentee
            mentorMentee.mentor = req.mentorRequested.mentor
            mentorMentee.start = new Date()
            if (mentorMentee.save(flush: true, failOnError: true)){
                req.save(flush: true, failOnError: true)
                def personMentor = Person.get(params.requestedPersonMentorId)
                def personMentee = Person.get(params.requestingPersonMenteeId)
                def emailText = createEmailAcceptBody(personMentor, personMentee, req)
                def emailSubject = "${personMentor.firstName} will provide mentoring support to you"
                sendAcceptOrDeclineEmail(req, emailSubject, emailText)
                flash.message = "${req.requester.firstName} ${req.requester.lastName} is now recorded as receiving mentoring from you"
                redirect(controller: "admin", action: "index", status: status)
                return
            }else{
                throw new RuntimeException("System error: could not save new MentorMentee record")
            }
        }
    }

    def decline() {
        def requestedPersonMentor = Person.get(params.requestedPersonMentorId)
        def requestedPersonMentee = Person.get(params.requestingPersonMenteeId)
        render(view: "decline", model: [requester: requestedPersonMentee, mentor: requestedPersonMentor])
    }

    def confirmDecline(){
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTOR || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def personMentor = Person.get(params.requestedPersonMentorId)
            def personMentee = Person.get(params.requestingPersonMenteeId)
            def req = MentoringRequest.get(params.id)
            def emailText = createEmailDeclineBody(personMentor, personMentee,req)
            def emailSubject = "${personMentor.firstName} is unable to provide mentoring support"
            sendAcceptOrDeclineEmail(req, emailSubject, emailText)
            req.decline()
            req.save(flush: true, failOnError: true)
            flash.message = "Notification has been sent to ${personMentee.firstName} ${personMentee.lastName}"
            redirect(controller: "admin", action: "index", status: status)
        }

    }

    private String createEmailAcceptBody(personMentor, personMentee, req ){
        def sb = new StringBuilder()
        sb.append("Dear " + personMentee.firstName + ",\n\n")
        sb.append("You requested ${personMentor.firstName} as your mentor on ${req.requestDate.format("dd MMM yyyy")}.\n\n")
        sb.append("We have received confirmation that ${personMentor.firstName} is willing to act as your mentor.\n")
        sb.append("Please log in to mentoring at ${HomeController.IOP_URL}${HomeController.MENTORING_URL}, choose 'Your info' from the menu, and then 'Requests made'.\n You will be able to access ${personMentor.firstName}'s  email.\n\n")
        sb.append("If you need any information on how to set up a mentoring contract, visit $HOW_MENTORING_WORKS\n\n")
        sb.append("If you have any questions please do not hesitate to contact us at mentoring@iop.org\n\nGood luck from the mentoring team!")
        sb.toString()
    }

    private String createEmailDeclineBody(personMentor, personMentee,req ){
        def sb = new StringBuilder()
        sb.append("Dear " + personMentee.firstName + ",\n\n")
        sb.append("You requested mentoring from ${personMentor.firstName} on ${req.requestDate.format("dd MMM yyyy")}.\n\n")
        sb.append("Unfornately ${personMentor.firstName} is unable to provide mentoring support to you")
        if (params.comment?.trim().length() > 0){
            sb.append(" for the following reason:\n\"${params.comment}\"\n\n")
        }else{
            sb.append(" on this occasion, but feel free to select another mentor.\n\n")
        }
        sb.append("If you have any questions please do not hesitate to contact us at mentoring@iop.org\n\nKind regards from the mentoring team.")
        sb.toString()
    }

    private sendAcceptOrDeclineEmail(MentoringRequest mentoringRequest, emailSubject, emailText) {
        def emailFrom = g.message(code: "iop.careers.manager.email")
        mailService.sendMail {
            from emailFrom
            to mentoringRequest.requester.emailAddress
            bcc g.message(code: "iop.admin.email")
            subject emailSubject
            text emailText
        }
    }

    private validateMentorRequest(Person requestedPersonMentor, Person requestingPersonMentee){
        // Check the mentee doesn't already have the maximum number of mentees
        def liveAllocatedMentors = MentorMentee.findAllByMenteeAndEndIsNull(requestingPersonMentee.mentee)
        if (liveAllocatedMentors.size() >= MAX_ALLOWED_LIVE_MENTORS){
            flash.message = "You already have the maximum allowed number of mentors (${MAX_ALLOWED_LIVE_MENTORS}) allocated to you."
            if (params.containsKey("type")){
                // contains a search type, so redirect back to Search screen
                redirect(controller: "search", action: "list", params: getParams())
            }else{
                redirect(controller: "admin", action: "managePMs", params: getParams())
            }
            return
        }
        // Check we don't already have a request from this mentee to this mentor
        def req = MentoringRequest.findByMentorRequestedAndRequester(requestedPersonMentor, requestingPersonMentee)
        if (req != null){
            flash.message = "You have already made a mentoring request to ${requestedPersonMentor.firstName} ${requestedPersonMentor.lastName}"
            if (params.containsKey("type")){
                // contains a search type, so redirect back to Search screen
                redirect(controller: "search", action: "list", params: getParams())
            }else{
                redirect(controller: "admin", action: "managePMs", params: getParams())
            }
            return
        }else{
            // Check the mentee hasn't exceeded the maximum number of requests.
            def d = new GregorianCalendar()
            d.setTime(new Date())
            d.add(Calendar.MONTH, -3)
            def validationDate = d.getTime()
            def requests = MentoringRequest.findAllByRequesterAndRequestDateGreaterThan(requestingPersonMentee, validationDate)
            if (requests.size() >= MAX_ALLOWED_REQUESTS){
                flash.message = "You have already made ${requests.size()} mentoring requests in the last $MAX_ALLOWED_REQUESTS_MONTHS months, please contact mentoring@iop.org if you wish to select a new mentor"
                if (params.containsKey("type")){
                    // contains a search type, so redirect back to Search screen
                    redirect(controller: "search", action: "list", params: getParams())
                }else{
                    redirect(controller: "admin", action: "managePMs", params: getParams())
                }
                return
            }
        }
    }

}
