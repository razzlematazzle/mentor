import org.iop.mentoring.domain.HighestQualification
import org.iop.mentoring.domain.IndustrySector
import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Mentor
import org.iop.mentoring.domain.NeedMentorReason
import org.iop.mentoring.domain.OrganisationType
import org.iop.mentoring.domain.Person
import org.iop.mentoring.domain.PreferredMeetingFormat
import org.iop.mentoring.services.GeocodingService

import java.sql.*
import java.text.SimpleDateFormat

/**
 * Read data from ProTech data and import into new structure.
 */
public class DataMigrator {
    def Connection msConnect = null
    def Statement msStatement = null
    def ResultSet msResultSet = null
    def Connection myConnect = null
    def Statement myStatement = null
    def ResultSet myResultSet = null
    def sdf = new SimpleDateFormat("MMM dd yyyy");
    Map<String, IndustrySector> industrySectors = new HashMap<String, IndustrySector>()
    Map<String, OrganisationType> organisationTypes = new HashMap<String, OrganisationType>()
    Map<String, HighestQualification> highestQualifications = new HashMap<String, HighestQualification>()
    Map<String, NeedMentorReason> needMentorReasons = new HashMap<String, NeedMentorReason>()
    Map<String, PreferredMeetingFormat> preferredMeetingFormats = new HashMap<String, PreferredMeetingFormat>()
    Map<String, List<RecordContactUD>> recordContactUDs
    Map<String, String[]> firstLastNames
    Map<String, Address> addresses
    def memberLatLng = new HashMap<String, double[]>()

    public static void main(String[] args) throws Exception {
        DataMigrator dataMigrator = new DataMigrator()
        if (args.length != 3){
            System.err.println("Program arguments: MSSQL-username MSSQL-password MySQL-username. You may also need VM options: -DproxySet=true -DproxyHost=iop-ldn-inet -DproxyPort=8080")
        }else{
            dataMigrator.migrateDataBase(args[0], args[1], args[2], "compaq")
        }
    }

    public void migrateDataBase(String msUserName, String msPassword, String myUserName, String myPassword) throws Exception {
        try {
            // set up SQL Server
            def msUrl = "jdbc:sqlserver://IOP-LDN-PRO08:1433;databasename=IOP_ProDB_Web_Live";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            def msConnect = DriverManager.getConnection(msUrl, msUserName, msPassword);
            Class.forName("com.mysql.jdbc.Driver");
            msStatement = msConnect.createStatement();
            // set up MySQL
            Class.forName("com.mysql.jdbc.Driver")
            def myUrl = "jdbc:mysql://192.168.20.15:3306/mentoring"
            def myConnect = DriverManager.getConnection(myUrl, myUserName, myPassword);
            myConnect.setAutoCommit(false)
            myStatement = myConnect.createStatement()
            clearData()
            // adapt database - wrong data-type is created by Grails/mysql mapping.
            if (!adaptDB()){
                System.err.println("Could not adapt database!!!")
                System.exit(1)
            }
            // load data
            recordContactUDs = loadRecordContactUDs()
            addPreferredMeetingFormats()
            // Commit the changes to reference data, so that new ids are automatically created, and can be referred to by records in other tables.
            myConnect.commit()
            // Read in lookup data, with new ids
            updateLookups()
            populateMemberLatLng()
            firstLastNames = loadFirstLastNames()
            addresses = loadAddresses()
            def menteeMentorsList = mergeSaveRecords()
            myConnect.commit()
            updateEmployerNames()
            saveMentorMenteeRecords(menteeMentorsList)
            savePreferredMeetingFormatsAndMentoringLocations()
            saveMenteeLocation()
            myConnect.commit()
            summary()
        } catch (Exception e) {
            System.err.println(e.getMessage())
            myConnect.rollback()
            throw e;
        } finally {
            close();
        }
    }

    private boolean adaptDB(){
        boolean ok = true
        try{
            def sql = "ALTER TABLE mentoring.person CHANGE photo photo blob"
            myStatement.execute(sql)
            sql = "ALTER TABLE mentoring.person CHANGE old_photo old_photo blob"
            myStatement.execute(sql)
            sql = "alter table mentee modify skills_to_develop varchar (1000)"
            myStatement.execute(sql)
            sql = "alter table mentor modify specialist_skills  varchar (1000)"
            myStatement.execute(sql)
            sql = "alter table mentor modify reason varchar (1000)"
            myStatement.execute(sql)
            sql = "alter table person modify current_responsibilities varchar(1000)"
            myStatement.execute(sql)
            sql = "alter table person modify career_info varchar(1000)"
            myStatement.execute(sql)
        }catch (SQLException e){
            ok = false
        }
        return ok
    }

    private void updateLookups() {
        updateLookups("industry_sector", "name", industrySectors)
        updateLookups("organisation_type", "name", organisationTypes)
        updateLookups("highest_qualification", "name", highestQualifications)
        updateLookups("need_mentor_reason", "reason", needMentorReasons)
        updateLookups("preferred_meeting_format", "name", preferredMeetingFormats)
    }

    private void updateLookups(tableName, fieldName, lookups) {
        myResultSet = myStatement.executeQuery("select * from $tableName")
        def key, id
        while (myResultSet.next()) {
            key = myResultSet.getString(fieldName)
            id = myResultSet.getInt("id")
            lookups.get(key).id = id
        }
    }

    def clearData() {
        deleteTableRecords("mentor_preferred_meeting_format")
        deleteTableRecords("preferred_mentor")
        deleteTableRecords("mentoring_request")
        deleteTableRecords("person")
        deleteTableRecords("mentor_mentee")
        deleteTableRecords("mentee")
        deleteTableRecords("mentor")
        deleteTableRecords("location")
        deleteTableRecords("industry_sector")
        deleteTableRecords("need_mentor_reason")
        deleteTableRecords("highest_qualification")
        deleteTableRecords("organisation_type")
        deleteTableRecords("preferred_meeting_format")
    }

    private void deleteTableRecords(tableName) {
        def deleted
        try {
            deleted = myStatement.executeUpdate("delete from $tableName")
            println("Deleted " + deleted + " records from $tableName")
        } catch (Exception e) {
            System.err.println("Could not delete records from $tableName : " + e.getMessage())
        }
    }

    /* Read data values from the recordContactUDs, and create inserts  from them in the person, mentor and mentee tables.
       Note that preferred mentor information is stored temporarily in menteeMentorsList, which is returned to called
       for processing later.
     */
    def mergeSaveRecords() {
        List<MenteeMentors> menteeMentorsList = new ArrayList<MenteeMentors>()
        List<RecordContactUD> recordContactUDsList
        def peopleInserted = 0
        def mentorsInserted = 0
        def menteesInserted = 0
        for (String recordCode : recordContactUDs.keySet()) {
            recordContactUDsList = recordContactUDs.get(recordCode)
            def person = new Person()
            person.memberCode = recordCode
            def menteeMentors = null;
            def tableCode, childFieldCode, dataValue
            for(RecordContactUD rec: recordContactUDsList) {
                tableCode = rec.tableCode?.trim()
                childFieldCode = rec.childFieldCode?.trim()
                dataValue = rec.dataValue?.trim()
                switch (childFieldCode){
                    case 'MENT' :       // Years in position            7
                        // This data is no longer required.
                        break;
                    case 'MENT1' :      // Industry sector
                        if (hasDataValue(dataValue)){
                            def industrySector = industrySectors.get(dataValue)
                            if (industrySector == null) throw new IllegalStateException(
                                    "Cannot find IndustrySector of' " + dataValue + "'")
                            person.industrySector = industrySector
                        }
                        break;
                    case 'MENT2' :      // Specialist skills e.g. scanning electron microscopy or project management
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentor.specialistSkills = dataValue
                        }
                        break
                    case 'MENT3' :      // Current responsibilities
                        if (hasDataValue(dataValue)){
                            person.currentResponsibilities = dataValue
                        }
                        break
                    case 'MENT4' :      // How many mentees are you able to take on?
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentor.maxMentees = Integer.parseInt(dataValue)
                        }
                        break
                    case 'MENT5' :      // Do you have mentoring experience?
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentor.experienced = dataValue == 'Y'
                        }
                        break
                    case 'MENT6' :      // Available hours per month - this data is no longer required.
                        break;
                    case 'MENT7' :      // Why do you want to be a mentor?
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentor.reason = dataValue
                        }
                        break
                    case 'MENT8' :      // Mentees
                        if (hasDataValue(dataValue)){
                            // Not used.
                            throw new IllegalStateException ("Unused field: " + childFieldCode)
                        }
                        break
                    case 'MENT9' :      // Member Code
                        throw new IllegalStateException("Unused field: " + childFieldCode)
                        break
                    case 'MENT10' :     //  Industry sector other       (free text)
                        if (hasDataValue(dataValue)){
                            if (tableCode == 'MENTEE') person.industrySectorOther = dataValue
                            else if (tableCode == 'MENT') person.industrySectorOther = dataValue
                        }
                        break;
                    case 'MENT11' :     // Job title                 eg Web Developer
                        if (hasDataValue(dataValue)) person.jobTitle = dataValue
                        break
                    case 'MENT12' :     // email address
                        if (hasDataValue(dataValue)) person.emailAddress = dataValue
                        break
                    case 'MENT13' :     // Registration Date
                        if (hasDataValue(dataValue)){
                            person.registrationDate = sdf.parse(dataValue)
                        }
                        break
                    case 'MENT14' :     // Type of organisation       eg Charity/Not-For-Profit
                        if (hasDataValue(dataValue)){
                            def organisationType = organisationTypes.get(dataValue)
                            if (organisationType == null) throw new IllegalStateException(
                                    "Cannot find OrganisationType of' " + dataValue + "'")
                            if (tableCode == 'MENTEE') person.organisationType = organisationType
                            else if (tableCode == 'MENT') person.organisationType = organisationType
                        }
                        break
                    case 'MENT15' :     // Alias
                        if (hasDataValue(dataValue)) person.alias = dataValue
                        break
                    case 'MENT16' :     // Type of organisation other  (free text)
                        if (hasDataValue(dataValue)){
                            if (tableCode == 'MENTEE') person.organisationTypeOther = dataValue
                            else if (tableCode == 'MENT') person.organisationTypeOther = dataValue
                        }
                        break;
                    case 'MENT17' :     // Highest qualification       A-LEVELS
                        if (hasDataValue(dataValue)){
                            def highestQualification = highestQualifications.get(dataValue)
                            if (highestQualification == null) throw new IllegalStateException(
                                    "Cannot find HighestQualification of' " + dataValue + "'")
                            if (tableCode == 'MENTEE') person.highestQualification = highestQualification
                            else if (tableCode == 'MENT') person.highestQualification = highestQualification
                        }
                        break
                    case 'MENT18' :     // Highest qualification other (free text)
                        if (hasDataValue(dataValue)) person.highestQualificationOther = dataValue
                        break
                    case 'MENT19' :     // Professional qualifications
                        if (hasDataValue(dataValue)) person.professionalQualifications = dataValue
                        break
                    case 'MENT20' :     // Career background / highlights
                        if (hasDataValue(dataValue)) person.careerInfo = dataValue
                        break
                    case 'MENT21' :     // Active
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            boolean active = {
                                if (dataValue == 'Y') true
                                else if (dataValue == 'N') false
                                else throw new IllegalStateException("Cannot understand value '" + dataValue + "' for boolean field.")
                            }
                            if (tableCode == 'MENTEE') person.mentee.active = active
                            else if (tableCode == 'MENT') person.mentor.active = active
                        }
                        break
                    case 'MENT22' :     // Subject                     Physics
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            if (tableCode == 'MENTEE') person.mentee.subject = dataValue
                            else if (tableCode == 'MENT') person.mentor.subject = dataValue
                        }
                        break
                    case 'MENTEE1' :   // Reason for wanting mentor
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            def needMentorReason = needMentorReasons.get(dataValue)
                            if (needMentorReason == null) throw new IllegalStateException(
                                    "Cannot find NeedMentorReason of' " + dataValue + "'")
                            person.mentee.needMentorReason = needMentorReason
                        }
                        break
                    case 'MENTEE2' :   // Mentor
                        if (hasDataValue(dataValue)){
                            def mentor = dataValue.trim()
                            if (recordContactUDs.containsKey(mentor)){
                                menteeMentors = createMenteeMentorsIfNeeded(menteeMentors, recordCode)
                                menteeMentors.actual = mentor
                            }else{
                                System.err.println("Cannot create reference to unknown mentor \"" + mentor + "\" for mentee \"" + recordCode + "\" (" + childFieldCode + ")" )
                            }
                        }
                        break
                    case 'MENTEE3' :   // Preferred Mentor 1
                        if (hasDataValue(dataValue)){
                            def mentor = dataValue.trim()
                            if (recordContactUDs.containsKey(mentor)){
                                menteeMentors = createMenteeMentorsIfNeeded(menteeMentors, recordCode)
                                menteeMentors.preferred1 = mentor
                            }else{
                                System.err.println("Cannot create reference to unknown preferred mentor 1 \"" + mentor + "\" for mentee \"" + recordCode + "\" ("  + childFieldCode + ")" )
                            }
                        }
                        break
                    case 'MENTEE4' :   // Preferred Mentor 2
                        if (hasDataValue(dataValue)){
                            def mentor = dataValue.trim()
                            if (recordContactUDs.containsKey(mentor)){
                                menteeMentors = createMenteeMentorsIfNeeded(menteeMentors, recordCode)
                                menteeMentors.preferred2 = mentor
                            }else{
                                System.err.println("Cannot create reference to unknown preferred mentor 2 \"" + mentor + "\" for mentee \""  + recordCode + "\" (" + childFieldCode + ")")
                            }
                        }
                        break
                    case 'MENTEE5' :   // Preferred Mentor 3
                        if (hasDataValue(dataValue)){
                            def mentor = dataValue.trim()
                            if (recordContactUDs.containsKey(mentor)){
                                menteeMentors = createMenteeMentorsIfNeeded(menteeMentors, recordCode)
                                menteeMentors.preferred3 = mentor
                            }else{
                                System.err.println("Cannot create reference to unknown preferred mentor 3 \"" + mentor + "\" for mentee \""  + recordCode + "\" ("  + childFieldCode + ")")
                            }
                        }
                        break
                    case 'MENTEE6' :   // Are there any particular skills that you want to develop?
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentee.skillsToDevelop = dataValue
                        }
                        break
                    case 'MENTEE7' :   // Gain what from having a mentor
                        if (hasDataValue(dataValue)){
                            throw new IllegalStateException("MENTEE7 is supposed to be unused!")
                        }
                        break // unused field, all contents empty
                    case 'MENTEE8' :   // Mentoring choices submitted date
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            person.mentee.mentorChoiceDate = sdf.parse(dataValue)
                        }
                        break
                    case 'MENTEE9' :   // why do you want a mentor?
                        if (hasDataValue(dataValue)){
                            createMentoreePerson(rec, person)
                            def needMentorReason = needMentorReasons.get(dataValue)
                            if (needMentorReason == null) throw new IllegalStateException(
                                    "Cannot find NeedMentorReason of' " + dataValue + "'")
                            if (tableCode == 'MENTEE') person.mentee.needMentorReason = needMentorReason
                            else if (tableCode == 'MENT') throw new IllegalStateException(
                                    "Cannot have needMentorReason for mentOR !")
                        }
                        break
                    default :
                        if (hasDataValue(dataValue)){
                            throw new IllegalStateException("Unknown value: '" + childFieldCode + "'")
                        }
                        break
                }
            }
            peopleInserted += savePerson(person)
            if (saveMentor(person)){
                updatePersonMentor(person)
                mentorsInserted ++
            }
            if (saveMentee(person)){
                updatePersonMentee(person)
                menteesInserted++
            }
            if (menteeMentors != null) menteeMentorsList.add(menteeMentors)
        }
        println("Created $peopleInserted new person, $mentorsInserted new mentor and $menteesInserted new mentee records")
        return menteeMentorsList
    }

    def updatePersonMentor(Person person) {
        if (person.mentor != null){
            def mentorId, personId
            def inserted = 0
            def sql = "select max(id) max_id from mentor"
            myResultSet = myStatement.executeQuery(sql)
            while (myResultSet.next()) {
                mentorId = myResultSet.getInt("max_id")
            }
            sql = "select max(id) max_id from person"
            myResultSet = myStatement.executeQuery(sql)
            while (myResultSet.next()) {
                personId = myResultSet.getInt("max_id")
            }
            if ( mentorId != null && personId != null){
                sql = "update person set mentor_id = $mentorId where id = $personId"
                inserted = insertOrUpdateRecord(sql)
            }
            if (inserted != 1){
                throw new Exception("Could not update mentor for person with memberCode " + person.memberCode)
            }
        }else{
            throw new Exception("Should have created a mentor record for memberCode " + person.memberCode)
        }
    }

    def updatePersonMentee(Person person) {
        if (person.mentee != null){
            def menteeId, personId
            def inserted = 0
            def sql = "select max(id) max_id from mentee"
            myResultSet = myStatement.executeQuery(sql)
            while (myResultSet.next()) {
                menteeId = myResultSet.getInt("max_id")
            }
            sql = "select max(id) max_id from person"
            myResultSet = myStatement.executeQuery(sql)
            while (myResultSet.next()) {
                personId = myResultSet.getInt("max_id")
            }
            if (menteeId != null && personId != null){
                sql = "update person set mentee_id = $menteeId where id = $personId"
                inserted = insertOrUpdateRecord(sql)
            }
            if (inserted != 1){
                throw new Exception("Could not update mentee for person with memberCode " + person.memberCode)
            }
        }else{
            throw new Exception("Should have created a mentee record for memberCode " + person.memberCode)
        }
    }

    private MenteeMentors createMenteeMentorsIfNeeded(MenteeMentors menteeMentors, recordCode) {
        if (menteeMentors == null){
            menteeMentors = new MenteeMentors()
            menteeMentors.mentee = recordCode
        }
        menteeMentors
    }

    def savePerson(person) {
        def inserted
        def insertSql= "insert into person ("
        def insertValuesSql = " values ("
        insertSql += "alias"
        insertValuesSql = appendFirstValueToSql(insertValuesSql, person.alias)
        insertSql += ", current_responsibilities"
        insertValuesSql = appendValueToSql(insertValuesSql, person.currentResponsibilities)
        insertSql += ", email_address"
        insertValuesSql = appendValueToSql(insertValuesSql, person.emailAddress)
        def firstName, lastName
        if (firstLastNames.containsKey(person.memberCode)){
          firstName = firstLastNames.get(person.memberCode)[0]
          lastName = firstLastNames.get(person.memberCode)[1]
        }
        insertSql += ", first_name"
        insertValuesSql = appendValueToSql(insertValuesSql, firstName)
        insertSql += ", last_name"
        insertValuesSql = appendValueToSql(insertValuesSql, lastName)
        insertSql += ", highest_qualification_other"
        insertValuesSql = appendValueToSql(insertValuesSql, person.highestQualificationOther)
        insertSql += ", industry_sector_other"
        insertValuesSql = appendValueToSql(insertValuesSql, person.industrySectorOther)
        insertSql += ", job_title"
        insertValuesSql = appendValueToSql(insertValuesSql, person.jobTitle)
        insertSql += ", member_code"
        insertValuesSql = appendValueToSql(insertValuesSql, person.memberCode)
        insertSql += ", organisation_type_other"
        insertValuesSql = appendValueToSql(insertValuesSql, person.organisationTypeOther)
        insertSql += ", professional_qualifications"
        insertValuesSql = appendValueToSql(insertValuesSql, person.professionalQualifications)
        insertSql += ", career_info"
        insertValuesSql = appendValueToSql(insertValuesSql, person.careerInfo)
        insertSql += ", registration_date"
        if (person.registrationDate != null){
            def formattedDate = sdf.format(person.registrationDate)
            insertValuesSql += ", STR_TO_DATE('$formattedDate','%M %d %Y')"
        }else{
            def formattedDate = sdf.format(new java.util.Date())
            insertValuesSql += ", STR_TO_DATE('$formattedDate','%M %d %Y')"
        }
        insertSql += ", version"
        insertValuesSql += ", 1"
        if (person.industrySector){
            insertSql += ", industry_sector_id"
            insertValuesSql += ", $person.industrySector.id"
        }
        if (person.highestQualification){
            insertSql += ", highest_qualification_id"
            insertValuesSql += ", $person.highestQualification.id"
        }
        if (person.organisationType){
            insertSql += ", organisation_type_id"
            insertValuesSql += ", $person.organisationType.id"
        }
        insertSql += ", super_user"
        insertValuesSql += ", false"
        insertSql += ", suspended"
        insertValuesSql += ", false"
        def sql = insertSql + ")" + insertValuesSql + ")"
        inserted = insertOrUpdateRecord(sql)
        return inserted
    }

    private insertOrUpdateRecord(String sql) {
        def inserted
        try {
            inserted = myStatement.executeUpdate(sql)
        } catch (Exception e) {
            e.printStackTrace()
            System.err.println(e.getMessage())
            throw (e)
        }
        inserted
    }

    def saveMentor(Person person){
        if (person.mentor != null){
            myResultSet = myStatement.executeQuery("select id from preferred_meeting_format where name = 'In Person'")
            def pmf_id
            while (myResultSet.next()) {
                pmf_id = myResultSet.getInt("id")
            }
            if (pmf_id != null){
                def insertSql= "insert into mentor ("
                def insertValuesSql = " values ("
                insertSql += "reason"
                insertValuesSql = appendFirstValueToSql(insertValuesSql, person.mentor.reason)
                insertSql += ", experienced"
                insertValuesSql += person.mentor.experienced ? ", true" : ", false"
                insertSql += ", max_mentees"
                insertValuesSql += ", $person.mentor.maxMentees"
                insertSql += ", active"
                insertValuesSql += person.mentor.active ? ", true" : ", false"
                insertSql += ", subject"
                insertValuesSql = appendValueToSql(insertValuesSql, person.mentor.subject)
                insertSql += ", specialist_skills"
                insertValuesSql = appendValueToSql(insertValuesSql, person.mentor.specialistSkills)
                insertSql += ", version"
                insertValuesSql += ", 1"
                def sql = insertSql + ")" + insertValuesSql + ")"
                def inserted = insertOrUpdateRecord(sql)
                return inserted
            }
        }
    }

    def int saveMentorPreferredMeetingFormat(mentorId, pmfId) {
        def insertSql = "insert into mentor_preferred_meeting_format (mentor_preferred_meeting_formats_id, preferred_meeting_format_id) values ($mentorId, $pmfId)"
        def inserted = insertOrUpdateRecord(insertSql)
        if (inserted != 1) {
            System.err.println("Could not insert mentor_preferred_meeting_format record for mentor $mentorId, pmf: $pmfId")
        }
        inserted
    }

    def saveMentee(Person person){
        if (person.mentee != null){
            def inserted = 0
            def insertSql= "insert into mentee ("
            def insertValuesSql = " values ("
            insertSql += "subject"
            insertValuesSql = appendFirstValueToSql(insertValuesSql, person.mentee.subject)
            insertSql += ", skills_to_develop"
            insertValuesSql = appendValueToSql(insertValuesSql, person.mentee.skillsToDevelop)
            if (person.mentee.mentorChoiceDate != null){
                insertSql += ", mentor_choice_date"
                def formattedDate = sdf.format(person.mentee.mentorChoiceDate)
                insertValuesSql += ", STR_TO_DATE('$formattedDate','%M %d %Y')"
            }
            if (person.mentee.needMentorReason != null){
                insertSql += ", need_mentor_reason_id"
                insertValuesSql += ", $person.mentee.needMentorReason.id"
            }
            insertSql += ", active"
            insertValuesSql += person.mentee.active ? ", true" : ", false"
            insertSql += ", matched"
            insertValuesSql += ", false"
            insertSql += ", version"
            insertValuesSql += ", 1"
            def sql = insertSql + ")" + insertValuesSql + ")"
            inserted = insertOrUpdateRecord(sql)
            return inserted
        }
    }

    private String appendValueToSql(String insertValuesSql, String value) {
        return appendValueToSql(insertValuesSql, value, false)
    }

    private String appendFirstValueToSql(String insertValuesSql, String value) {
        return appendValueToSql(insertValuesSql, value, true)
    }

    private String appendValueToSql(String insertValuesSql, String value, boolean first) {
        if (value == null || value.length() == 0){
            value = ""
        }else{
            value = value.replaceAll("\"", "'")
        }
        if (first) insertValuesSql += "\"$value\""
        else insertValuesSql += ", \"$value\""
        insertValuesSql
    }

    def createMentoreePerson(rec, person){
        String tableCode = rec.tableCode
        tableCode = tableCode.trim()
        if (tableCode == 'MENTEE'){
            if(person.mentee == null) person.mentee = new Mentee()
        }else if (tableCode == 'MENT'){
            if(person.mentor == null) person.mentor = new Mentor()
        }
    }

    def boolean hasDataValue(String dataValue) {
        dataValue != null && dataValue.trim().length() > 0
    }

    def loadRecordContactUDs() throws SQLException {
        msResultSet = msStatement.executeQuery(
                "select RecordCode, ContactCounter, TableCode, ChildFieldCode, DataValue from RecordContactUD where TableCode like 'MENT%' and len(ltrim(rtrim(RecordCode))) > 0 order by RecordCode, TableCode, ChildFieldCode");
        Map<String, List<RecordContactUD>> recordContactUDs = new HashMap<String, List<RecordContactUD>>();
        def recordCode, lastRecordCode = ""
        List<RecordContactUD> recordContactUDList
        RecordContactUD recordContactUD

        while (msResultSet.next()) {
            recordCode = msResultSet.getString("RecordCode").trim()
            if (recordCode != lastRecordCode){
                recordContactUDList = new ArrayList<RecordContactUD>();
                recordContactUDs.put(recordCode, recordContactUDList)
            }
            recordContactUD = new RecordContactUD()
            recordContactUD.recordCode = recordCode
            recordContactUD.contactCounter = msResultSet.getInt("ContactCounter")
            recordContactUD.tableCode = msResultSet.getString("TableCode")
            recordContactUD.childFieldCode = msResultSet.getString("ChildFieldCode")
            recordContactUD.dataValue = msResultSet.getString("DataValue")
            recordContactUDList.add(recordContactUD)
            if (recordContactUD.childFieldCode == 'MENT1') addIndustrySector(recordContactUD.dataValue)
            if (recordContactUD.childFieldCode == 'MENT14') addOrganisationType(recordContactUD.dataValue)
            if (recordContactUD.childFieldCode == 'MENT17') addHighestQualification(recordContactUD.dataValue)
            if (recordContactUD.childFieldCode == 'MENTEE9') addNeedMentorReason(recordContactUD.dataValue)
            lastRecordCode = recordCode
        }
        return recordContactUDs
    }

    def addIndustrySector(String value){
        if (hasDataValue(value) && !industrySectors.containsKey(value)){
            IndustrySector industrySector = new IndustrySector()
            industrySector.name = value
            int inserted
            try{
                inserted = myStatement.executeUpdate("insert into industry_sector(name, version) values ('" + value + "', 1)")
            }catch (Exception e){
                System.err.println(e.getMessage())
                throw (e)
            }
            if (inserted){
                industrySectors.put(value, industrySector)
            }else{
                throw new RuntimeException("Could not create industry_sector record for '" + value + "'")
            }
        }
    }

    def addOrganisationType(String value){
        if (hasDataValue(value) && !organisationTypes.containsKey(value)){
            OrganisationType organisationType = new OrganisationType()
            organisationType.name = value
            int inserted
            try{
                inserted = myStatement.executeUpdate("insert into organisation_type(name, version) values ('" + value + "', 1)")
            }catch (Exception e){
                System.err.println(e.getMessage())
                throw (e)
            }
            if (inserted){
                organisationTypes.put(value, organisationType)
            }else{
                throw new RuntimeException("Could not create organisation_type record for '" + value + "'")
            }
        }
    }

    def addHighestQualification(String value){
        if (hasDataValue(value) && !highestQualifications.containsKey(value)){
            HighestQualification highestQualification = new HighestQualification()
            highestQualification.name = value
            int inserted
            try{
                inserted = myStatement.executeUpdate("insert into highest_qualification(name, version) values ('" + value + "', 1)")
            }catch (Exception e){
                System.err.println(e.getMessage())
                throw (e)
            }
            if (inserted){
                highestQualifications.put(value, highestQualification)
            }else{
                throw new RuntimeException("Could not create highest_qualification record for '" + value + "'")
            }
        }
    }

    def addNeedMentorReason(String value){
        if (hasDataValue(value) && !needMentorReasons.containsKey(value)){
            NeedMentorReason needMentorReason = new NeedMentorReason()
            needMentorReason.reason = value
            int inserted
            try{
                inserted = myStatement.executeUpdate("insert into need_mentor_reason(reason, version) values ('" + value + "', 1)")
            }catch (Exception e){
                System.err.println(e.getMessage())
                throw (e)
            }
            if (inserted){
                needMentorReasons.put(value, needMentorReason)
            }else{
                throw new RuntimeException("Could not create need_mentor_reason record for '" + value + "'")
            }
        }
    }

    def addPreferredMeetingFormats(){
        String[][] values = [['Phone',1], ['Video Conferencing',2], ['In Person', 4], ['Any', 7] ]
        def value, bitmap
        for (int i = 0; i < 4; i++){
            int inserted
            try{
                value = values[i][0]
                bitmap = values[i][1]
                inserted = myStatement.executeUpdate("insert into preferred_meeting_format(name, version, bitmap) values ('$value', 1, $bitmap )")
            }catch (Exception e){
                System.err.println(e.getMessage())
                throw (e)
            }
            if (inserted){
                preferredMeetingFormats.put(value, new PreferredMeetingFormat(value))
            }else{
                throw new RuntimeException("Could not create preferred_meeting_format record for '" + value + "'")
            }
        }
    }

    def loadFirstLastNames(){
        msResultSet = msStatement.executeQuery(
                "select distinct Member_Code, Primary_First_Name, Primary_Surname\n" +
                        "from RecordContactUD\n" +
                        "  inner join ME_Member_Master\n" +
                        "    on RecordCode = Member_Code\n" +
                        "where TableCode like 'MENT%'" +
                        "  and Member_Code is not null and len(ltrim(rtrim(Member_Code))) > 0")
        firstLastNames = new HashMap ()
        while (msResultSet.next()) {
            firstLastNames.put(msResultSet.getString("Member_Code"), [msResultSet.getString("Primary_First_Name"), msResultSet.getString("Primary_Surname")])
        }
        return firstLastNames
    }

    def loadAddresses() throws SQLException {
        loadCountriesIfNecessary()
        msResultSet = msStatement.executeQuery(
                "select distinct mc.Member_Code, ExtAddress1,ExtAddress2,ExtAddress3,ExtAddress4,ExtAddress5,ExtAddress6, Town_Description, Post_Zip, Country_Code\n" +
                        "from RecordContactUD rc\n" +
                        "  inner join ME_Member_Contacts mc\n" +
                        "    on ContactCounter = Contact_Counter\n" +
                        "       and RecordCode = Member_Code\n" +
                        "  inner join ME_Member_Address ma\n" +
                        "    on ma.Member_Code = mc.Member_Code\n" +
                        "       and ma.Address_Seq = mc.Address_Seq\n" +
                        "  left outer join GL_TOWN t\n" +
                        "    on ma.Town_Code = t.Town_Code\n" +
                        "where TableCode like 'MENT%'\n" +
                        "      and mc.Member_Code = ma.Member_Code");
        Map<String, Address> addresses = new HashMap<String, Address>();
        Address address
        def missing = 0
        while (msResultSet.next()) {
            address = new Address()
            address.memberCode = msResultSet.getString("Member_Code")
            address.extAddress1 = msResultSet.getString("ExtAddress1")
            address.extAddress2 = msResultSet.getString("ExtAddress2")
            address.extAddress3 = msResultSet.getString("ExtAddress3")
            address.extAddress4 = msResultSet.getString("ExtAddress4")
            address.extAddress5 = msResultSet.getString("ExtAddress5")
            address.extAddress6 = msResultSet.getString("ExtAddress6")
            address.townCity = msResultSet.getString("Town_Description")
            address.postZip = msResultSet.getString("Post_Zip")
            def countryCode = msResultSet.getString("Country_Code")
            // Correct UK to GB for correct country code.
            address.countryCode = (countryCode == "UK" ? "GB" : countryCode)
            if (loadLatLng(address)){
                addresses.put(address.memberCode, address)
                sleep(500)
            } else missing++
        }
        println("Addresses: found " + addresses.size() + ", missing " + missing)
        return addresses
    }

    def loadLatLng(Address address){
        def success = false
        // The following 3 lines are to be used during DEBUGGING ONLY! They replce the rest of this function, which does the real work.
        /*address.latitude = 1
        address.longitude = 1
        success = true*/
        if (hasDataValue(address.postZip)){
            success = populateLatLng(address, address.postZip)
        }
        if (!success){
            // try to find using other address details.
            def concatenatedAddress = getConcatenatedAddress(address)
            success = populateLatLng(address, concatenatedAddress)
            if (!success){
                if (memberLatLng.containsKey(address.memberCode)){
                    def manualLatLng = memberLatLng.get(address.memberCode)
                    address.latitude = manualLatLng[0]
                    address.longitude = manualLatLng[1]
                    success = true
                }
            }
            if (!success){
                // cannot lookup up, so set lat/lng to 0,0
                address.latitude = 0
                address.longitude = 0
            }
        }
        success
    }

    private boolean populateLatLng(Address address, String searchStr) {
        def success = false
        def results
        results = GeocodingService.getLatLong(searchStr, address.countryCode)
        if (results != null && results.size() == 1) {
            // 1 geo-location found, so use it to search address lat/lng and formatted address
            def (lat, lng, place) = results[0]
            address.latitude = lat
            address.longitude = lng
            success = true
        }
        success
    }

    def getConcatenatedAddress(Address address){
        def sb = new StringBuilder("")
        if (hasDataValue(address.extAddress1)){
            sb.append(address.extAddress1)
        }
        if (hasDataValue(address.extAddress2)){
            if (sb.length() > 0) sb.append(", ")
            sb.append(address.extAddress2)
        }
        if (hasDataValue(address.extAddress3)){
            if (sb.length() > 0) sb.append(", ")
            sb.append(address.extAddress3)
        }
        if (hasDataValue(address.extAddress4)){
            if (sb.length() > 0) sb.append(", ")
            sb.append(address.extAddress4)
        }
        if (hasDataValue(address.extAddress5)){
            if (sb.length() > 0) sb.append(", ")
            sb.append(address.extAddress5)
        }
        if (hasDataValue(address.extAddress6)){
            if (sb.length() > 0) sb.append(", ")
            sb.append(address.extAddress6)
        }
        sb.toString()
    }

    def loadCountriesIfNecessary(){
        myResultSet = myStatement.executeQuery("select count(*) total from country");
        def countryCount = 0
        while (myResultSet.next()) {
            countryCount = myResultSet.getInt("total")
        }
        if (countryCount == 0){
            def countries = CountryPopulator.populate()
            def inserted = 0
            for (def country : countries){
               inserted += insertOrUpdateRecord("insert into country (name, code, version) values (\"$country.name\", '$country.code', 1)")
            }
            println("Inserted $inserted country records")
        }
    }

    def updateEmployerNames(){
        myResultSet = myStatement.executeQuery("select member_code from person");
        def memberCodes = []
        def updated
        def empNameUpdCount = 0
        while (myResultSet.next()) {
            memberCodes.add(myResultSet.getString("member_code"))
        }
        def employerName
        for (def memberCode : memberCodes){
            employerName = ""
            def sql =
                "SELECT      TOP 1 Primary_Name \n" +
                "FROM              dbo.ME_Member_Relationship MR \n" +
                "INNER JOIN        dbo.ME_Member_Master MM ON MM.Member_Code = MR.Parent_Member_Code \n" +
                "LEFT OUTER JOIN dbo.ME_Member_Address MMA ON MM.Member_Code = MMA.Member_Code \n" +
                "AND                     MMA.Primary_Address = 1 \n" +
                "AND                     MMA.Active = 1 WHERE (MR.Child_Member_Code = '$memberCode')" +
                "AND                     MR.Parent_Title_Name = 'Employer'" +
                "AND                     MR.Relationship_To_Date > GETDATE()"
            msResultSet = msStatement.executeQuery(sql);
            while (msResultSet.next()){
                employerName = msResultSet.getString("Primary_Name").trim()
            }
            if (employerName != null && employerName.length() > 0){
                // update the person record
                updated = insertOrUpdateRecord("update person set employer = \"$employerName\" where member_code = '$memberCode'")
                if (updated) empNameUpdCount++
            }
        }
        println("Updated $empNameUpdCount person records with employer name")
    }

    /* Use the data stored in the List of MenteeMentors to create entries in the preferred_mentor table
     */
    def saveMentorMenteeRecords(List<MenteeMentors> menteeMentorsList){
        //  Load the newly allocated IDs for mentor/mentee records.
        myResultSet = myStatement.executeQuery("select mentor_id, member_code from person p inner join mentor m on p.mentor_id = m.id")
        def memberCodeMentorIds = loadMemberCodeMentoreeIds(myResultSet, "mentor_id")
        myResultSet = myStatement.executeQuery("select mentee_id, member_code from person p inner join mentee m on p.mentee_id = m.id")
        def memberCodeMenteeIds = loadMemberCodeMentoreeIds(myResultSet, "mentee_id")
        def pm_inserted = 0
        def mm_inserted = 0
        // For each mentee in the List of MenteeMentors, insert preferred_mentor and update the mentor_mentee table as necessary.
        for (MenteeMentors menteeMentor : menteeMentorsList){
            def menteeId = memberCodeMenteeIds.get(menteeMentor.mentee)
            if (menteeId == null){
               throw new Exception ("Cannot find id for mentee with member code " + menteeMentor.mentee)
            }
            if (menteeMentor.actual != null){
                def actualMentorId = memberCodeMentorIds.get(menteeMentor.actual)
                if (actualMentorId != null){
                    mm_inserted += insertOrUpdateRecord("insert into mentor_mentee (mentor_id, mentee_id)  values (" +
                            actualMentorId + ", "  + menteeId + ")")
                }
            }
            if (menteeMentor.preferred1 != null){
                pm_inserted += insertPreferredMentor(memberCodeMentorIds.get(menteeMentor.preferred1), menteeId)
            }
            if (menteeMentor.preferred2 != null){
                pm_inserted += insertPreferredMentor(memberCodeMentorIds.get(menteeMentor.preferred2), menteeId)
            }
            if (menteeMentor.preferred3 != null){
                pm_inserted += insertPreferredMentor(memberCodeMentorIds.get(menteeMentor.preferred3), menteeId)
            }
        }
        println("Inserted " + mm_inserted + " mentor_mentee records and inserted " + pm_inserted + " preferred_mentor records")
    }

    private int insertPreferredMentor(preferredMentorId, menteeId) {
        def inserted = 0
        if (preferredMentorId != null) {
            inserted = insertOrUpdateRecord("insert into preferred_mentor (mentee_id, mentor_id, version) values (" +
                    menteeId + ", " + preferredMentorId + ", 1 )")
        }
        inserted
    }

    /*
      In the future mentoring system, mentors will be able to state a preferred meeting type of phone, video-conferencing or in-person.
      If they chose the latter, they must state one (or more) preferred locations.
      For the purposes of data migration we will treat all existing mentors as preferring in-person meetings at one
      location, taken from their current address.
     */
    def savePreferredMeetingFormatsAndMentoringLocations(){
        def count = 0
        for (String memberCode : addresses.keySet()){
            def inPersonId = preferredMeetingFormats.get("In Person").id
            def changed = updateMentorPreferredMeetingFormatToInPerson(memberCode, inPersonId)
            if (changed == 1){
                changed = insertMentoringLocation(memberCode)
                if (changed == 1){
                    changed = updateMentorMentoringLocation(memberCode)
                    if (changed == 1) count++
                }
            }
        }
        println("Created " + count + " mentor locations")
    }

    private int updateMentorPreferredMeetingFormatToInPerson(memberCode, inPersonId){
        def inserted = 0
        def sql = "select mentor_id from person where member_code = '$memberCode'"
        def mentorId
        myResultSet = myStatement.executeQuery(sql)
        while (myResultSet.next()) {
            mentorId = myResultSet.getInt("mentor_id")
        }
        if (memberCode != null && mentorId != null && mentorId > 0) {
            inserted = saveMentorPreferredMeetingFormat(mentorId, inPersonId)
        }
        inserted
    }

    def int insertMentoringLocation(memberCode){
        def address = addresses.get(memberCode)
        if (address.countryCode == null || (address.latitude == 0 && address.longitude == 0)){
            return 0
        }
        String sql = createInsertLocationSqlFromAddress(address)
        def inserted = 0
        if (sql != null){
            inserted = insertOrUpdateRecord(sql)
        }
        return inserted
    }

    private String createInsertLocationSqlFromAddress(Address address) {
        myResultSet = myStatement.executeQuery("select id from country where code = '$address.countryCode'")
        def country_id
        while (myResultSet.next()) {
            country_id = myResultSet.getInt("id")
        }
        if (country_id != null){
            def sql =
                "insert into location(address_line1, address_line2, town_city, post_zip, country_id, version, latitude, longitude) values ("
            sql += addTextPhrase(address.extAddress1, address.extAddress2) + ", "
            sql += addTextPhrase(address.extAddress3, address.extAddress4) + ", "
            sql += addTextPhrase(address.townCity) + ", "
            sql += addTextPhrase(address.postZip) + ", "
            sql += country_id + ", 1, "
            sql += address.latitude + ", "
            sql += address.longitude + ")"
            sql
        }
    }

    def String addTextPhrase(String phrase){
        phrase == null ? "null" : "\"" + phrase + "\""
    }

    def String addTextPhrase(String phrase1, String phrase2){
        def outPhrase
        if (phrase1 == null && phrase2 == null){
            outPhrase = "null"
        }else{
            if (phrase1 != null){
                outPhrase = "\"" + phrase1
                if (phrase2 != null){
                    outPhrase += ", " + phrase2 + "\""
                }else{
                    outPhrase += "\""
                }
            }else{
                outPhrase = "\"" + phrase2 + "\""
            }
        }
        outPhrase
    }

    def updateMentorMentoringLocation(memberCode){
        def location_id
        location_id = getLatestInsertedLocationId()
        def mentor_id
        def sql = "select mentor_id from person where member_code = '" + memberCode + "'"
        myResultSet = myStatement.executeQuery(sql)
        while (myResultSet.next()) {
            mentor_id = myResultSet.getInt("mentor_id")
        }
        sql = "update mentor set location_id = $location_id where id = $mentor_id"
        def updated = insertOrUpdateRecord(sql)
        if (updated != 1){
            throw new Exception("Could not update mentor record with location_id $location_id for person/mentor with memberCode " +memberCode)
        }
        updated
    }

    private int getLatestInsertedLocationId() {
        def location_id
        def sql = "select max(id) max_id from location"
        myResultSet = myStatement.executeQuery(sql)
        while (myResultSet.next()) {
            location_id = myResultSet.getInt("max_id")
        }
        location_id
    }

    private loadMemberCodeMentoreeIds(ResultSet myResultSet, idFieldName) {
        Map<String, String> memberCodeMentoreeIds = new HashMap<String, String>()
        def key, value
        while (myResultSet.next()) {
            key = myResultSet.getString("member_code")
            value = myResultSet.getInt(idFieldName)
            if (key != null && value != null) {
                memberCodeMentoreeIds.put(key, value)
            }
        }
        memberCodeMentoreeIds
    }

     def saveMenteeLocation(){
        def count = 0
        def inserted, updated
        for (String memberCode : addresses.keySet()){
            def address = addresses.get(memberCode)
            if (address.countryCode != null && address.latitude != 0 && address.longitude != 0){
                String sql = createInsertLocationSqlFromAddress(address)
                inserted = insertOrUpdateRecord(sql)
                if (inserted == 1){
                    def location_id = getLatestInsertedLocationId()
                    sql = "update mentee set location_id = " + location_id + " where id = (select mentee_id from person where member_code = '" +
                        address.memberCode + "')"
                    updated = insertOrUpdateRecord(sql)
                    if (updated == 1) count++
                }
            }
        }
        println("Created " + count + " mentee locations")
    }

    def summary(){
        println "\nSUMMARY OF DATA INSERTED\n"
        def tables =
            ["preferred_mentor", "person", "mentee", "mentor", "mentor_mentee", "preferred_mentor",
             "location", "industry_sector", "need_mentor_reason", "highest_qualification", "organisation_type",
             "preferred_meeting_format", "mentor_preferred_meeting_format"]
        for (def table : tables){
            myResultSet = myStatement.executeQuery("select count(*) total from $table")
            def total = 0
            while (myResultSet.next()) {
                total = myResultSet.getInt("total")
            }
            println "$table : $total records"
        }
    }

    class RecordContactUD{
        String recordCode
        int contactCounter
        String tableCode
        String childFieldCode
        String dataValue
        Address address
    }

    class Address {
        String memberCode
        String extAddress1
        String extAddress2
        String extAddress3
        String extAddress4
        String extAddress5
        String extAddress6
        String townCity
        String postZip
        String countryCode
        double latitude
        double longitude
    }

    class MenteeMentors {
        String mentee
        String actual
        String preferred1
        String preferred2
        String preferred3
    }

    private void close() {
        try {
            if (msResultSet != null) msResultSet.close();
            if (msStatement != null) msStatement.close();
            if (msConnect != null) msConnect.close();
            if (myResultSet != null) myResultSet.close();
            if (myStatement != null) myStatement.close();
            if (myConnect != null) myConnect.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private populateMemberLatLng(){
        memberLatLng.put("1073065", [25.8881056,51.5428304])
        memberLatLng.put("1078860", [53.3349547,-6.2506218])
        memberLatLng.put("1079325", [59.3659222,18.0562459])
        memberLatLng.put("1091996", [53.3551451,-6.3738191])
        memberLatLng.put("1093632", [5.5687849,-0.1967239])
        memberLatLng.put("1093719", [38.6487895,-90.3107962])
        memberLatLng.put("1109202", [50.4693850,4.1892216])
        memberLatLng.put("1112395", [51.4955800,11.9419300 ])
        memberLatLng.put("1117999", [37.9719140,23.7165550])
        memberLatLng.put("1118769", [5.5687849,-0.1967239])
        memberLatLng.put("1137281", [7.932925,4.7265243])
        memberLatLng.put("56874", [17.4575574,78.3333750])
        memberLatLng.put("571097", [45.5415991,-73.5985092])
        memberLatLng.put("577161", [53.5178630,-6.4029925])
        memberLatLng.put("579655", [51.9899094,4.3753215])
        memberLatLng.put("60843", [1.3900470,103.8364870])
        memberLatLng.put("80001854", [4.5385355,101.1129395])
        memberLatLng.put("80002198", [7.2986764,5.1453383])
        memberLatLng.put("80018207", [25.3471579,49.5963688])
        memberLatLng.put("80022005", [-26.1897750,28.0316775])
        memberLatLng.put("80023349", [25.6439368,-100.2891151])
        memberLatLng.put("80024266", [-23.8883300,29.7386299])
        memberLatLng.put("80029206", [5.5557169,-0.1963060])
        memberLatLng.put("1096206", [6.5134247,3.3873198])
        memberLatLng.put("1107793", [6.6623110,-1.6036253])
        memberLatLng.put("1109676", [-33.4280046,-70.6183996])
        memberLatLng.put("60020273", [44.41653,26.05834])
        memberLatLng.put("80013329", [7.7333333,4.4333333])
        memberLatLng.put("80021816", [-26.2264282,27.8747336])
        memberLatLng.put("80022740", [22.8874202,84.1382368])
        memberLatLng.put("80023932", [8.5658780,7.7268755])
        memberLatLng.put("80024603", [8.4827657,4.5369686])
        memberLatLng.put("80045465", [22.2604140,84.8682360])
        memberLatLng.put("80050208", [29.9805607,76.8447080])
    }
}
