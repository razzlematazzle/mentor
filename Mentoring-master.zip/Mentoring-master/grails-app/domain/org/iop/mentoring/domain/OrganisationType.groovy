package org.iop.mentoring.domain

class OrganisationType {

    private static String NA = "N/A"
    String name

    static def getNames() {
        return listOrderByName()
    }

    static def getDefault(){
        return OrganisationType.findByName(NA)
    }

}
