Mentoring
=========

The main documentation can be found under grails-app/documents/documentation.md
