package org.iop.mentoring.controllers

import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Mentor
import org.iop.mentoring.domain.MentoringRequest
import org.iop.mentoring.domain.Person
import org.iop.mentoring.domain.PreferredMentor
import org.iop.mentoring.services.PreferredMentorService
import org.iop.mentoring.services.SecurityService
import org.iop.mentoring.services.UserInfo

class MenteeController {

    def SecurityService securityService

    def PreferredMentorService preferredMentorService

    def MANAGE_PREFERRED_MENTORS_ACTION = "managePMs"
    def APPLY_TO_MENTOR_ACTION = "apply"
    def SET_PREFERRED_MENTOR_ACTION = "prefer"

    def actions = { SearchCommand sc ->
        if (!params.id){
            throw new RuntimeException('System error: cannot find mentee - no id provided!')
        }
        flash.message = "" // reset
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            def requestedPersonMentor = Person.get(Long.parseLong(params.id))
            def requestingPersonMentee = Person.get(id)
            if (!requestedPersonMentor) {
                render( view: "/error", text: 'System error: cannot find person with id ' + params.id)
            }else{
                if (params.containsKey(APPLY_TO_MENTOR_ACTION)){
                    actionApplyToMentor(requestedPersonMentor, requestingPersonMentee)
                }else if (params.containsKey(SET_PREFERRED_MENTOR_ACTION)){
                    actionSetPreferredMentorAction(requestingPersonMentee, requestedPersonMentor, status, sc, u)
                }else if (params.containsKey(MANAGE_PREFERRED_MENTORS_ACTION)){
                    def preferredMentors = requestingPersonMentee.mentee.preferredMentors
                    def preferredPersonMentors = requestingPersonMentee.findPreferredMentorPersons()
                    showManagePreferredMentors(preferredMentors, preferredPersonMentors, status)
                    return
                }else{
                    throw new RuntimeException("System error: cannot understand action required by looking at params: $params")
                }
            }
        }else{
            // Not a registered mentee, so redirect to home mentoring screen
            redirect(url: HomeController.MENTORING_URL)
        }

    }

    private void showManagePreferredMentors(requestingPersonMentee, preferredPersonMentors, status, assignedMentorNames, preferredMentorNames) {
        def sorted = new TreeMap()
        preferredPersonMentors.each {
            sorted.put(it.lastName, it)
        }
        def requested = MentoringRequest.findByRequester(requestingPersonMentee)
        def requestedById = new HashMap()
        for (MentoringRequest mentoringRequest : requested){
            requestedById.put(mentoringRequest.mentorRequested.id, mentoringRequest)
        }
        render(view: "/mentee/preferredMentors", model: [preferredPersonMentorsSorted: sorted, requested: requestedById, status: status, assignedMentorNames: assignedMentorNames, preferredMentorNames: preferredMentorNames])
    }

    private void actionSetPreferredMentorAction(Person requestingPersonMentee, Person requestedPersonMentor, status, SearchCommand sc, UserInfo u) {
        // Get the existing preferred Mentors, if any.
        def mentee = requestingPersonMentee.mentee
        def preferredMentors = mentee.getPreferredMentors()
        // Get details of the chosen Mentor
        def mentor = requestedPersonMentor.mentor
        def firstName = requestedPersonMentor.firstName
        if (preferredMentors?.size() == 0) {
            addPreferredMentor(mentor, mentee)
            flash.message = "$firstName has been added to your list of preferred mentors"
        } else {
            if (PreferredMentor.contains(mentor, mentee)) {
                flash.message = "$firstName is already one of your preferred mentors!"
            } else {
                // Add the newly preferred mentor to the existing list, assigning it as last choice.
                if (preferredMentors.size() < PreferredMentor.MAX_ALLOWED_PREFERRED_MENTORS) {
                    addPreferredMentor(mentor, mentee)
                    flash.message = "$firstName has been added to your list of preferred mentors"
                } else {
                    flash.message = "You already have the maximum allowed number of preferred mentors ($PreferredMentor.MAX_ALLOWED_PREFERRED_MENTORS). Click on 'Manage Preferred Mentors' to change them"
                }
            }
        }
        removeActionNameParams()
        if (preferredMentors?.size() > 0) {
            render(view: "/mentor/show", model: [person: requestedPersonMentor, mentor: mentor, showApply: true, showManagePMs: true,
                    menteesAllocated: mentor.getMentees(), params: params, status: status, sc: sc, requestingPersonMentee: requestingPersonMentee,
                    assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        } else {
            render(view: "/mentor/show", model: [person: requestedPersonMentor, mentor: mentor, showApply: true,
                    menteesAllocated: mentor.getMentees(), params: params, status: status, sc: sc, requestingPersonMentee: requestingPersonMentee,
                    assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }
        return
    }

    def managePMs(){
        flash.message = "" // reset
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, menteeId = u.menteeId
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            // We should have a param that begins with "apply-" or "delete-"
            for (def param : params){
                def preferredMentorId
                // There will be a param key which starts with "apply-" or "delete-", followed by the ID which has to be stripped out.
                if (param.key.startsWith("apply-")){
                    preferredMentorId = param.key.substring(6)
                    def requestedPersonMentor = Person.findByMentor(Mentor.get(preferredMentorId))
                    def requestingPersonMentee = Person.get(id)
                    params.remove(param.key)
                    actionApplyToMentor(requestedPersonMentor, requestingPersonMentee)
                    return
                }else if (param.key.startsWith("delete-")){
                    preferredMentorId = param.key.substring(7)
                    preferredMentorService.deletePreferredMentor(menteeId, preferredMentorId)
                    def preferredPersonMentor = Person.findByMentor(Mentor.findById(preferredMentorId))
                    params.remove(param.key)
                    flash.message = "$preferredPersonMentor.firstName $preferredPersonMentor.lastName successfully removed mentor from you preferred list"
                    redirect(controller: "admin", action: "index")
                    return
                }
            }
            throw new RuntimeException("System error: cannot find a preferred mentor to manage in function managePMs")
            return
        }
    }

    private void actionApplyToMentor(Person requestedPersonMentor, Person requestingPersonMentee) {
        params.put("requestedPersonMentorId", requestedPersonMentor.id)
        params.put("requestingPersonMenteeId", requestingPersonMentee.id)
        forward(controller: "mentoringRequest", action: "create", params: getParams())
    }

    // Remove params, otherwise more than one button will appear to have been clicked when user selects one.
    private void removeActionNameParams() {
        params.remove(APPLY_TO_MENTOR_ACTION)
        params.remove(SET_PREFERRED_MENTOR_ACTION)
        params.remove(MANAGE_PREFERRED_MENTORS_ACTION)
    }

    // Attempt to add this Mentor to the list of preferred Mentors.
    private void addPreferredMentor(Mentor mentor, Mentee mentee) {
        def newPreferredMentor = new PreferredMentor()
        newPreferredMentor.mentor = mentor
        newPreferredMentor.mentee = mentee
        if (!newPreferredMentor.save()) {
            throw new RuntimeException("System error: cannot save newly preferred mentor record - $newPreferredMentor.errors")
        }
        mentee.getPreferredMentors().add(newPreferredMentor)
        if (!mentee.save(flush: true, failOnError: true)) {
            throw new RuntimeException("System error: cannot save newly preferred mentor record - mentee.errors")
        }
    }
}
