package org.iop.mentoring.services

class ReportResult {
    BigDecimal personId
    String memberCode
    BigDecimal mentorId
    BigDecimal menteeId
    String firstName
    String lastName
    Date significantDate
    int duration
}