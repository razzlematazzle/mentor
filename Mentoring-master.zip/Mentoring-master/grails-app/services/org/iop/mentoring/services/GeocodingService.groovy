package org.iop.mentoring.services

import groovy.json.JsonSlurper
import org.apache.commons.logging.LogFactory

/**
 *  Service which constructs queries to the Google Maps API, runs them and processes the results.
 */
class GeocodingService {

    static urlBase = "http://maps.googleapis.com/maps/api/geocode/json?sensor=false"
    static urlRegionPhrase = "&region="
    static urlAddressPhrase = "&address="

    // Set max/min boundaries for geo-location of UK & Ireland
    private static BigDecimal MAX_LAT = 60.75
    private static BigDecimal MIN_LAT = 49.1
    private static BigDecimal MAX_LNG = 1.8
    private static BigDecimal MIN_LNG = -10.5

    public static getLatLong(String place, String countryCode) {
        def fullResults = CacheService.get(place)
        if (!fullResults){
            // Check whether cache contains place, despite returning 0 location results (ie if it does, then place is outside UK/ROI)
            if (!CacheService.contains(place)){
                def inUkRoi = countryCode != null && countryCode.length() == 2 && (countryCode == 'UK' || countryCode == 'IE')
                fullResults = new ArrayList<String>()
                String urlStr = urlBase + urlAddressPhrase + (URLEncoder.encode(place))
                if (countryCode != null && countryCode.length() == 2) urlStr += urlRegionPhrase + countryCode.toLowerCase()
                URL url = new URL(urlStr)
                def contents = getUrlContents(url)
                if (contents != null && contents.length() > 0){
                    def slurper = new JsonSlurper()
                    def slurp = slurper.parseText(contents)
                    def results = slurp.results
                    def latitude, longitude, formatted_address
                    def Set<String> formatted_addresses = new HashSet<String>()
                    for (def i = 0; i < results.size() ; i++){
                        latitude = results.getAt(i).geometry.location.lat
                        longitude = results.getAt(i).geometry.location.lng
                        formatted_address = results.getAt(i).formatted_address.trim()
                        if ((inUkRoi && latitude < MAX_LAT && latitude > MIN_LAT && longitude < MAX_LNG && longitude > MIN_LNG) || !inUkRoi){
                        // Add to fullResults provided the lat/lng is within UK/ROI if required, and the address isn't duplicated in the results
                            if ( !formatted_addresses.contains(formatted_address)){
                                fullResults.add([latitude, longitude, formatted_address])
                                formatted_addresses.add(formatted_address)
                            }
                        }
                    }
                }
                // nb add the place searched for even if no location results - saves us having to repeat a fruitless search
                CacheService.add(place, fullResults)
            }
        }
        fullResults
    }

    private static String getUrlContents(URL url){
        StringBuilder sb = new StringBuilder()
        String str
        BufferedReader br
        try{
            br = new BufferedReader(new InputStreamReader(url.openStream()))
            while ((str = br.readLine()) != null) {
                sb.append(str)
            }
        } catch (Exception e) {
            LogFactory.getLog(this).debug(e.getMessage())
        }finally{
            br.close();
        }
        return sb.toString()
    }

}

