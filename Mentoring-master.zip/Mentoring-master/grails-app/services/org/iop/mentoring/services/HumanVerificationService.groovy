package org.iop.mentoring.services

/**
 * A simple Human Verification system, which doesn't require the use of javascript on the client.
 *
 * A random string is generated, and the user has to extract the portion of the string which has been highlighted, and submit it.
 * I have tried to make it hard for a someone to script a crack for this:
 *   : the portion of the string which the user must select is not inserted in the same place every time.
 *   : the start/end tags vary (although I had to wrap them in a span tag, so maybe this isn't that useful)/
 *   : the strings are generated at random
 *   : the target string which the user must copy is encrypted before being returned, and the encryption is salted with
 *     strings based on today's date and "Mentoring" to make it harder to guess.
 *
 */
class HumanVerificationService {

    static final String charset = "abcdefghijklmnopqrstuvwxysABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!£%*|@#"
    static rand = new Random(System.currentTimeMillis())

    static def getVerificationStrings(targetLength) {
        // generate a stream of characters 3 times as long as the target.
        StringBuilder sb = new StringBuilder()
        for (def i=0; i < targetLength * 3; i++ ){
            sb.append(charset[rand.nextInt().abs() % charset.length()])
        }
        // Choose a point where the target string will start within the generated stream.
        int startPoint = ((int)Math.floor(targetLength / 2))+ (rand.nextInt().abs() % targetLength)
        def target = sb.substring(startPoint, startPoint + targetLength)
        // Use one of four sets of matching tags
        def startTags = ["<strong><em>","<em><strong>","<b><i>","<i><b>"]
        def endTags = ["</em></strong>","</strong></em>","</i></b>","</b></i>"]
        int tagChoice = rand.nextInt().abs() % startTags.size()
        // wrap a span with class of humanVerification around the whole target phrase
        def spanStartTags = "<span class='humanVerification'>" + startTags[tagChoice]
        def spanEndTags = endTags[tagChoice] + "</span>"
        // insert the tags into the chosen points of the html to display
        sb.insert(startPoint + targetLength, spanEndTags)
        sb.insert(startPoint, spanStartTags)
        return [sb.toString(), encodeString(target), spanStartTags, spanEndTags]

    }

    static def encodeString(string){
        def now = new Date()
        def saltedString = now.format("EEEdd") + string + now.format("MMMyy") + "Mentoring"
        saltedString.bytes.encodeBase64().toString()
    }
}
