package org.iop.mentoring.domain

class IndustrySector {

    private static String OTHER = 'Other'

    String name

    static def getNames() {
        return listOrderByName()
    }

    static def getDefault(){
        return IndustrySector.findByName(OTHER)
    }

}
