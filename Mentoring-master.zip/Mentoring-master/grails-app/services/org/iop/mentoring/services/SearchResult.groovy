package org.iop.mentoring.services

class SearchResult {
    BigDecimal personId
    String memberCode
    String firstName
    String lastName
    String jobTitle
    String employer
    String industrySector
    BigDecimal industrySectorId
    String townCity
    String postZip
    String countryCode
    String country
    Float distance
    boolean active
    boolean isSuperUser
    boolean isSuspended
    int maxMentees
    int mentees
    BigDecimal mentorId
    BigDecimal menteeId

}
