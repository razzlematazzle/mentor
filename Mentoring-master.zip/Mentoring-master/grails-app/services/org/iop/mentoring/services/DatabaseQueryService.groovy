package org.iop.mentoring.services


import groovy.sql.GroovyRowResult

import javax.sql.DataSource

/**
 This is a base class providing common functionality for services which query the database
 */
class DatabaseQueryService {

    protected static final String DATE_OUTPUT_FORMAT = 'dd MMM yyyy'

    static transactional = true

    DataSource dataSource

    protected groovy.sql.Sql newSql(){
        new groovy.sql.Sql(dataSource)
    }

}