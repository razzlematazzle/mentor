package mentoring

import org.iop.mentoring.controllers.HomeController
import org.iop.mentoring.controllers.ReportCommand
import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.MentoreeReportResult
import org.iop.mentoring.services.ReportResult
import org.iop.mentoring.services.ReportService
import org.iop.mentoring.services.SecurityService

class ReportController {

    public final enum ReportType {
        MENTOR, MENTEE
    }

    def ReportService reportService

    def SecurityService securityService

    def mentors = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            List<ReportResult> results = reportService.mentors(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countMentors()
                def title = "Registered Mentors"
                def model = [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", type: "Mentor", paginationLink: "mentors"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu("Registered Mentors")
            }
        }else{
            return
        }
    }

    def mentees = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            List<ReportResult> results = reportService.mentees(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countMentees()
                def title = "Registered Mentees"
                def model = [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", type: "Mentee"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu("Registered Mentees")
            }
        }else{
            return
        }
    }

    def unmatched_mentors = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title = "Unmatched Mentors"
            List<ReportResult> results = reportService.unmatchedMentors(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countUnmatchedMentors()
                def model =
                    [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", type: "Mentor", paginationLink: "unmatched_mentors"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def unmatched_mentees = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title = "Unmatched Mentees"
            List<ReportResult> results = reportService.unmatchedMentees(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countUnmatchedMentees()
                def model =
                    [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", type: "Mentee", paginationLink: "unmatched_mentees"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def waiting = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title = "Awaiting Response to Request for Mentoring"
            List<MentoreeReportResult> results = reportService.awaitingResponse(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countAwaitingResponse()
                def model =
                    [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Request", type: "Mentee", paginationLink: "waiting", duration: "Days outstanding"]
                setParams(rc, model, total)
                render(view: "menteeMentorList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def matched_name_order = { ReportCommand rc ->
        matched(rc, false)
    }

    def matched_duration_order = { ReportCommand rc ->
        matched(rc, true)
    }

    private void matched(ReportCommand rc, boolean durationOrder){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title = "Report of matched Mentor/Mentees in " + (durationOrder ? "duration" : "name") + " order"
            def paginationLink = "matched_" + (durationOrder ? "duration" : "name") + "_order"
            List<MentoreeReportResult> results = reportService.matched(rc, durationOrder)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countMatched()
                def model =
                    [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Mentoring Start", paginationLink: paginationLink, duration: "Mentoring period (days)"]
                setParams(rc, model, total)
                render(view: "menteeMentorList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def suspended_mentors = { ReportCommand rc ->
        suspended(rc, ReportType.MENTOR)
    }

    def suspended_mentees = { ReportCommand rc ->
        suspended(rc, ReportType.MENTEE)
    }


    private suspended(ReportCommand rc, ReportType reportType ){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title, paginationLink, type
            if (reportType == ReportType.MENTOR){
                title = "Mentors who have been suspended"
                paginationLink = "suspended_mentors"
                type = "Mentor"
            }else{
                title = "Mentees who have been suspended"
                paginationLink = "suspended_mentees"
                type = "Mentee"
            }
            List<MentoreeReportResult> results = reportService.suspended(rc, reportType)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countSuspended(reportType)
                def model =
                    [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", type: type, paginationLink: paginationLink, duration: "Days outstanding"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def super_users = { ReportCommand rc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            def title = "Super Users"
            List<ReportResult> results = reportService.superUsers(rc)
            if (results.size() > 0) {
                int total = params.total ? Integer.parseInt(params.total) : reportService.countSuperUsers()
                def model = [resultsList: results, resultsTotal: total, status: status, title: title, breadCrumbHeading: title, heading: title, dateName: "Registration", paginationLink: "super_users"]
                setParams(rc, model, total)
                render(view: "mentoreeList", model: model, max: rc.max, offset: rc.offset)
            } else {
                returnToAdminMenu(title)
            }
        }else{
            return
        }
    }

    def extract_csv = {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (checkAdminStatus(status, id)){
            String csv = reportService.extractCSV()
            render(text: csv, contentType: "text/plain", encoding: "UTF-8")
        }else{
            return
        }
    }

    private void returnToAdminMenu(repName) {
        flash.message = "No results found for your $repName report."
        redirect(controller: "admin", action: "index")
    }

    private boolean checkAdminStatus(status, id){
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN || !person.superUser){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
            return false
        }
        return true
    }


    private setParams(ReportCommand rc, Map model, int total) {
        params.put("total", total)
        params.put("offset", rc.offset)
        params.put("max", rc.max)
        model.put("params", params)
    }
}
