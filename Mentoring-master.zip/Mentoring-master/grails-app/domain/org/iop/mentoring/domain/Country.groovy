package org.iop.mentoring.domain

class Country {

    String name
    String code

    static List<Country> listOrderedByName

    static Map<String, Country> countryMap

    static constraints = {
        code minSize: 2, maxSize: 2
    }

    public Country(String code, String name){
        this.code = code
        this.name = name
    }

    static def getNames() {
        if (!listOrderedByName) listOrderedByName = listOrderByName()
        listOrderedByName
    }

    static def getCountryByCode(String code){
        if (!countryMap){
            countryMap = new HashMap<String, Country>()
            for (Country country : getNames()){
                countryMap.put(country.code, country)
            }
        }
        countryMap.get(code)
    }
}
