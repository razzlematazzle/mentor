package org.iop.mentoring.controllers

import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.SecurityService

import javax.imageio.ImageIO
import java.awt.Graphics
import java.awt.image.BufferedImage

class PhotoUploadCommand {
    byte[] photo
    String personId
    String origin
}

class ImageController {

    SecurityService securityService

    final int IMG_BASE_DIMENSION = 400

    private static final okcontents = ['image/png', 'image/jpeg']

    def index = {
        image()
    }

    def menteeEdit = {
        image("menteeEdit")
    }

    def mentorEdit = {
        image("mentorEdit")
    }

    private void image(origin) {
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        if (status == SecurityService.Status.NOT_LOGGED_IN) {
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        } else if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOR ||
                status == SecurityService.Status.LOGGED_IN_MENTOREE) {
            render(view: "/image/form", model: [person: person, status: status, origin: origin])
            return
        } else {
            flash.message = "You are not a registered mentor or mentee so cannot upload a photo."
            return
        }
    }

    def upload = { PhotoUploadCommand puc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            flash.message = null // reset
            if (puc.personId?.length() == 0){
                throw new RuntimeException("System error: no person id specified re photo upload")
            }
            def person = Person.findById(puc.personId)
            def f = request.getFile('photo')
            if (f == null){
                flash.message = "could not read your upload file"
                render( view: "form", model: [person: person, personId: puc.personId, photo: puc.photo, firstName: person.firstName])
                return
            }
            def fileContentType = f.getContentType()
            if (!okcontents.contains(fileContentType)) {
                flash.message = "photo must be either a jpg or png !"
                render( view: "form", model: [person: person, personId: puc.personId, photo: puc.photo, firstName: person.firstName])
                return
            }
            resizePhotoIfNeeded(puc, f)
            person.oldPhoto = person.photo
            person.photo = puc.photo
            if (!person.validate()){
                render( view: "form", model: [person: person, personId: puc.personId, photo: puc.photo, firstName: person.firstName])
                return
            }else{
                if (person.save(flush: true, validate: false)) {
                    render (view: "view", model: [photo: puc.photo, person: person, status: status, origin: puc.origin] )
                }else{
                    if (person.hasErrors()){
                        // Couldn't save file if too large.
                        render( view: "form", model: [person: person, personId: puc.personId, photo: puc.photo, firstName: person.firstName])
                    }else{
                        // Some other error occurred
                        response.sendError(500)
                    }
                }
            }
        }
    }

    def resizePhotoIfNeeded(PhotoUploadCommand puc, file) {
        def imageBaseResize = IMG_BASE_DIMENSION
        // If the photo is too large, decrease its dimensions until it fits the required size
        while (puc.photo.size() > Person.PHOTO_MAXSIZE){
            resizePhoto(puc, imageBaseResize, file)
            imageBaseResize = (int)(imageBaseResize/2)
        }
    }

    private void resizePhoto(PhotoUploadCommand puc, int imageBaseResize, file) {
        def fileContentType = file.getContentType()
        BufferedImage originalImage = ImageIO.read(file.getInputStream())
        int origHeight = originalImage.getHeight()
        int origWidth = originalImage.getWidth()
        int newHeight, newWidth
        // preserve aspect ratio, make sure image is at least a minimum size along one dimension.
        if (origHeight > origWidth){
            newWidth = imageBaseResize
            newHeight = imageBaseResize * (origHeight / origWidth)
        }else{
            newHeight = imageBaseResize
            newWidth = imageBaseResize * (origWidth / origHeight)
        }
        BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, originalImage.getType());
        Graphics graphics = resizedImage.createGraphics();
        graphics.drawImage(originalImage,0,0,newWidth,newHeight,null);
        writeImageToPhoto(puc, fileContentType, resizedImage)
    }

    private void writeImageToPhoto(PhotoUploadCommand puc, fileContentType, BufferedImage resizedImage) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        def fileType = ""
        if (fileContentType == 'image/png') {
            fileType = "png"
        }else if (fileContentType == 'image/jpeg'){
            fileType = "jpg"
        }else{
            log("Unexpected condition: unexpected image content type " + fileContentType)
            response.sendError(500)
        }
        ImageIO.write(resizedImage, fileType, baos);
        baos.flush();
        byte[] bytes = baos.toByteArray();
        baos.close();
        puc.photo = bytes
    }

    def delete = {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            flash.message = null // reset
            if (params.id.length() == 0){
                throw new RuntimeException("System error: no person id specified re photo deletion")
            }
            def person = Person.findById(params.id)
            person.photo = null
            person.save(flush: true, failOnError: true)
            flash.message = "Your photo has been deleted"
            returnToOrigin(params.origin)
        }
    }

    def cancel = {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN ){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            flash.message = null // reset
            if (params.id.length() == 0){
                throw new RuntimeException("System error: no person id specified re photo deletion")
            }
            def person = Person.findById(params.id)
            person.photo = person.oldPhoto
            person.oldPhoto = null
            person.save(flush: true, failOnError: true)
            flash.message = "Uploaded photo has not be saved"
            returnToOrigin(params.origin)
        }
    }

    def change = {
        flash.message = "Your photo has now been changed."
        returnToOrigin(params.origin)
    }

    def back = {
        returnToOrigin(params.origin)
    }

    private void returnToOrigin(origin) {
        switch (origin) {
            case 'menteeEdit':
                redirect(controller: "person", action: "edit_mentee")
                break
            case 'mentorEdit':
                redirect(controller: "person", action: "edit_mentor")
                break
            default:
                redirect(controller: "home")
        }
    }

    def renderImage = {
        def person = Person.findById(params.id)
        if (person?.photo) {
            response.setContentLength(person.photo.length)
            response.outputStream.write(person.photo)
        } else {
            response.sendError(500)
        }
    }
}