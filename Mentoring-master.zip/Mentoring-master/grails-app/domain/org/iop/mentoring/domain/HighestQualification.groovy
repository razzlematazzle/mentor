package org.iop.mentoring.domain

class HighestQualification {

    String name

    static def getNames() {
        return listOrderByName()
    }

}
