package org.iop.mentoring.services

class PreferredMentorService extends DatabaseQueryService{

    final static deletePreferredMentorSql = '''
        delete from preferred_mentor where mentee_id = _MENTEE_ID_ and mentor_id = _MENTOR_ID_ '''

    def deletePreferredMentor(menteeId, preferredMentorId) {
        def sql = newSql()
        try {
            def deleteQuery =
                deletePreferredMentorSql
                        .replace("_MENTOR_ID_", preferredMentorId.toString())
                        .replace("_MENTEE_ID_", menteeId.toString())
            def deleted = sql.executeUpdate(deleteQuery)
            if (deleted != 1) {
                sql.rollback()
                throw new RuntimeException("System error: should have deleted 1 record but $deleted deleted")
            }
            sql.commit()
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

}
