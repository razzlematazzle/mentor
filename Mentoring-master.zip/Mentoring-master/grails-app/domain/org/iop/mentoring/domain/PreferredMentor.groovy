package org.iop.mentoring.domain

/**
 * This class records who the mentee's preferred mentors are.
 * Note that the preferred mentors are not the same as a person's actual mentors.
 * Note also that a mentor may only take on a maximum of three mentees, there is no limit on how many mentees may name
 * that person as a preferred mentor.
 */
class PreferredMentor implements Serializable{

    public static def MAX_ALLOWED_PREFERRED_MENTORS = 3

    Mentor mentor

    static belongsTo = [mentee: Mentee]

    static mapping = {
        id composite:[ "mentee", "mentor"]
    }

    public static boolean contains(Mentor mentor, Mentee mentee){
        def found = PreferredMentor.findByMentorAndMentee(mentor, mentee)
        return found != null
    }

}
