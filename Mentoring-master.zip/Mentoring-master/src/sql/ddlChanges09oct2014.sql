drop table if exists mentee_need_mentor_reason;
create table mentee_need_mentor_reason (mentee_need_mentor_reasons_id bigint, need_mentor_reason_id bigint);
alter table mentee_need_mentor_reason add index FKA3DAA3FA1B0C74CB (need_mentor_reason_id), add constraint FKA3DAA3FA1B0C74CB foreign key (need_mentor_reason_id) references need_mentor_reason (id);
alter table mentee_need_mentor_reason add index FKA3DAA3FA4F3A69CE (mentee_need_mentor_reasons_id), add constraint FKA3DAA3FA4F3A69CE foreign key (mentee_need_mentor_reasons_id) references mentee (id);

INSERT INTO mentee_need_mentor_reason (mentee_need_mentor_reasons_id, need_mentor_reason_id)
  SELECT id, need_mentor_reason_id
  FROM mentee;

commit;

select count(*) from  mentee_need_mentor_reason;
select count(*) from mentee where need_mentor_reason_id is not null;
-- These should be equal. CHECK THIS BEFORE PROCEEDING!

alter table mentee drop need_mentor_reason_id;
