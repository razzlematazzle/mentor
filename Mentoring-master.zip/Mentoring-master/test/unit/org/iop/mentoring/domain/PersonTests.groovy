package org.iop.mentoring.domain



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Person)
class PersonTests {

    void testYearsInPosition() {
        def p = new Person()
        assertNotNull(p)
        assertTrue(p.getYearsInPosition() == 0)
        def today = new Date()
        p.startedInCurrentPosition = today
        assertTrue(p.getYearsInPosition() == 0)
        def almostAYearAgo = today -360
        p.startedInCurrentPosition = almostAYearAgo
        assertTrue(p.getYearsInPosition() == 0)
        def justOverAYearAgo = today - 367
        p.startedInCurrentPosition = justOverAYearAgo
        assertTrue(p.getYearsInPosition() == 1)
        def justOver2YearsAgo = today - ((366 * 2) + 1)
        p.startedInCurrentPosition = justOver2YearsAgo
        assertTrue(p.getYearsInPosition() == 2)
        def justOver3YearsAgo = today - ((366 * 3) + 1)
        p.startedInCurrentPosition = justOver3YearsAgo
        assertTrue(p.getYearsInPosition() == 3)

    }
}
