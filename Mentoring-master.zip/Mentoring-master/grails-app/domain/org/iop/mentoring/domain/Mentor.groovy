package org.iop.mentoring.domain

class Mentor {
    String reason
    boolean experienced
    int maxMentees = 0
    boolean active = true
    String subject
    String specialistSkills
    Location location
    Location alternativeLocation

    static hasMany = [preferredMeetingFormats: PreferredMeetingFormat]
    SortedSet<PreferredMeetingFormat> preferredMeetingFormats

    static constraints = {
        location nullable: true, blank: true, validator: {
            loc, mentor ->
                if (loc == null && mentor.alternativeLocation == null){
                    return ['mentoring.location.empty.error']
                }
            }
        alternativeLocation nullable: true
        // nb subject, specialistSkills and reason all need nullable to be set to true when doing data import!
        subject maxSize: 80, validator: {
            subject, mentor ->
                if (subject == null || subject.trim().length() == 0){
                    return ['mentor.subject.blank.error']
                }
        }
        reason maxSize: 1000, validator: {
            reason, mentor ->
                if (reason == null || reason.trim().length() == 0){
                    return ['mentor.reason.blank.error']
                }
        }
        specialistSkills maxSize: 1000, validator: {
            specialistSkills, mentor ->
                if (specialistSkills == null || specialistSkills.trim().length() == 0){
                    return ['mentor.specialistSkills.blank.error']
                }
        }

    }

    Set<Mentee> getMentees() {
        MentorMentee.findAllByMentor(this).collect { it.mentee } as Set
    }

    Set<Mentee> getLiveMentees() {
        MentorMentee.findAllByMentorAndEndIsNull(this).collect { it.mentee } as Set
    }

}
