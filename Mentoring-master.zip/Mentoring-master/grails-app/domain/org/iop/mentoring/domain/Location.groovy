package org.iop.mentoring.domain

import org.iop.mentoring.services.GeocodingService

class Location {

    String addressLine1
    String addressLine2
    String townCity
    String postZip               // eg UK postcode, zip
    Country country
    double latitude
    double longitude

    public static enum Status  {ADDRESS_MISSING, EMPTY, VALID, MISSING_COUNTRY_CODE, INVALID_COUNTRY_CODE, LOCATION_NOT_FOUND, LOCATION_AMBIGUOUS}

    static constraints = {
        addressLine1 maxSize: 256
        addressLine2 maxSize: 256, nullable: true
        townCity maxSize: 128, nullable: true
        postZip nullable: true, blank: true, maxSize: 20
    }

    public static createLocation(addressLine1, addressLine2, townCity, postZip, countryCode, GeocodingService geocodingService){
        def location = null
        Status status
        if (isEmpty(addressLine1) &&  isEmpty(addressLine1) && isEmpty(townCity) && isEmpty(postZip)){
            if (isEmpty(countryCode)){
                // If no fields populated, return empty Location.
                status = Status.EMPTY
            }else{
                status = Status.ADDRESS_MISSING
                def country = Country.findByCode(countryCode)
                location = new Location()
                if (country != null) location.country = country
            }
        }else{
            location = new Location()
            location.addressLine1 = addressLine1
            location.addressLine2 = addressLine2
            location.townCity = townCity
            location.postZip = postZip
            if (isEmpty(countryCode)){
                status = Status.MISSING_COUNTRY_CODE
            }else{
                def country = Country.findByCode(countryCode)
                if (country == null){
                    status = Status.INVALID_COUNTRY_CODE
                }else{
                    location.country = country
                    def address = location.concatenateLocationFromAddressFields()
                    def found = geocodingService.getLatLong(address, countryCode)
                    switch (found.size()){
                        case 0:
                            // No matching location found, so error
                            status = Status.LOCATION_NOT_FOUND
                            break
                        case 1:
                            // 1 geo-location found, so use it to search database
                            status = Status.VALID
                            def (lat, lng, place) = found[0]
                            location.latitude = lat
                            location.longitude = lng
                            break
                        default:
                            //  > 1 matching location found, fail validation.
                            status = Status.LOCATION_AMBIGUOUS
                    }
                }
            }
        }
        [location, status]
    }

    def static isEmpty(String field){
        return (field == null || field.trim().length() == 0) ? true : false
    }

    def concatenateLocationFromAddressFields(){
        StringBuilder address = new StringBuilder()
        if (!isEmpty(addressLine1)) address.append(addressLine1)
        if (!isEmpty(addressLine2)){
            if (address.length() > 0) address.append(", ")
            address.append(addressLine2)
        }
        if (!isEmpty(townCity)){
            if (address.length() > 0) address.append(", ")
            address.append(townCity)
        }
        if (!isEmpty(postZip)){
            if (address.length() > 0) address.append(", ")
            address.append(postZip)
        }
        address.toString()
    }
}
