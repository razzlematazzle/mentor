package org.iop.mentoring.domain



import grails.test.mixin.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Location)
class LocationTests {

    void testSomething() {
        fail "Implement me"
    }
}
