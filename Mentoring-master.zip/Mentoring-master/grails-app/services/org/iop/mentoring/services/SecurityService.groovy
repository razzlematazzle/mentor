package org.iop.mentoring.services

import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Mentor
import org.iop.mentoring.domain.MentorMentee
import org.iop.mentoring.domain.Person
import org.iop.mentoring.domain.PreferredMentor

import javax.servlet.http.Cookie

class SecurityService extends DatabaseQueryService{

    public static IOP_MEMBERCODE_COOKIE_NAME = 'membercode'
    public static MENTORING_MEMBERCODE_COOKIE_NAME = 'mentoring'
    public static String MENTOR_DETAILS_COOKIE_NAME = 'mentorDetails'
    private static final int QUARTER_HOUR_SECONDS = 15 * 60
    private static final String COOKIE_PATH = "/"

    /**
     * Remove both the MyIOP and Mentoring cookies which contain the membercode so the user has no session.
     */
    def logout(request, response) {
        def cookie = request.getCookie(MENTORING_MEMBERCODE_COOKIE_NAME)
        if (cookie != null) deleteCookie(MENTORING_MEMBERCODE_COOKIE_NAME, response)
        cookie = request.getCookie(IOP_MEMBERCODE_COOKIE_NAME)
        if (cookie != null) deleteCookie(IOP_MEMBERCODE_COOKIE_NAME, response)
        cookie = request.getCookie(MENTOR_DETAILS_COOKIE_NAME)
        if (cookie != null) deleteCookie(MENTOR_DETAILS_COOKIE_NAME, response)
    }

    private void deleteCookie(cookieName, response) {
        def cookie = new Cookie(cookieName, "")
        cookie.setMaxAge(0);
        cookie.setPath(COOKIE_PATH);
        response.addCookie(cookie);
    }

    enum Status {
        NOT_LOGGED_IN, LOGGED_IN, LOGGED_IN_MENTOR, LOGGED_IN_MENTEE, LOGGED_IN_MENTOREE
    }

    /* Get the user's iop membercode from the MyIOP cookie (dropped when the user logs in).
     * If its not there, look for the Mentoring cookie. We drop a 'mentoring' cookie containing the member code, with an
     * expiry of 15 minutes, every time this application checks the user's security, so that if the user's MyIOP session
     * expires they won't lose data entry in the mentoring data-entry forma.
     * (Note that we check for the MyIOP cookie first, so that if the user logs out and someone else logs in to MyIOP,
     * we change the user's identity).
     */
    def getSecurity(request, response) {
        def status, id, mentorId, menteeId, memberCode
        memberCode = request.getCookie(IOP_MEMBERCODE_COOKIE_NAME)
        if (!memberCode) memberCode = request.getCookie(MENTORING_MEMBERCODE_COOKIE_NAME)
        (status, id, mentorId, menteeId, memberCode) = getSecurityFromMemberCode(memberCode )
        if (status != Status.NOT_LOGGED_IN){
            // Add or refresh the mentoring cookie
            addMentoringCookie(memberCode, response)
        }
        UserInfo userInfo = new UserInfo()
        userInfo.status = status
        userInfo.id = id
        userInfo.mentorId = mentorId
        userInfo.menteeId = menteeId
        userInfo.memberCode = memberCode
        if (status == SecurityService.Status.LOGGED_IN_MENTEE || status == SecurityService.Status.LOGGED_IN_MENTOREE){
            // Look for mentor details cookie
            Set<Mentor>[] mentorDetails = getAssociatedMentorDetails(menteeId, request)
            def assignedMentors = mentorDetails[0]
            userInfo.assignedMentorNames = getMentorFirstLastNames(assignedMentors)
            def preferredMentors = mentorDetails[1]
            userInfo.preferredMentorNames = getMentorFirstLastNames(preferredMentors)
        }
        return userInfo
    }

    private void addMentoringCookie(memberCode, response) {
        Cookie cookie = new Cookie(MENTORING_MEMBERCODE_COOKIE_NAME, memberCode)
        cookie.maxAge = QUARTER_HOUR_SECONDS
        cookie.setPath(COOKIE_PATH)
        response.addCookie(cookie)
    }

    private getSecurityFromMemberCode(memberCode){
        def status = Status.NOT_LOGGED_IN
        def id, mentorId, menteeId
        if (memberCode != null){
            status = Status.LOGGED_IN
            // Find member's mentor/ee status.
            def row = newSql().firstRow("select id, mentor_id, mentee_id from person where member_code = ? and suspended = false", [memberCode])
            if (row != null){
                id = row.id
                if (row.mentor_id != null && row.mentee_id != null){
                    status = Status.LOGGED_IN_MENTOREE
                    mentorId = row.mentor_id
                    menteeId = row.mentee_id
                }else if (row.mentor_id != null){
                    status = Status.LOGGED_IN_MENTOR
                    mentorId = row.mentor_id
                }else if (row.mentee_id != null){
                    status = Status.LOGGED_IN_MENTEE
                    menteeId = row.mentee_id
                }
            }
        }
        return [status, id, mentorId, menteeId, memberCode]
    }

    private Set<Mentor>[] getAssociatedMentorDetails(Long menteeID, request){
        Mentee mentee = Mentee.get(menteeID)
        Set<Mentor>[] mentorDetails
        mentorDetails = getAssociatedMentorDetailsFromDatabase(mentee)
        mentorDetails
    }

    private Set<Mentor>[]  getAssociatedMentorDetailsFromDatabase(Mentee mentee) {
        def assignedMentorMentees = MentorMentee.findAllByMenteeAndEndIsNull(mentee)
        Set<Mentor> assignedMentors = assignedMentorMentees*.mentor
        def assignedMentorIDs = assignedMentors*.getId()
        def preferredMentors = mentee.getPreferredMentors()
        def preferredOnlyMentors = new HashSet<Mentor>()
        // Remove any preferred mentor from list if already an assigned mentor
        for (PreferredMentor preferredMentor : preferredMentors) {
            if (!assignedMentorIDs.contains(preferredMentor.mentorId)) {
                preferredOnlyMentors.add(preferredMentor.mentor)
            }
        }
        return [assignedMentors, preferredOnlyMentors]
    }

    private String getMentorFirstLastNames(assignedMentors) {
        def sb = new StringBuilder()
        boolean first = true
        for (Mentor mentor : assignedMentors) {
            def person = Person.findByMentor(mentor)
            if (person == null){
                log.error("Could not find assigned mentor " + mentor.id)
            }else{
                if (first) {
                    first = false
                } else {
                    sb.append(", ")
                }
                sb.append(person.firstName)
                sb.append(" ")
                sb.append(person.lastName)
            }
        }
        sb.toString()
    }

    def readMentorDetailsString(String str){
        def mentorId, assignedMentors, preferredMentors
        if (str.startsWith("MENTORS ")){
            String[] elems = str.split("\\|")
            if (elems.size() == 3){
                mentorId = elems[0].substring(elems[0].indexOf(" ")).trim()
                def assignedMentorsStrings = elems[1]
                assignedMentors = assignedMentorsStrings?.split(",")
                def preferredMentorsStrings = elems[2]
                preferredMentors = preferredMentorsStrings?.split(",")
            }
        }
        [mentorId, assignedMentors, preferredMentors]
    }


}

class UserInfo{
    SecurityService.Status status
    Long id
    Long mentorId
    Long menteeId
    String memberCode
    String assignedMentorNames
    String preferredMentorNames
}