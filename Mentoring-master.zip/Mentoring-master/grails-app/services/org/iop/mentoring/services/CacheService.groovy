package org.iop.mentoring.services

import org.apache.commons.logging.LogFactory

class CacheService implements Serializable {

    private static places = new HashMap<String, ArrayList<String>>()

    private static cacheFilename = 'serializedCache.obj'

    static int sizeLastSerialized = 0
    static int serializationThreshold = 100

    public static load() {
        def f = new File(cacheFilename)
        if (f.exists() && f.canRead()) {
            try {
                def ois = new ObjectInputStream(new FileInputStream(cacheFilename))
                def cache = ois.readObject()
                if (cache != null) {
                    places = cache
                    sizeLastSerialized = places.size()
                }
                ois.close()
            } catch (Exception e) {
                LogFactory.getLog(this).info('Cannot read cache from file ' + cacheFilename + ': ' + e.getMessage())
            }

        }
    }

    public static ArrayList<String> get(String place) {
        return places.get(place.toLowerCase().trim())
    }

    public static boolean contains(String place) {
        places.containsKey(place.toLowerCase().trim())
    }

    public synchronized static add(String place, ArrayList<String> fullResults) {
        places.put(place.toLowerCase().trim(), fullResults)
        if (places.size() > sizeLastSerialized + serializationThreshold) {
            serialize()
            sizeLastSerialized = places.size()
        }
    }

    private static serialize() {
        try {
            def out = new ObjectOutputStream(new FileOutputStream(cacheFilename))
            out.writeObject(places)
            out.close()
        } catch (Exception e) {
            LogFactory.getLog(this).info('Cannot write cache to file ' + cacheFilename + ': ' + e.getMessage())
        }
    }
}
