package org.iop.mentoring.controllers

import org.iop.mentoring.domain.Location

import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Mentor
import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.GeocodingService
import org.iop.mentoring.services.SecurityService
import org.iop.mentoring.services.SecurityService.Status

class PersonController {

    def mailService

    def index() {}

    def static MYIOP_LOGOUT_URL = "https://www.iop.org/myportal/MemberSignOut.jsp"
    def final TERMS_CONDITIONS = "/resources/TermsConditions.pdf"
    def SecurityService securityService
    def GeocodingService geocodingService

    // Create a new mentor. There should be neither a Person nor Mentor record already in existence.
    def create_mentor() {
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, mentorId = u.mentorId, memberCode = u.memberCode;
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                if (mentorId == null){
                    Person personInstance = new Person()
                    personInstance.setMentor(new Mentor())
                    personInstance.setMemberCode(memberCode)
                    render(view: "mentorRegistration", model: [id: id, status: status, isSuperUser: personInstance.isSuperUser(),
                            personInstance: personInstance, mode: "create"])
                }else{
                    logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a mentor record, id $mentorId")
                }
            }else{
                logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a person record, id $id")
            }
        }
    }

    // Create a new Mentor record for an already existing Person with a Mentee record.
    def add_mentor(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, mentorId = u.mentorId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                logRuntimeException("System error: cannot create mentor - no person record exists for membercode $memberCode")
            }else if (mentorId != null){
                logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a mentor record, id $mentorId")
            }else{
                Person personInstance = Person.get(id)
                render(view: "mentorAddition", model: [id: id, status: status, isSuperUser: personInstance.isSuperUser(), personInstance: personInstance, mode: "create"])
            }
        }
    }

    def save_new_additional_mentor(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def personDb = Person.findByMemberCode(memberCode) // sanity check
                if (personDb != null){
                    def (person, locErrorCodes, altLocErrorCodes, location, altLocation, mentor, locMsg, altLocMsg) = loadPersonMentorLocations(personDb)
                    person.mentor = mentor
                    validateMentorRejectErrors(person, locErrorCodes, altLocErrorCodes, false)
                    if (!person.hasErrors()){
                        if (location != null) location.save(failOnError: true)
                        if (altLocation != null) altLocation.save(failOnError: true)
                        mentor.save(flush: true, failOnError: true)
                        personDb.mentor = mentor
                        personDb.save(flush: true, failOnError: true)
                        if (mentor.active) flash.message = message(code: 'mentor.created.message')
                        else flash.message = message(code: 'mentor.created.inactive.message')
                        emailMentorRegistrationResponse(person)
                        u = securityService.getSecurity(request, response)
                        status = u.status // reset
                        redirect(controller: "home", model: [status: status])
                        return
                    }else{
                        flash.message = null; // clear
                        def model = [personInstance: person, status: status]
                        if (locMsg != null) model.put("locMsg", locMsg)
                        if (altLocMsg != null) model.put("altLocMsg", altLocMsg)
                        model.put("mode", "create")
                        render(view: "mentorAddition", model: model)
                        return
                    }
                }else{
                    logRuntimeException("System error: cannot create mentor - no person record exists for membercode $memberCode")
                }
            }
        }
    }


    // Create a new mentee. There should be neither a Person nor Mentee record already in existence.
    def create_mentee() {
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, menteeId = u.menteeId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                if (menteeId == null){
                    Person personInstance = new Person()
                    personInstance.setMentee(new Mentee())
                    personInstance.setMemberCode(memberCode)
                    render(view: "menteeRegistration", model: [id: id, status: status, isSuperUser: personInstance.isSuperUser(),
                            personInstance: personInstance, mode: "create"])
                }else{
                    logRuntimeException("System error: cannot create mentee - membercode $memberCode already has a mentee record, id $menteeId")
                }
            }else{
                logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a person record, id $id")
            }
        }
    }

    // Create a new Mentee record for an already existing Person with a Mentor record.
    def add_mentee(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, menteeId = u.menteeId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                logRuntimeException("System error: cannot create mentee - no person record exists for membercode $memberCode")
            }else if (menteeId != null){
                logRuntimeException("System error: cannot create mentee as one already exists for membercode $memberCode")
            }else{
                Person personInstance = Person.get(id)
                render(view: "menteeAddition", model: [id: id, status: status, isSuperUser: personInstance.isSuperUser(), personInstance: personInstance, mode: "create"])
            }
        }
    }

    def edit_mentor_su(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            Person person = Person.get(id)
            if (person.superUser){
                Person personInstance = Person.get(Long.parseLong(params.id))
                render(view: "mentorRegistration", model: [id: id, status: status, superUser: true, personInstance: personInstance, mode: "edit",
                        assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
            }else{
                throw new RuntimeException("System error: only super users can use the edit_mentor_su() method")
            }
        }
    }

    def edit_mentor(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, mentorId = u.mentorId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                logRuntimeException("System error: cannot edit mentor - no person record exists for membercode $memberCode")
            }else if (mentorId == null){
                logRuntimeException("System error: cannot edit mentor -  no person mentor exists for membercode $memberCode")
            }else{
                Person personInstance = Person.get(id)
                render(view: "mentorRegistration", model: [id: id, status: status, isSuperUser: personInstance.isSuperUser(), personInstance: personInstance, mode: 'edit',
                        assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
            }
        }
    }

    def edit_mentee_su(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            Person person = Person.get(id)
            if (person.superUser){
                Person personInstance = Person.get(Long.parseLong(params.id))
                render(view: "menteeRegistration", model: [id: id, status: status, superUser: true, personInstance: personInstance, mode: "edit",
                        assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
            }else{
                throw new RuntimeException("System error: only super users can use this method")
            }
        }
    }

    def edit_mentee(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, menteeId = u.menteeId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (id == null){
                logRuntimeException("System error: cannot edit mentee - no person record exists for membercode $memberCode")
            }else if (menteeId == null){
                logRuntimeException("System error: cannot edit mentee -  no person mentor exists for membercode $memberCode")
            }else{
                Person personInstance = Person.get(id)
                render(view: "menteeRegistration", model: [id: id, status: status, superUser: false, personInstance: personInstance, mode: "edit",
                        assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
            }
        }
    }

    def save_new_mentor(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def person = Person.findByMemberCode(memberCode) // sanity check
                if (person == null){
                    Mentor mentor
                    def location, altLocation, locMsg, altLocMsg, locErrorCodes, altLocErrorCodes
                    (person, locErrorCodes, altLocErrorCodes, location, altLocation, mentor, locMsg, altLocMsg) = loadPersonMentorLocations(null)
                    person.registrationDate = new Date()
                    validateMentorRejectErrors(person, locErrorCodes, altLocErrorCodes, true)
                    if (!params.terms.equals("on")) person.errors.reject('terms.not.accepted')
                    if (!person.hasErrors()){
                        if (location != null) location.save(flush: true, failOnError: true)
                        if (altLocation != null) altLocation.save(flush: true, failOnError: true)
                        mentor.save(flush: true, failOnError: true)
                        person.save(flush: true, failOnError: true)
                        if (mentor.active) flash.message = message(code: 'mentor.created.message')
                        else flash.message = message(code: 'mentor.created.inactive.message')
                        emailMentorRegistrationResponse(person)
                        u = securityService.getSecurity(request, response)
                        status = u.status // reset
                        if (mentor.active) redirect(controller: "image", action: "mentorEdit")
                        else redirect(controller: "home", model: [status: status])
                        return
                    }else{
                        flash.message = null; // clear
                        def model = [personInstance: person, status: status]
                        if (locMsg != null) model.put("locMsg", locMsg)
                        if (altLocMsg != null) model.put("altLocMsg", altLocMsg)
                        model.put('mode', 'create')
                        render(view: "mentorRegistration", model: model)
                        return
                    }
                }else{
                    logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a person record, id $id")
                }
            }else{
                // If memberCode in params doesn't match that from the cookie, take them back to login screen.
                redirect(url: HomeController.MENTORING_LOGIN_URL)
            }
        }
    }

    private void validateMentorRejectErrors(Person person, locErrorCodes, altLocErrorCodes, boolean validatePerson) {
        if (validatePerson) person.validate()
        // Add any errors found in creating the Locations.
        if (locErrorCodes?.size() > 0) for (def errorCode : locErrorCodes) person.errors.reject(errorCode)
        if (altLocErrorCodes?.size() > 0) for (def errorCode : altLocErrorCodes) person.errors.reject(errorCode)
        // Validate the person's mentor record, and add any errors to the person.errors collection.
        person.mentor.validate()
        for (def error : person.mentor.errors.fieldErrors){
            person.errors.reject(error.code, g.message(error: error))
        }
    }

    private List loadPersonMentorLocations(personDb) {
        def mentor = new Mentor(params)
        params.put("mentor", mentor)
        // Copy existing Person data onto the new Person record, so that we can redisplay read-only fields to user.
        def person = new Person(params)
        if (personDb != null){
            // personDb will only be provided if the calling method is saving mentor details for a person who is already a mentee.
            person.properties = personDb.properties
        }
        def (location, locMsg, locErrorCodes) = populateValidateLocation(params)
        def (altLocation, altLocMsg, altLocErrorCodes) = populateValidateAltLocation(params)
        if (location != null) mentor.location = location
        if (altLocation != null) mentor.alternativeLocation = altLocation
        [person, locErrorCodes, altLocErrorCodes, location, altLocation, mentor, locMsg, altLocMsg]
    }

    def save_edited_mentor_su(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            Person person = Person.get(id)
            if (person.superUser){
                def personBeingEdited = Person.findByMemberCode(params.memberCode)
                if (personBeingEdited != null){
                    save_edited_mentor_db(personBeingEdited, params.memberCode, status, true)
                    return
                }
            }else{
                throw new RuntimeException("System error: only super users can use the save_edited_mentor_su() method")
            }
        }
    }

    def save_edited_mentor(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, mentorId = u.mentorId, menteeId = u.menteeId, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def person = Person.findByMemberCode(memberCode) // sanity check
                if (person != null){
                    save_edited_mentor_db(person, memberCode, status, false)
                    return
                }
            }
        }
    }

    private save_edited_mentor_db(person, memberCode, status, superUser){
        Mentor mentor
        def location, altLocation, locMsg, altLocMsg, locErrorCodes, altLocErrorCodes
        (person, locErrorCodes, altLocErrorCodes, location, altLocation, mentor, locMsg, altLocMsg) = loadPersonMentorLocations(null)
        def personDb = Person.findByMemberCode(memberCode)
        person.registrationDate = personDb.registrationDate
        validateMentorRejectErrors(person, locErrorCodes, altLocErrorCodes, true)
        if (!person.hasErrors()){
            if (!checkPersonVersioning(personDb, person, status)) return
            // Copy properties onto the Person record taken from the database
            personDb.properties = params
            if (personDb.mentor.location != null) personDb.mentor.location.save()
            if (personDb.mentor.alternativeLocation != null) personDb.mentor.alternativeLocation.save()
            personDb.mentor.save(flush: true, failOnError: true)
            personDb.save(flush: true, failOnError: true)
            if (mentor.active) flash.message = message(code: 'mentor.updated.message')
            else flash.message = message(code: 'mentor.updated.inactive.message')
            redirect(controller: "home", model: [status: status])
        }else{
            flash.message = null; // clear
            person.version = Long.parseLong(params.version)
            def model = [personInstance: person, status: status]
            if (locMsg != null) model.put("locMsg", locMsg)
            if (altLocMsg != null) model.put("altLocMsg", altLocMsg)
            model.put('mode', 'edit')
            model.put('superUser', superUser)
            render(view: "mentorRegistration", model: model)
        }
    }

    def save_new_mentee(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def person = Person.findByMemberCode(memberCode) // sanity check
                if (person == null){
                    Mentee mentee
                    def location, locMsg, locErrorCodes
                    (person, locErrorCodes, mentee, location, locMsg) = loadPersonMenteeLocation()
                    person.registrationDate = new Date()
                    validateMenteeRejectErrors(person, locErrorCodes, mentee, true)
                    if (!params.terms.equals("on")) person.errors.reject('terms.not.accepted')
                    if (!person.hasErrors()){
                        if (location != null) location.save(flush: true, failOnError: true)
                        mentee.save(flush: true, failOnError: true)
                        person.save(flush: true, failOnError: true)
                        if (mentee.active) flash.message = message(code: 'mentee.created.message')
                        else flash.message = message(code: 'mentee.created.inactive.message')
                        emailMenteeRegistrationResponse(person)
                        u = securityService.getSecurity(request, response)
                        status = u.status // reset
                        if (mentee.active) redirect(controller: "image", action: "menteeEdit")
                        else redirect(controller: "home", model: [status: status])
                        return
                    }else{
                        flash.message = null; // clear
                        def model = [personInstance: person, status: status]
                        if (locMsg != null) model.put("locMsg", locMsg)
                        model.put("mode", "create")
                        render(view: "menteeRegistration", model: model)
                        return
                    }
                }else{
                    logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a person record, id $id")
                }
            }else{
                // If memberCode in params doesn't match that from the cookie, take them back to login screen.
                redirect(url: HomeController.MENTORING_LOGIN_URL)
            }
        }
    }

    def save_new_additional_mentee(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def personDb = Person.findByMemberCode(memberCode) // sanity check
                if (personDb != null){
                    def (person, locErrorCodes, mentee, location, locMsg) = loadPersonMenteeLocation(personDb)
                    person.mentee = mentee
                    validateMenteeRejectErrors(person, locErrorCodes, mentee, false)
                    if (!person.hasErrors()){
                        if (location != null) location.save(failOnError: true)
                        mentee.save(flush: true, failOnError: true)
                        personDb.mentee = mentee
                        personDb.save(flush: true, failOnError: true)
                        if (mentee.active) flash.message = message(code: 'mentee.created.message')
                        else flash.message = message(code: 'mentee.created.inactive.message')
                        emailMenteeRegistrationResponse(person)
                        status = securityService.getSecurity(request, response) // reset
                        redirect(controller: "home", model: [status: status])
                        return
                    }else{
                        flash.message = null; // clear
                        def model = [personInstance: person, status: status]
                        if (locMsg != null) model.put("locMsg", locMsg)
                        model.put("mode", "create")
                        render(view: "menteeAddition", model: model)
                        return
                    }
                }else{
                    logRuntimeException("System error: cannot create mentee - no person record exists for membercode $memberCode")
                }
            }
        }
    }

    private void validateMenteeRejectErrors(Person person, locErrorCodes, Mentee mentee, boolean validatePerson) {
        if (validatePerson) person.validate()
        // Add any errors found in creating the Mentee or Location.
        if (locErrorCodes?.size() > 0) for (def errorCode : locErrorCodes) person.errors.reject(errorCode)
        mentee.validate()
        for (def error : mentee.errors.fieldErrors){
            person.errors.reject(error.code, g.message(error: error))
        }
    }

    private List loadPersonMenteeLocation(personDb) {
        def mentee = new Mentee(params)
        params.put("mentee", mentee)
        // Copy existing Person data onto the new Person record, so that we can redisplay read-only fields to user.
        def person = new Person(params)
        if (personDb != null){
            person.properties = personDb.properties
        }
        def (location, locMsg, locErrorCodes) = populateValidateLocation(params)
        if (location != null) mentee.location = location
        [person, locErrorCodes, mentee, location, locMsg]
    }

    def save_edited_mentee_su(){
        flash.message = null;
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            Person person = Person.get(id)
            if (person.superUser){
                def personBeingEdited = Person.findByMemberCode(params.memberCode)
                if (personBeingEdited != null){
                    save_edited_mentee_db(personBeingEdited, params.memberCode, status, true)
                    return
                }
            }else{
                throw new RuntimeException("System error: only super users can use the save_edited_mentee_su() method")
            }
        }
    }

    def save_edited_mentee(){
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, memberCode = u.memberCode
        if (status == Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            if (params.memberCode == memberCode){
                def person = Person.findByMemberCode(memberCode) // sanity check
                if (person != null){
                    save_edited_mentee_db(person, params.memberCode, status, false)
                    return
                }else{
                    logRuntimeException("System error: cannot create mentor - membercode $memberCode already has a person record, id $id")
                }
            }else{
                // If memberCode in params doesn't match that from the cookie, take them back to login screen.
                redirect(url: HomeController.MENTORING_LOGIN_URL)
            }
        }
    }

    private save_edited_mentee_db(person, memberCode, status, superUser){
        Mentee mentee
        def location, locMsg, locErrorCodes
        (person, locErrorCodes, mentee, location, locMsg) = loadPersonMenteeLocation()
        def personDb = Person.findByMemberCode(memberCode)
        person.registrationDate = personDb.registrationDate
        validateMenteeRejectErrors(person, locErrorCodes, mentee, true)
        if (!person.hasErrors()){
            if (!checkPersonVersioning(personDb, person, status)) return
            // Copy properties onto the Person record taken from the database
            personDb.properties = params
            if (personDb.mentee.location != null) personDb.mentee.location.save()
            personDb.mentee.save(flush: true, failOnError: true)
            personDb.save(flush: true, failOnError: true)
            if (mentee.active) flash.message = message(code: 'mentee.updated.message')
            else flash.message = message(code: 'mentee.updated.inactive.message')
            redirect(controller: "home", model: [status: status])
            return
        }else{
            flash.message = null; // clear
            person.version = Long.parseLong(params.version )
            def model = [personInstance: person, status: status]
            if (locMsg != null) model.put("locMsg", locMsg)
            model.put('mode', 'edit')
            model.put('superUser', superUser)
            render(view: "menteeRegistration", model: model)
        }
    }

    // check versioning of Person (no need to check Mentor/Mentee and Location records since save is only called on Person).
    private checkPersonVersioning(Person personDb, Person person, status) {
        if (personDb.version != null) {
            if (personDb.version > Long.parseLong(params.version)) {
                person.errors.reject("person.optimistic.locking.failure")
                render(view: "edit", model: [personInstance: person, status: status])
                false
            }
        }
        true
    }

    def populateValidateLocation(params){
        def (location, status) = Location.createLocation(
                    params.get("LocationAddressLine1"), params.get("LocationAddressLine2"), params.get("LocationTownCity"),
                    params.get("LocationPostZip"), params.get("LocationCountry"), geocodingService)
        def msg
        def List<String> errorCodes = new ArrayList()
        switch (status){
            case Location.Status.EMPTY:
            case Location.Status.VALID:
                break
            case Location.Status.ADDRESS_MISSING:
                errorCodes.add("location.address.missing")
                msg = message(code: 'location.address.missing')
                break
            case Location.Status.LOCATION_NOT_FOUND:
                errorCodes.add("location.address.not.found")
                msg = message(code: 'location.address.not.found')
                break
            case Location.Status.LOCATION_AMBIGUOUS:
                errorCodes.add("location.address.ambiguous")
                msg = message(code: 'location.address.ambiguous')
                break
            case Location.Status.MISSING_COUNTRY_CODE:
                errorCodes.add("location.country.blank.error")
                msg = message(code: 'location.country.blank.error')
                break
            case Location.Status.INVALID_COUNTRY_CODE:
                logRuntimeException("Country code '" + params.get("LocationCountry") + "' could not be found for location")
                break
            default:
                logRuntimeException("Unrecognised status received from Location.createLocation(): " + status)
        }
        [location, msg, errorCodes]
    }

    def populateValidateAltLocation(params){
        def (altLocation, status) = Location.createLocation(
                params.get("AltLocationAddressLine1"), params.get("AltLocationAddressLine2"), params.get("AltLocationTownCity"),
                params.get("AltLocationPostZip"), params.get("AltLocationCountry"), geocodingService)
        def msg = ""
        def List<List> errorCodes = new ArrayList()
        switch (status){
            case Location.Status.EMPTY:
            case Location.Status.VALID:
                break
            case Location.Status.ADDRESS_MISSING:
                errorCodes.add("alt.location.address.missing")
                msg = message(code: 'alt.location.address.missing')
                break
            case Location.Status.LOCATION_NOT_FOUND:
                errorCodes.add("alt.location.address.not.found")
                msg = message(code: 'alt.location.address.not.found')
                break
            case Location.Status.LOCATION_AMBIGUOUS:
                errorCodes.add("alt.location.address.ambiguous")
                msg = message(code: 'alt.location.address.ambiguous')
                break
            case Location.Status.MISSING_COUNTRY_CODE:
                errorCodes.add("alt.location.country.blank.error")
                msg = message(code: 'alt.location.country.blank.error')
                break
            case Location.Status.INVALID_COUNTRY_CODE:
                logRuntimeException("Country code '" + params.get("LocationCountry") + "' could not be found for alternative location")
                break
            default:
                logRuntimeException("Unrecognised status received from Location.createLocation(): " + status)
        }
        [altLocation, msg, errorCodes]
    }

    def logout(){
        securityService.logout(request, response)
        flash.message = null;
        redirect(url: MYIOP_LOGOUT_URL)
    }

    def logRuntimeException(String msg){
        log.info(msg)
        throw new RuntimeException(msg)
    }

    private void emailMentorRegistrationResponse(Person person){
        mailService.sendMail {
            to person.emailAddress
            from g.message(code: "iop.careers.manager.email")
            subject "IOP - Mentor Registration‏"
            body(view:"/mentor/registrationResponse", model:[person: person])
        }
    }

    private void emailMenteeRegistrationResponse(Person person){
        mailService.sendMail {
            to person.emailAddress
            from g.message(code: "iop.careers.manager.email")
            subject "IOP - Mentee Registration‏"
            body(view:"/mentee/registrationResponse", model:[person: person, url: HomeController.IOP_URL + HomeController.MENTORING_URL + "search/mentor"])
        }
    }

}