package org.iop.mentoring.domain

class NeedMentorReason {

    String reason

    static def getReasons() {
        return listOrderByReason()
    }

}
