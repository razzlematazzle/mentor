Mentoring - system documentation
================================

Overview
--------

The purpose of the Mentoring system is to enable registered MyIOP members to:

   * make themselves available as mentors
   * register as potential mentees
   * search for potential mentors or mentees
   * apply to a potential mentor
   * view outstanding applications, and current mentor(s)
   * earmark preferred mentors (so that people can apply to them later)

There are several types of users of the system, all of whom must be registered, logged-in MyIOP members:

   * unregistered on Mentoring - view only.
   * registered Mentor - available to Mentees
   * registered Mentee - can apply for mentoring
   * registered as both Mentor and Mentee - can do both the above
   * super-user - has control over the Mentoring system

Design Goals
------------

Screens should not be reliant on javascript/ajax, although this is used to improve user experience in some cases.

The software platform is based on current IOP standards, so _Grails_, _MySQL_ and  _Google Maps_ were chosen.

Database
--------

*   The database was created automatically by Grails from its domain objects. Data had to be migrated from a legacy system
which was stored within *Protech*, which forced an extremely un-normalised schema. The new Mentoring schema bears no resemblance
to the old, the data has had to be restructured to fit within the new.

*   The main tables are:

    * 	`person` all users of the Mentoring system have a person record
    *   `mentor` if a user registers as a mentor, additional data relevant to a mentor is stored in this table
    *   `location` the location of a mentor/mentee, which is used in geographical searches
    *   `mentee` if a user registers as a mentee, additional data relevant to a mentee is stored here

*   Lookup tables are used so that the main tables above can have objects associated with them:
    * 	`preferred_meeting_format` applies to mentors only - this can be used for searching by mentees
    * 	`need_mentor_reason` is selected by a mentee to indicate their main reason for wanting a mentor
    *   `organisation_type` every person must specify the type of organisation they work for
    *   `industry_sector` every person must specify the industry sector they work in
    *   `highest_qualification` every person must specify their highest qualification

*   One-to-many tables contain the relationships between the main tables and their associated objects:
    * 	`preferred_mentor` stores those mentors which a mentee is potentially interested in
    *   `mentoring_request` contains details of the applications made by mentees to mentors
    *   `mentor_mentee` contains actual mentor/mentee matches
    *   `mentee_need_mentor_reason` mentees may have several reasons why they need a mentor.

Please see the [Entity Relationship Diagram](ERD.txt) which shows the main table relationships.

Grails application
------------------

*   Layout

	The layout of the application follows Grails standards, so should contain no surprises.

*   Services

    These services contain important system functionality:
    * 	`CacheService` provides a very rudimentary cache of the results from looking up locations using the Google Maps API
    * 	`DatabaseQueryService` base class for common functionality
    * 	`GeocodingService` constructs queries to the Google Maps API, runs them and processes the results.
    *   `HumanVerificationService` requires the user to prove they are human before sending emails on their behalf.
    *   `PreferredMentorService` maintains preferred mentor data
    *   `ReportService` creates and runs reports for the super-user and mentor/mentees
    * 	`SearchService` constructs SQL used to conduct queries, corresponding to user searches, against the Mentoring database.
    * 	`SecurityService` this manages user access to the different functionality of the system. See the section on System Security below.

Search functionality
--------------------

Search functionality is provided which enables mentees to find potential mentors, and vice versa. The Mentor and Mentee Search screens are
very similar, although the former has more options.

These options are available for both Mentor and Mentee searches:

   * pick a country to search on.
   * choose a national or a location search. If the latter, the user must provide a postcode/zip/town/city which the Google Maps search engine understands.
   * job title, industry sector, and keywords can all be chosen, which will filter the results accordingly. Note that on the free text fields, if the user
   enters two words within quotes, only complete matches of the given phrase will be returned.

Additionally, Mentor searching has these options:

   * Preferred Meeting Format - a mentee can specify any, or just a particular meeting format, in case this is relevant to them.
   * Show *unavailable* mentors - a mentee can choose to include mentors who already have their full allocation of mentees assigned to them.
   The thinking behind this is that although a mentee won't be able to apply to these mentors, they might want to add them to their list of preferred mentors, for future use.

__Location__ based searching.

*   A mentor has at least one Location record, and a mentee has just one (a mentor is allowed an alternative, in case they don't want to provide mentoring at work or home).
    The location contains latitude and longitude. When a location record is created or updated, latitude/longitude is set,
    using a combination of whatever location fields have been provided, via the Google maps API (see section below).

*   Distance is calculated within the SQL search query run against the database. Distance is calculated by using a trigonometric function, comparing the latitude/longitude
   of the search with that of each mentor/mentee. The resulting distance is used both to filter and order the results.

   The amount of data on the database is sufficiently small that no special geolocation search engine is needed.

Google Maps API
---------------

The Geocoding service contains one public method, namely `getLatLong(String place)`. This method performs the following:

*   it firstly looks in its cache to see whether it has already obtained a result for this place, and returns it if so.
*   it constucts a URL by adding the place onto a standard URL base and submits it to Google. This base url is contained in the variable `urlBase`, and this should be altered if every Google change their API, or if we quote an API key in future.
*   it parses the result using a JsonSlurper. Google returns a set of results, and the latitude, longitude, and formatted_address is extracted from each one.
*   an array of results is constructed, each containing the latitude, longitude, and formatted address of the result, provided:
    * 	the latitude/longitude is within a square which contains the British Isles, if the country code is 'UK' or 'IE'.
    * 	the formatted address has not been duplicated by Google in their results (this does happen).
*   the array of results are added to the internal results cache, and then returned.

(We do not currently have a Google API key).

Human Verification
------------------

This is a simple Human Verification system, which doesn't require the use of javascript on the client. I have copied it
from the Engaging Physicists system.

A random string is generated, and the user has to extract the portion of the string which has been highlighted, and submit it.

I have tried to make it hard for a someone to script a crack for this:

*   the portion of the string which the user must select is not inserted in the same place every time.
*   the start/end tags vary (although I had to wrap them in a span tag, so maybe this isn't that useful)/
*   the strings are generated at random
*   the target string which the user must copy is encrypted before being returned, and the encryption is salted with strings based on today's date and "Mentoring" to make it harder to guess.

System Security
---------------

The Mentoring system relies entirely on MyIOP for security, and doesn't use any Grails security functionality. When someone logs
in to MyIOP, a cookie is dropped called "membercode", so Mentoring checks for its presence. If it isn't there, the user is directed to log in to MyIOP.

If the cookie is present and hasn't expired, the system looks to see whether there is a *person* record in existence with this code:

   * if no record exists then the user is only allowed to view records, but can register as a Mentor or Mentee.
   * if a record exists and the person is a registered Mentor, they can search for Mentees. They will also be able to use the Admin screen to view any mentees who may have applied to them.
   * if a record exists and the person is a registered Mentee, they can:
      * search for Mentors
      * add a Mentor to their list of preferred Mentors
      * apply to a Mentor via the system (they cannot do so directly since they will not be given the Mentor's email address).
      * view their applications for Mentoring, so they can see whether they have been successful.

Additionally, the system will look to see if the logged in person is designated as a super-user. If they are, they will be given several privileges:

   * they will select many extra reports on the Admin page.
   * they will be able to see and edit any mentor or mentee anywhere on the system
   * they can suspend a mentor/mentee should that ever prove necessary, so that their details will no longer appear in search results.

Application Resources
---------------------
   * Images. These are in `/web-app/images`.
   * Included documents. These are placed in the `/web-app/resources` directory, and currently consist of the mentoring agreement, and "Working Together".

   If a Terms and Conditions document is produced, it must be called TermsConditions.pdf and placed in the resources folder.
   The application looks for this file, and if present it will alter the disclaimer notice which is present on both
   the mentee and mentor registration screens.

   Without this file, the on-screen text reads: "By clicking Create, you confirm you are at least 18 years of age."
   If the file is present, the on-screen text changes to: "By clicking Create, you agree to our Terms and Conditions, and you confirm you are at least 18 years of age."

Testing
-------

There is a hidden feature of Mentoring which can be used to test whether services are running correctly. These are:

*   `/mentoring/test/geo` tests whether we can obtain a response from `http://maps.googleapis.com`
*   `/mentoring/test/db` tests we can do a live database query
*   `/mentoring/test/smtp?email=name@wherever.org` tests we can send an email

If you forget the syntax, type `/mentoring/test/help/`

Deployment
----------

To deploy the application:

*   You will need a server with this software:
    *   latest JDK
    *   latest MySQL
    *   latest Tomcat
*   Build a `.war` file, which should be renamed to `mentoring.war`
    *   If tomcat is running, stop the application using the manager console, then choose the undeploy option.
    *   Copy the new `.war` file into tomcat's webappp directory. Depending on how tomcat is set up, this should automatically explode the `.war` into the relevant directory structure.
    *   Start the application through the management console.

Data Migration
--------------

Data migration is managed by the DataMigrator. See `DataMigrator.groovy` which contains a runnable `main()` method.
This should only be run once on live data!

   * take the Protech database offline.
   * create a fresh, empty MySQL Mentoring database by temporarily changing `DataSource.groovy` to:

        development {
            dataSource {
                dbCreate = "create-drop"

   * run DataMigrator with:
      * VM options:  `-DproxySet=true -DproxyHost=iop-ldn-inet -DproxyPort=8080`
      * program arguments: `mssql lqssm root`
   * check the console output while running it
   * change `DataSource.groovy` back to `dbCreate = "update"` - __OR ELSE YOU WILL WIPE OUT YOUR NEWLY MIGRATED DATA!__
   * deploy a `mentoring.war` file as described above.

Jerry
14 May 2014



