package org.iop.mentoring.domain

import org.apache.commons.lang.builder.HashCodeBuilder

class MentorMentee implements Serializable {

    Mentor mentor
    Mentee mentee
    Date start
    Date end

    boolean equals(other) {
        if (!(other instanceof MentorMentee)) {
            return false
        }

        other.mentor?.id == mentor?.id &&
        other.mentee?.id == mentee?.id
    }

    int hashCode() {
        def builder = new HashCodeBuilder()
        if (mentor) builder.append(mentor.id)
        if (mentee) builder.append(mentee.id)
        builder.toHashCode()
    }

    static MentorMentee get(long mentorId, long menteeId) {
        find 'from MentorMentee where mentor.id=:mentorId and mentee.id=:menteeId',
                [mentorId: mentorId, menteeId: menteeId]
    }

    static MentorMentee create(Mentor mentor, Mentee mentee, boolean flush = false) {
        new MentorMentee(mentor: mentor, mentee: mentee).save(flush: flush, insert: true)
    }

    static boolean remove(Mentor mentor, Mentee mentee, boolean flush = false) {
        MentorMentee instance = MentorMentee.findByMentorAndMentee(mentor, mentee)
        if (!instance) {
            return false
        }

        instance.delete(flush: flush)
        true
    }

    static mapping = {
        id composite: ['mentor', 'mentee']
        version false
    }

    static constraints = {
        start nullable: true  // legacy data
        end nullable: true
    }
}
