package org.iop.mentoring.services

class MentoreeReportResult {
    BigDecimal menteePersonId
    BigDecimal menteeId
    String menteeLastName
    String menteeFirstName
    BigDecimal mentorPersonId
    BigDecimal mentorId
    String mentorLastName
    String mentorFirstName
    Date significantDate

    public getDuration(){
        return significantDate == null ? 0 : new Date() - significantDate
    }
}