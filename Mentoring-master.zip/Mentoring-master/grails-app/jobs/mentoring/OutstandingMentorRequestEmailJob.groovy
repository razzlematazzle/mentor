package mentoring

import org.iop.mentoring.controllers.HomeController
import org.iop.mentoring.controllers.ReportCommand
import org.iop.mentoring.domain.Person
import org.iop.mentoring.services.MentoreeReportResult
import org.iop.mentoring.services.ReportService

/**
 * Create a fortnightly email report of requests for mentoring which have been outstanding for more than a minimum length of time
 */
class OutstandingMentorRequestEmailJob {

    private static final daysOutstandingMinimum = 14

    def ReportService reportService

    def mailService

    static triggers = {
        //simple repeatInterval: 60000 // execute job once in 10 seconds
        cron name: 'fortnightly', cronExpression: "0 0 0 1,16 * ?"
    }

    def execute() {

        List<MentoreeReportResult> results = reportService.awaitingResponse(new ReportCommand())
        def sb = new StringBuilder()
        if (results.size() > 0) {
            sb.append("The following requests for mentoring have been outstanding for more than $daysOutstandingMinimum days:\n\n")
            for (MentoreeReportResult result : results){
                if (result.duration > daysOutstandingMinimum){
                    sb.append("  \tDays outstanding: ")
                    sb.append(result.duration)
                    sb.append("   ")
                    sb.append(result.menteeFirstName)
                    sb.append(" ")
                    sb.append(result.menteeLastName)
                    sb.append(" requested mentoring from ")
                    sb.append(result.mentorFirstName)
                    sb.append(" ")
                    sb.append(result.mentorLastName)
                    sb.append('\n')
                }
            }
            sb.append("\nIf you want to review these, go to ${HomeController.IOP_URL}${HomeController.MENTORING_URL}admin -> Awaiting Response")
        }
        def superUsers = Person.findSuperUsers()
        def emailees = []
        superUsers.collect(emailees, {it.getEmailAddress()})
        mailService.sendMail {
            from g.message(code: "iop.careers.manager.email")
            to emailees
            subject "Outstanding Mentoring Requests"
            text sb.toString()
        }
    }
}
