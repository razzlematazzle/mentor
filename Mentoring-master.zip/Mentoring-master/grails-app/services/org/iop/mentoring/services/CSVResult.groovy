package org.iop.mentoring.services

class CSVResult {
    BigDecimal personId
    BigDecimal mentorId
    BigDecimal menteeId
    String memberCode
    String emailAddress
    Date registrationDate
    String firstName
    String lastName
    BigDecimal maxMentees
    BigDecimal activeMentees
    BigDecimal activeMentors
    BigDecimal outstandingRequests
    Boolean superUser
    Boolean suspended

}
