package org.iop.mentoring.controllers

import org.iop.mentoring.services.GeocodingService
import org.iop.mentoring.services.SearchService

class TestController {

    def mailService
    def SearchService searchService
    def GeocodingService geocodingService

    def db() {
        def sc = new SearchCommand()
        sc.type = "Mentor"
        sc.distance = "national"
        def count = searchService.count(sc)
        if (count > 0){
            render("Database is available and returning records")
        }else{
            render("Database is NOT currently returning expected records! Investigate.")
        }
    }

    def smtp(){
        if (!params.email){
            render("You must state an email parameter, so that an email can be sent to it")
        }else{
            mailService.sendMail {
                from "testing@iop.org"
                to params.email
                subject "TEST"
                text "This is a test - please ignore"
            }
            render("message has been successfully sent to " + params.email)
        }

    }

    def smtpMentor() {
        def mailee = request.getParameter("mailee")
        def mentor = request.getParameter("mentor")
        if (mailee?.length() > 0 && mentor?.length() > 0) {
            mailService.sendMail {
                to mailee
                from g.message(code: "iop.careers.manager.email")
                subject "$mentor will provide mentoring support to you‏"
                body "just a test - give support to andy.dowding@iop.org on 17 Jul 2014."
            }
            render("Email dispatched to $mailee re $mentor, captain")
        }else{
            render("You must provide a mailee and a mentor parameter")
        }
    }

    def geo(){
        def result = geocodingService.getLatLong("London", "GB")
        if (result == null){
            render "ERROR! Could not use geocodingService"
        }else{
            render "geocodingService OK"
        }
    }

    def help(){
        render("There are 3 tests which can be run: db, geo, and smtp?email=yourname@whatever.com ")
    }
}
