dataSource {
    pooled = true
    driverClassName = "com.mysql.jdbc.Driver"
    username = "root"
    password = ""
}
hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = false
    cache.region.factory_class = 'net.sf.ehcache.hibernate.EhCacheRegionFactory'
}
// environment specific settings
environments {

    final DAYS_IN_MILLIS = 1000 * 60 * 24

    development {
        dataSource {
            dbCreate = "update" //  "create-drop" // one of 'create', 'create-drop', 'update', 'validate', ''
            driverClassName = "com.mysql.jdbc.Driver"
            //url = "jdbc:mysql://192.168.20.15:3306/mentoring"
            url = "jdbc:mysql://localhost:3306/mentoring"
            username = "mentor"
            password = "compaq"
            logSql = false
        }
    }
    test {
        dataSource {
            dbCreate = "update"
        }
    }
    production {
        dataSource {
            dbCreate = "update"
            url = "jdbc:mysql://localhost:3306/mentoring"
            username =  "mentor"
            password = "20omwDSwqer1" // compaq
            driverClassName = "com.mysql.jdbc.Driver"
            pooled = true
            properties {
                maxActive = 50
                maxIdle = 25
                minIdle = 1
                initialSize = 1
                numTestsPerEvictionRun = 3
                maxWait = 10000

                testOnBorrow = true
                testWhileIdle = true
                testOnReturn = true

                validationQuery = "select now()"

                minEvictableIdleTimeMillis = 3 + DAYS_IN_MILLIS
                timeBetweenEvictionRunsMillis = 3 + DAYS_IN_MILLIS
            }
        }
    }
}
