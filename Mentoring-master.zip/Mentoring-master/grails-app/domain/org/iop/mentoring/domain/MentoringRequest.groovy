package org.iop.mentoring.domain

class MentoringRequest {

    Person requester
    Person mentorRequested
    Date requestDate = new Date()
    String comment
    boolean emailSent = false
    char accepted = 'U'  // Initially Unknown. Acceptable values are Unknown (U), Yes (Y), No (N).

    static constraints = {
        comment nullable: true, maxSize: 1024
        accepted validator: {
            accepted, mentoringRequest ->
                if (!accepted ==~ /^[UYN]$/){
                    throw new RuntimeException("Unknown value $accepted in 'accepted' property")
                }
                if (accepted == 'Y' && !mentoringRequest.emailSent){
                        throw new IllegalStateException("Cannot accept a mentoring request before email sent!")
                }
        }
    }

    public void accept(){
        accepted = 'Y'
    }

    public void decline(){
        accepted = 'N'
    }

    public String getStatus(){
        def status
        if (accepted == 'Y') status = "Accepted"
        else if (accepted == 'N') status = "Not accepted"
        else status = 'Unknown'
        status
    }
}
