package org.iop.mentoring.controllers

import org.iop.mentoring.domain.Country
import org.iop.mentoring.domain.Mentee
import org.iop.mentoring.domain.Person
import org.iop.mentoring.domain.PreferredMeetingFormat
import org.iop.mentoring.services.GeocodingService
import org.iop.mentoring.services.SearchResult
import org.iop.mentoring.services.SearchService
import org.iop.mentoring.services.SecurityService
import org.iop.mentoring.services.UserInfo

class SearchController {

    def SecurityService securityService
    def SearchService searchService
    def GeocodingService geocodingService

    enum SearchType {
        MENTOR, MENTEE
    }

    private static String MENTOR = "Mentor"
    private static String MENTEE = "Mentee"

    def mentor() {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            render(view: "index", model: [status: status, type: SearchType.MENTOR, sc: new SearchCommand(), assignedMentorNames: u.assignedMentorNames,
                    preferredMentorNames: u.preferredMentorNames])
        }
    }

    def mentee() {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            // Search Mentees has been withdrawn, as per Vishanti and Stephanie's request. Jerry 03 July 2014
            //render(view: "index", model: [status: status, type: SearchType.MENTEE, sc: new SearchCommand()])
            redirect(url: "/")
        }
    }

    def modify = {
        def u = securityService.getSecurity(request, response)
        def status = u.status
        if (status == SecurityService.Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            SearchCommand sc = new SearchCommand()
            sc.place = params.get('place')
            sc.distance = params.get('distance')
            String[] pmfs = params.get('pmf')
            Set<PreferredMeetingFormat> preferredMeetingFormats = new HashSet<PreferredMeetingFormat>()
            for (String pmfName : pmfs) preferredMeetingFormats.add(PreferredMeetingFormat.get(pmfName))
            sc.preferredMeetingFormats = preferredMeetingFormats
            sc.type = params.get('type')
            sc.keywords = params.get('keywords')
            sc.jobTitle = params.get('jobTitle')
            sc.units = params.get('units')
            sc.showUnavailable = params.get('showUnavailable')
            sc.countryCode = params.get('countryCode')
            populateCommaSeparatedMultipleSearchItems(sc)
            render( view: "index", model: [status: status,sc:sc, type: getSearchTypeFromStr(params.get('type'))] )
        }
    }

    def page = {SearchCommand sc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            populateCommaSeparatedMultipleSearchItems(sc)
            def person = Person.get(id)
            if (isSuperUser(person)) sc = makeSearchCommandSuperUser(sc)
            pageList(sc, status, isSuperUser(person), u)
        }
    }

    boolean isSuperUser(Person person) {
        return person == null ? false : person.isSuperUser();
    }

    def list = {SearchCommand sc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        if (status == SecurityService.Status.NOT_LOGGED_IN){
            redirect(url: HomeController.MENTORING_LOGIN_URL)
        }else{
            sc.populateIndustrySectors(params.industrySectors)
            sc.populatePreferredMeetingFormats(params.preferredMeetingFormats)
            def person = Person.get(id)
            if (isSuperUser(person)) sc = makeSearchCommandSuperUser(sc)
            pageList(sc, status, isSuperUser(person), u)
        }
    }

    private SearchCommand makeSearchCommandSuperUser(SearchCommand sc) {
        sc.showInactive = true
        sc.showAdmin = true
        sc.showSuspended = true
        sc
    }

    private pageList(SearchCommand sc, SecurityService.Status status, boolean isSuperUser, UserInfo u){
        // insert default distance value which applies when field is disabled
        if (sc.distance == null) sc.distance = "national"
        sc.validate()
        if (sc.hasErrors()){
            render( view: "index", model: [sc:sc, type: getSearchType(sc)])
        }else{
            if (sc.place == null || sc.place.trim().length() == 0){
                searchDB(sc, status, isSuperUser, u)
            }else{
                // get geo-location of postcode
                def found = getGeoLocation(sc)
                switch (found.size()){
                    case 0:
                        // No matching location found, so error
                        sc.errors.reject("search.location.error")
                        render( view: "index", model: [sc:sc])
                        break
                    case 1:
                        // 1 geo-location found, so use it to search database
                        def (lat, lng, place) = found[0]
                        sc.lat = lat
                        sc.lng = lng
                        searchDB(sc, status, isSuperUser, u)
                        break
                    default:
                        //  > 1 matching location found, so seek disambiguation
                        found.sort{it[2]}
                        def model = [found: found, distance: sc.distance]
                        addIndustrySectors(sc, params)
                        addPreferredMeetingFormats(sc, params)
                        render( view: "disambiguate", model: model)
                }
            }
        }
    }

    def SearchType getSearchType(SearchCommand sc) {
        return getSearchTypeFromStr(sc.type)
    }

    def SearchType getSearchTypeFromStr(String s) {
        def type
        if (s != null){
            if (s == MENTOR){
                type = SearchType.MENTOR
            }else if (s == MENTEE){
                type = SearchType.MENTEE
            }else{
                throw RuntimeException("Unknown value for search type: \"" + type + "\"")
            }
        }
        type
    }

    private void searchDB(SearchCommand sc, status, isSuperUser, u) {
        List<SearchResult> results = searchService.search(sc)
        processSearchResults(results, sc, null, null, status, isSuperUser, u)
    }

    private void processSearchResults(List<SearchResult> results, SearchCommand sc, lat, lng, status, isSuperUser, UserInfo u) {
        if (results.size() > 0) {
            int total = params.total ? Integer.parseInt(params.total) : searchService.count(sc)
            def model = [resultsList: results, resultsTotal: total, place: sc.place, distance: sc.distance, units: sc.units, type: sc.type,
                    preferredMeetingFormat: sc.preferredMeetingFormats*.id, keywords: sc.keywords, jobTitle: sc.jobTitle]
            addIndustrySectors(sc, model)
            addPreferredMeetingFormats(sc, model)
            def searchTermsDisplay = getSearchTerms(sc)
            if (searchTermsDisplay != null) model.put("searchTerms", searchTermsDisplay)
            model.put("status", status)
            model.put("assignedMentorNames", u.assignedMentorNames)
            model.put("preferredMentorNames", u.preferredMentorNames)
            setParams(sc, model, total, lat, lng, isSuperUser)
            render(view: "list", model: model)
        } else {
            sc.errors.reject("search.results.empty")
            sc.type = params.get('type')
            render(view: "index", model: [sc: sc, status: status, type: getSearchTypeFromStr(params.get('type')),
                    assignedMentorNames: u.assignedMentorNames, preferredMentorNames: u.preferredMentorNames])
        }
    }

    def disambiguate = {SearchCommand sc ->
        populateCommaSeparatedMultipleSearchItems(sc)
        sc.place = params.location
        sc.lat = new BigDecimal(params.lat)
        sc.lng = new BigDecimal(params.lng)
        getSelectedPreferredMeetingFormats(sc)
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id
        def person = Person.get(id)
        def isSuperUser = isSuperUser(person)
        if (isSuperUser) sc = makeSearchCommandSuperUser(sc)
        searchDB(sc, status, isSuperUser, u)
    }

    private void getSelectedPreferredMeetingFormats(SearchCommand sc) {
        String[] pmfs = params.get('pmf')
        Set<PreferredMeetingFormat> preferredMeetingFormats = new HashSet<PreferredMeetingFormat>()
        for (String pmfName : pmfs) preferredMeetingFormats.add(PreferredMeetingFormat.get(pmfName))
        sc.preferredMeetingFormats = preferredMeetingFormats
    }

    private void addIndustrySectors(SearchCommand sc, Map<String, String> model) {
        if (sc.industrySectors?.size() > 0) {
            model.put("industrySectors", sc.industrySectors*.id.join(","))
        }
    }

    private void addPreferredMeetingFormats(SearchCommand sc, Map<String, String> model) {
        if (sc.preferredMeetingFormats?.size() > 0) {
            model.put("preferredMeetingFormats", sc.preferredMeetingFormats*.id.join(","))
        }
    }

    private void populateCommaSeparatedMultipleSearchItems(SearchCommand sc) {
        sc.populateIndustrySectors(params.industrySectors?.split(","))
        sc.populatePreferredMeetingFormats(params.preferredMeetingFormats?.split(","))
    }

    private ArrayList getGeoLocation(SearchCommand sc) {
        // If SearchCommand has been populated during pagination we will already have all the values relating to one geo-location.
        if (sc.lat != 0 && sc.lng != 0 ){
            return [[sc.lat, sc.lng, sc.place]]
        }else{
            return geocodingService.getLatLong(sc.place, sc.countryCode)
        }
    }

    private String getSearchTerms(SearchCommand sc) {
        def sb = new StringBuilder('You searched on ')
        def industrySectorsSearchTerm = getIndustrySectorsSearchTerm(sc)
        def preferredMeetingFormatsSearchTerm = getPreferredMeetingFormatsSearchTerm(sc)
        sb.append('<em>Country:</em> ' + Country.getCountryByCode(sc.countryCode).name)
        if (sc.distance != "national"){
            if (sc.place?.length() > 0){
                sb.append('; <em>Place:</em> ' + sc.place)
            }
            if (sc.distance && sc.distance){
                sb.append('; <em>Distance</em> &lt; ' + sc.distance + ' ' + sc.units)
            }
        }
        if (sc.jobTitle?.trim()?.length() > 0){
            sb.append('; <em>Job title:</em> ' + sc.jobTitle)
        }
        if (industrySectorsSearchTerm != null){
            sb.append('; <em>Industry sectors:</em> ' + industrySectorsSearchTerm)
        }
        if (preferredMeetingFormatsSearchTerm != null){
            sb.append('; <em>Meeting Format:</em> ' + preferredMeetingFormatsSearchTerm)
        }
        if (sc.keywords?.trim()?.length() > 0){
            sb.append('; <em>Keywords:</em> ' + sc.keywords)
        }
        if (sc.showUnavailable){
            sb.append('; <em>Show unavailable mentors</em> ')
        }
        sb.toString()
    }

    private String getIndustrySectorsSearchTerm(SearchCommand sc){
        return sc.industrySectors?.size() > 0 ? sc.industrySectors*.name.join(", ") : null
    }

    private String getPreferredMeetingFormatsSearchTerm(SearchCommand sc){
        return sc.preferredMeetingFormats?.size() > 0 ? sc.preferredMeetingFormats*.name.join(", ") : null
    }

    // Set up the params which will be passed as URL arguments.
    private setParams(SearchCommand sc, Map model, int total, lat, lng, isSuperUser) {
        def params = new HashMap()
        if (sc.place?.length() > 0){
            params.put("place", sc.place)
        }
        if (lat != null){
            params.put("lat", lat)
        }
        if (lng != null){
            params.put("lng", lng)
        }
        params.put("distance", sc.distance == null ? "national" : sc.distance)
        params.put("total", total)
        if (model.containsKey("industrySectors")){
            params.put("industrySectors", model.get("industrySectors"))
        }
        if (model.containsKey("preferredMeetingFormats")){
            params.put("preferredMeetingFormats", model.get("preferredMeetingFormats"))
        }
        if (sc.jobTitle?.trim()?.length() > 0){
            params.put("jobTitle", sc.jobTitle.trim())
        }
        if (sc.keywords?.trim()?.length() > 0){
            params.put("keywords", sc.keywords.trim())
        }
        model.put("superUser", isSuperUser)
        params.put("type", sc.type)
        params.put("offset", sc.offset)
        params.put("max", sc.max)
        if (sc.showUnavailable){
            model.put("showUnavailable", sc.showUnavailable)
        }
        if (sc.countryCode){
            model.put("countryCode", sc.countryCode)
        }
        model.put("params", params)
    }

    def show = {SearchCommand sc ->
        def u = securityService.getSecurity(request, response)
        def status = u.status, id = u.id, mentorId = u.mentorId
        def person = Person.get(Long.parseLong(params.id))
        if (!person) {
            render( view: "/error", text: 'System error: cannot find person with id ' + params.id)
        }else{
            if (status == SecurityService.Status.NOT_LOGGED_IN ){
                redirect(url: HomeController.MENTORING_LOGIN_URL)
                return
            }
            boolean superUser = Person.get(id) == null ? false : Person.get(id)?.superUser
            if (sc.type == MENTOR){
                def mentor = person.mentor
                if (!mentor) {
                    render( view: "/error", text: 'System error: cannot find mentor for person with id ' + params.id)
                }else{
                    def mentees = mentor.getLiveMentees()
                    // do not show Apply button if mentee is viewing their own mentor record.
                    def showApply = mentor.id != mentorId
                    render( view: "/mentor/show", model:[person: person, mentor: mentor, showApply: showApply, menteesAllocated: mentees, params: params, status: status, superUser: superUser, sc: sc] )
                }
            }else if (sc.type == MENTEE){
                def mentee = person.mentee
                if (!mentee) {
                    render( view: "/error", text: 'System error: cannot find mentee for person with id ' + params.id)
                }else{
                    render( view: "/mentee/show", model:[person: person, mentee: mentee, params: params, status: status, superUser: superUser, sc: sc] )
                }
            }else{
                throw new RuntimeException (sc.type == null ? "Mentor/ee type not known" : "Unknown mentor/ee type ${sc.type} in show()")
            }
        }
    }

    def cancel(){
        redirect(url: "/")
    }
}