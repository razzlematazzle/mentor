package org.iop.mentoring.controllers

import grails.validation.Validateable

@Validateable
class ReportCommand {
    // offset and max variables control which part of the result set should be displayed.
    int offset = 0
    int defaultMax = 30
    int max = defaultMax
}
