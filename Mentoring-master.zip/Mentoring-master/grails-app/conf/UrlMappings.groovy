class UrlMappings {

	static mappings = {
		"/$controller/$action?/$id?"{
			constraints {
				// apply constraints here
			}
		}

        "/"(controller: 'home', action: 'index')
        "/photo/upload"(controller: 'Person', view:'photo/upload', )
        "404"(view:'/notfound')
		"500"(view:'/error')
        "/cookie"(controller: 'home', action: 'dropDevCookie')
	}
}
