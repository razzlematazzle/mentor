package org.iop.mentoring.services

import groovy.sql.Sql
import mentoring.ReportController.ReportType
import org.iop.mentoring.controllers.ReportCommand

class ReportService extends DatabaseQueryService{

    static transactional = true

    final static String SELECT_TOTAL = "select count(*) total "

    final static countMentorsSql = SELECT_TOTAL + bodyMentorsSql

    final static listMentorsSql =
        "select p.id as person_id, p.member_code, mentor_id, registration_date, first_name, last_name, registration_date as significant_date " + bodyMentorsSql

    final static bodyMentorsSql = '''
        from person p
          inner join mentor m
            on p.mentor_id = m.id
          where suspended = false
          order by last_name '''

    final static countMenteesSql = SELECT_TOTAL + bodyMenteesSql

    final static listMenteesSql =
        "select p.id as person_id, p.member_code, mentee_id, registration_date, first_name, last_name, registration_date as significant_date " + bodyMenteesSql

    final static bodyMenteesSql = '''
        from person p
          inner join mentee m
            on p.mentee_id = m.id
          where suspended = false
            order by last_name '''

    final static countSuspendedMentorsSql = SELECT_TOTAL + bodySuspendedMentorsSql

    final static listSuspendedMentorsSql =
        "select p.id as person_id, p.member_code, mentor_id, registration_date, first_name, last_name, registration_date as significant_date " + bodySuspendedMentorsSql

    final static bodySuspendedMentorsSql = '''
        from person p
          inner join mentor m
            on p.mentor_id = m.id
          where suspended = true
          order by last_name '''

    final static countSuspendedMenteesSql = SELECT_TOTAL + bodySuspendedMenteesSql

    final static listSuspendedMenteesSql =
        "select p.id as person_id, p.member_code, mentee_id, registration_date, first_name, last_name, registration_date as significant_date " + bodySuspendedMenteesSql

    final static bodySuspendedMenteesSql = '''
        from person p
          inner join mentee m
            on p.mentee_id = m.id
          where suspended = true
          order by last_name '''


    final static countUnmatchedMentorsSql = SELECT_TOTAL + bodyUnmatchedMentorsSql

    final static listUnmatchedMentorsSql =
        "select p.id as person_id, p.member_code, mentor_id, registration_date, first_name, last_name, registration_date as significant_date " + bodyUnmatchedMentorsSql

    final static bodyUnmatchedMentorsSql = '''
        from person p
          inner join mentor m
            on p.mentor_id = m.id
          where p.mentor_id not in (
            select mentor_id
            from mentor_mentee mm
            where mm.end is null
          )
        order by last_name     '''

    final static countUnmatchedMenteesSql = SELECT_TOTAL + bodyUnmatchedMenteesSql

    final static listUnmatchedMenteesSql =
        "select p.id as person_id, p.member_code, mentor_id, registration_date, first_name, last_name, registration_date as significant_date " + bodyUnmatchedMenteesSql

    final static bodyUnmatchedMenteesSql = '''
        from person p
          inner join mentee m
            on p.mentee_id = m.id
          where p.mentee_id not in (
            select mentee_id
            from mentor_mentee mm
            where mm.end is null
          )
        order by last_name     '''

    final static countMenteesAwaitingResponseSql = SELECT_TOTAL + bodyMenteesAwaitingResponse

    final static listMenteesAwaitingResponseSql = "select p.id mentee_person_id, p.first_name mentee_first_name, p.last_name mentee_last_name, mr.request_date significant_date, datediff(now(), request_date) duration, p2.id mentor_person_id, p2.first_name mentor_first_name, p2.last_name mentor_last_name " + bodyMenteesAwaitingResponse

    final static bodyMenteesAwaitingResponse = '''
        from person p
          inner join mentee
            on p.mentee_id = mentee.id
          inner join mentoring_request mr
            on p.id = mr.requester_id
          inner join person p2
            on mr.mentor_requested_id = p2.id
          where mr.accepted = 'U'
        order by mr.request_date   '''

    final static countMatchesSql = SELECT_TOTAL + bodyMatchesSql

    final static listMatchesSql =  "select pe.id mentee_person_id, mm.mentee_id mentee_id, pe.first_name mentee_first_name, pe.last_name mentee_last_name, pr.id mentor_person_id, mm.mentor_id mentor_id, pr.first_name mentor_first_name, pr.last_name mentor_last_name, mm.start significant_date"  + bodyMatchesSql + orderMatchesByLastNameSql

    final static listMatchesByDurationSql =  "select pe.id mentee_person_id, mm.mentee_id mentee_id, pe.first_name mentee_first_name, pe.last_name mentee_last_name, pr.id mentor_person_id, mm.mentor_id mentor_id, pr.first_name mentor_first_name, pr.last_name mentor_last_name, mm.start significant_date"  + bodyMatchesSql  + orderMatchesByDurationLastNameSql

    final static bodyMatchesSql = '''
        from mentor_mentee mm
          inner join person pr
            on mm.mentor_id = pr.mentor_id
          inner join person pe
            on mm.mentee_id = pe.mentee_id
          where end is null   '''

    final static orderMatchesByDurationLastNameSql = " order by start, pe.last_name, pr.last_name"

    final static orderMatchesByLastNameSql = " order by pe.last_name, pr.last_name"

    final static listSuperUsersSql =
        "select p.id as person_id, p.member_code, mentor_id, mentee_id, registration_date, first_name, last_name, registration_date as significant_date " + bodySuperUsersSql

    final static bodySuperUsersSql = '''
        from person p
        left outer join mentor
            on p.mentor_id = mentor.id
        left outer join mentee
            on p.mentee_id = mentee.id
        where super_user = true
          order by last_name   '''

    final static countSuperUsersSql = SELECT_TOTAL + bodySuperUsersSql

    final static CSV_Sql ='''
        select p.id as person_id, p.member_code, p.mentor_id, p.mentee_id, p.email_address, registration_date, first_name, last_name, max_mentees, sum(mmr.mentee_id is not null and mmr.end is null) active_mentees, sum(mme.mentor_id is not null and mme.end is null) active_mentors, sum(r.requester_id is not null) outstanding_requests, super_user, suspended
        from person p
          left outer join mentor
            on p.mentor_id = mentor.id
          left outer join mentor_mentee mmr
            on mentor.id = mmr.mentor_id
          left outer join mentee
            on p.mentee_id = mentee.id
          left outer join mentor_mentee mme
            on mentee.id = mme.mentee_id
          left outer join (
            select requester_id
            from mentoring_request
            where accepted = 'U'
          ) r
            on p.id = requester_id
        group by p.id, p.member_code, p.mentor_id, p.mentee_id, p.email_address, registration_date, first_name, last_name  '''

    final static countOutstandingRequestsReceivedSql = '''
        select count(*) total
        from mentoring_request mr
          inner join person p
            on mr.mentor_requested_id = p.id
        where p.id = ?
          and mr.accepted = 'U'
    '''

    final static countOutstandingRequestsMadeSql = '''
        select count(*) total
        from mentoring_request mr
          inner join person p
            on mr.requester_id = p.id
        where p.id = ?
              and mr.accepted = 'U'
    '''

    public def List<ReportResult> mentors(ReportCommand rc) {
        def sql = newSql()
        try {
            List<ReportResult> resultsList = createSearchResults(sql, listMentorsSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countMentors (){
        return count(countMentorsSql)
    }

    public def List<ReportResult> mentees(ReportCommand rc) {
        def sql = newSql()
        try {
            List<ReportResult> resultsList = createSearchResults(sql, listMenteesSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countMentees (){
        return count(countMenteesSql)
    }

    public def List<ReportResult> unmatchedMentors(ReportCommand rc) {
        def sql = newSql()
        try {
            List<ReportResult> resultsList = createSearchResults(sql, listUnmatchedMentorsSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countUnmatchedMentors (){
        return count(countUnmatchedMentorsSql)
    }

    public def List<ReportResult> unmatchedMentees(ReportCommand rc) {
        def sql = newSql()
        try {
            List<ReportResult> resultsList = createSearchResults(sql, listUnmatchedMenteesSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countUnmatchedMentees (){
        return count(countUnmatchedMenteesSql)
    }

    public def List<MentoreeReportResult> awaitingResponse(ReportCommand rc) {
        def sql = newSql()
        try {
            List<MentoreeReportResult> resultsList = createMentoreeSearchResults(sql, listMenteesAwaitingResponseSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countAwaitingResponse (){
        return count(countMenteesAwaitingResponseSql)
    }

    public def List<MentoreeReportResult> matched(rc, durationOrder) {
        def sql = newSql()
        def query = durationOrder ? listMatchesByDurationSql : listMatchesSql
        try {
            List<MentoreeReportResult> resultsList = createMentoreeSearchResults(sql, query + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }


    public int countMatched (){
        return count(countMatchesSql)
    }

    public def List<ReportResult> suspended(ReportCommand rc, ReportType reportType) {
        def sql = newSql()
        def query = reportType == ReportType.MENTOR ? listSuspendedMentorsSql : listSuspendedMenteesSql
        try {
            List<ReportResult> resultsList = createSearchResults(sql, query + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countSuspended (ReportType reportType){
        def query = reportType == ReportType.MENTOR ? countSuspendedMentorsSql : countSuspendedMenteesSql
        return count(query)
    }

    public def List<ReportResult> superUsers(ReportCommand rc){
        def sql = newSql()
        try {
            List<MentoreeReportResult> resultsList = createSearchResults(sql, listSuperUsersSql + " limit " +  rc.offset + ", "  + rc.max)
            return resultsList
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    public int countSuperUsers (){
        return count(countSuperUsersSql)
    }

    public def String extractCSV(){
        def sql = newSql()
        try {
            List<CSVResult> resultsList = createCSVResults(sql, CSV_Sql )
            def csvResult = convertResultSetToCSV(resultsList)
            return csvResult
        } catch (Exception e) {
            log(e.getMessage())
            sql.rollback()
            throw (e)
        }
    }

    private String convertResultSetToCSV(csvResults) {
        def sb = new StringBuilder()
        appendCsvHeaderLine(sb)
        for (CSVResult res: csvResults){
            appendCsvRow(sb, res)
        }
        sb.toString()
    }

    private void appendCsvRow(StringBuilder sb, CSVResult res) {
        appendQuoteAndComma(sb, res.personId)
        appendQuotedYesNoAndComma(sb, res.mentorId)
        appendQuotedYesNoAndComma(sb, res.menteeId)
        appendQuoteAndComma(sb, res.memberCode)
        appendQuoteAndComma(sb, res.emailAddress)
        appendQuoteAndComma(sb, res.registrationDate.format('dd MMM yyyy'))
        appendQuoteAndComma(sb, res.firstName)
        appendQuoteAndComma(sb, res.lastName)
        appendQuoteAndComma(sb, res.maxMentees)
        appendQuoteAndComma(sb, res.activeMentees)
        appendQuoteAndComma(sb, res.activeMentors)
        appendQuoteAndComma(sb, res.outstandingRequests)
        appendQuoteAndComma(sb, res.superUser)
        appendQuoteAndComma(sb, res.suspended)
        sb.append("\n")
    }

    private void appendCsvHeaderLine(StringBuilder sb) {
        appendQuoteAndComma(sb, "Mentoring ID")
        appendQuoteAndComma(sb, "Is Mentor")
        appendQuoteAndComma(sb, "Is Mentee")
        appendQuoteAndComma(sb, "Member code")
        appendQuoteAndComma(sb, "Email address")
        appendQuoteAndComma(sb, "Registration date")
        appendQuoteAndComma(sb, "First name")
        appendQuoteAndComma(sb, "Last name")
        appendQuoteAndComma(sb, "Max Mentees")
        appendQuoteAndComma(sb, "Active Mentees")
        appendQuoteAndComma(sb, "Active Mentors")
        appendQuoteAndComma(sb, "Outstanding Requests")
        appendQuoteAndComma(sb, "Super User")
        appendQuoteAndComma(sb, "Suspended")
        sb.append("\n")
    }

    private void appendQuoteAndComma(StringBuilder sb, field) {
        if (field != null) sb.append('"' + field + '",')
        else sb.append(',')
    }

    private void appendQuotedYesNoAndComma(StringBuilder sb, field) {
        if (field == null) sb.append('"No",')
        else sb.append('"Yes",')
    }

    public int count(query) {
        Sql sql = new groovy.sql.Sql(dataSource)
        def row = sql.firstRow(query)
        return row.total
    }

    public int countOutstandingRequestsMade(long id){
        return count(countOutstandingRequestsMadeSql.replace("?", id.toString()))
    }

    public int countOutstandingRequestsReceived(long id){
        return count(countOutstandingRequestsReceivedSql.replace("?", id.toString()))
    }

    private List<ReportResult> createSearchResults(Sql sql, String query) {
        List<ReportResult> resultsList = sql.rows(query.toString()).collect { row ->
            new ReportResult(
                    personId: row['person_id'],
                    memberCode: row['member_code'],
                    mentorId: row.containsKey("mentor_id") ? row['mentor_id'] : null,
                    menteeId: row.containsKey("mentee_id") ? row['mentee_id'] : null,
                    firstName: row['first_name'],
                    lastName: row['last_name'],
                    significantDate: row['significant_date']
            )
        }
        resultsList
    }

    private List<MentoreeReportResult> createMentoreeSearchResults(Sql sql, String query) {
        List<MentoreeReportResult> resultsList = sql.rows(query.toString()).collect { row ->
            new MentoreeReportResult(
                    menteePersonId: row['mentee_person_id'],
                    menteeId: row.containsKey("mentee_id") ? row['mentee_id'] : null,
                    menteeFirstName: row['mentee_first_name'],
                    menteeLastName: row['mentee_last_name'],
                    mentorPersonId: row['mentor_person_id'],
                    mentorId: row.containsKey("mentor_id") ? row['mentor_id'] : null,
                    mentorFirstName: row['mentor_first_name'],
                    mentorLastName: row['mentor_last_name'],
                    significantDate: row['significant_date']
            )
        }
        resultsList
    }

    private List<CSVResult> createCSVResults(Sql sql, String query) {
        List<CSVResult> resultsList = sql.rows(query.toString()).collect { row ->
            new CSVResult(
                    personId: row['person_id'],
                    memberCode: row['member_code'],
                    mentorId: row['mentor_id'],
                    menteeId: row['mentee_id'],
                    emailAddress: row['email_address'],
                    registrationDate: row['registration_date'],
                    firstName: row['first_name'],
                    lastName: row['last_name'],
                    maxMentees: row['max_mentees'],
                    activeMentees: row['active_mentees'],
                    activeMentors: row['active_mentors'],
                    outstandingRequests: row['outstanding_requests'],
                    superUser: row['super_user'],
                    suspended: row['suspended']
            )
        }
        resultsList
    }
}
