package org.iop.mentoring.domain

class Mentee {

    boolean active = true
    boolean matched
    String skillsToDevelop
    String subject
    Date mentorChoiceDate = null
    Location location

    static hasMany = [preferredMentors: PreferredMentor, needMentorReasons: NeedMentorReason]

    static constraints = {
        active default: false
        matched default: false
        location nullable: true
        mentorChoiceDate nullable: true
        preferredMentors nullable: true, maxSize: 3
        needMentorReasons nullable: true, validator: {
            reasons, obj ->
                if (reasons == null){
                    // This is a hack to force Grails to pick up the correct error message
                    return ['mentee.needMentorReason.unstated.error']
                }
        }
        skillsToDevelop nullable: true, maxSize: 1000
    }
}
